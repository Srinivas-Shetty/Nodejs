import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './dashboard/components/Layout';
import Dashboard from './dashboard/components/Dashboard'
import Cases from './dashboard/components/Cases';
import InsuffClinet from './dashboard/components/InsuffClinet';
import SignIn from './sign-in/SignIn.jsx';
import ForgotPassword from './sign-in/ForgotPassword.jsx';
import OtpComponent from './sign-in/otp.jsx';
import AuthGuard from './auth/authGuard.jsx';
import SingleCaseUpload from './dashboard/components/SingleCaseUpload.jsx';
import UploadBatch from './dashboard/components/UploadBatch.jsx';
import AcceptBatch from './dashboard/components/AcceptBatch.jsx';
import ClientTracker from './dashboard/components/ClientTracker.jsx';
import ChatBotOptions from './dashboard/components/ChatBoat.jsx';
import DownloadTemplate from './dashboard/components/DownloadTemplate.jsx';

function App() {
  return (
    <>
    {/* <BrowserRouter> */}
          <BrowserRouter basename="/client">

    {/* <ChatBotOptions/> */}
      <Routes>
        <Route path='login' element={<SignIn/>}/>
        <Route path='forgotPassword' element={<ForgotPassword/>}/>
        <Route path='otpvalidation/:userId' element={<OtpComponent/>}/>
        <Route path="/" element={<AuthGuard> <Layout /> </AuthGuard>}>
          <Route index element={<Dashboard />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="cases" element={<Cases />} />
          <Route path="singlecaseupload" element={<SingleCaseUpload/>} />
          <Route path="batchupload" element={<UploadBatch/>} />
          <Route path="insufClient" element={<InsuffClinet />} />
          <Route path="acceptbatch" element={<AcceptBatch/>} />
          <Route path="clienttracker" element={<ClientTracker/>} />
          <Route path="downloadtemplate" element={<DownloadTemplate />} />
            
        </Route>
      </Routes> 
    </BrowserRouter>
    </>
  )
}

export default App
