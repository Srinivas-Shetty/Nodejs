// import * as React from 'react';
// import { styled } from '@mui/material/styles';
// import AppBar from '@mui/material/AppBar';
// import Box from '@mui/material/Box';
// import Stack from '@mui/material/Stack';
// import MuiToolbar from '@mui/material/Toolbar';
// import { tabsClasses } from '@mui/material/Tabs';
// import Typography from '@mui/material/Typography';
// import MenuRoundedIcon from '@mui/icons-material/MenuRounded';
// import DashboardRoundedIcon from '@mui/icons-material/DashboardRounded';
// import SideMenuMobile from './SideMenuMobile';
// import MenuButton from './MenuButton';
// import ColorModeIconDropdown from '../../shared-theme/ColorModeIconDropdown';
// import mainLogo from '../../assets/exlogo.jpeg'

// const Toolbar = styled(MuiToolbar)({
//   width: '100%',
//   padding: '12px',
//   display: 'flex',
//   flexDirection: 'column',
//   alignItems: 'start',
//   justifyContent: 'center',
//   gap: '12px',
//   flexShrink: 0,
//   [`& ${tabsClasses.flexContainer}`]: {
//     gap: '8px',
//     p: '8px',
//     pb: 0,
//   },
// });

// export default function AppNavbar({user, headerName}) {
//   const [open, setOpen] = React.useState(false);

//   const toggleDrawer = (newOpen) => () => {
//     setOpen(newOpen);
//   };

//   return (
//     <AppBar
//       position="fixed"
//       sx={{
//         // display: { xs: 'auto', md: 'none' },
//         boxShadow: 0,
//         bgcolor: "background.paper",
//         backgroundImage: "none",
//         borderBottom: "1px solid",
//         borderColor: "divider",
//         top: "var(--template-frame-height, 0px)",
//       }}
//     >
//       <Toolbar variant="regular" style={{ padding: "0px 12px" }}>
//         <Stack
//           direction="row"
//           alignItems="center"
//           justifyContent="space-between"
//           sx={{ width: "100%" }}
//         >
//           <Box display="flex" alignItems="center" height="64px">
//             {" "}
//             <img
          
//               src={mainLogo}
//               alt="Company Logo"
//               style={{
               
//                 height: "100%",
//                 width: "auto",
//                 maxWidth: "120px",
//                 objectFit: "contain",
//                 position:"absolute",
//                 left:"1130px", 
//               }}
//             />
//           </Box>

//           <Typography
//             variant="h4"
//             component="h1"
//             sx={{ color: "text.primary", textAlign: "center", flexGrow: 1 }}
//           >
//             {headerName || ""}
//           </Typography>
//           <Stack direction="row" alignItems="center" spacing={1}>
//             <ColorModeIconDropdown />
//             <MenuButton
//               aria-label="menu"
//               onClick={toggleDrawer(true)}
//               sx={{ display: { md: "none" } }}
//             >
//               <MenuRoundedIcon />
//             </MenuButton>
//           </Stack>
//         </Stack>
//         <SideMenuMobile open={open} toggleDrawer={toggleDrawer} user={user} />
//       </Toolbar>
//     </AppBar>
//   );
// }


import * as React from 'react';
import { styled } from '@mui/material/styles';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import MuiToolbar from '@mui/material/Toolbar';
import { tabsClasses } from '@mui/material/Tabs';
import Typography from '@mui/material/Typography';
import MenuRoundedIcon from '@mui/icons-material/MenuRounded';
import LogoutRoundedIcon from '@mui/icons-material/LogoutRounded'; // Import logout icon
import IconButton from '@mui/material/IconButton'; // Import IconButton
import SideMenuMobile from './SideMenuMobile';
import MenuButton from './MenuButton';
import ColorModeIconDropdown from '../../shared-theme/ColorModeIconDropdown';
import mainLogo from '../../assets/exlogo.jpeg';
import adammaLogo from '../../assets/Addammalogo.png';
import { useNavigate } from 'react-router-dom';
import Tooltip from '@mui/material/Tooltip'; // Import Tooltip at top
import EmailPopup from './EmailPopup';

const Toolbar = styled(MuiToolbar)({
  width: '100%',
  padding: '12px',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'start',
  justifyContent: 'center',
  gap: '12px',
  flexShrink: 0,
  [`& ${tabsClasses.flexContainer}`]: {
    gap: '8px',
    p: '8px',
    pb: 0,
  },
});

export default function AppNavbar({ user, headerName }) {
  const [open, setOpen] = React.useState(false);
  const navigate = useNavigate(); // For logout navigation

  const toggleDrawer = (newOpen) => () => {
    setOpen(newOpen);
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  return (
    <AppBar
      position="fixed"
      sx={{
        boxShadow: 0,
        bgcolor: "background.paper",
        backgroundImage: "none",
        borderBottom: "1px solid",
        borderColor: "divider",
        top: "var(--template-frame-height, 0px)",
      }}
    >
      <Toolbar variant="regular" style={{ padding: "0px 12px" }}>
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          sx={{ width: "100%" }}
        >
          <Box display="flex" alignItems="center" height="64px">
            <img
              src={adammaLogo}
              alt="Company Logo"
              style={{
                height: "100%",
                width: "auto",
                maxWidth: "200px",
                objectFit: "contain",
                // position: "absolute",
                // left: "1110px",
              }}
            />
          </Box>
          <Box display="flex" alignItems="center" height="64px">
            <img
              src={mainLogo}
              alt="Company Logo"
              style={{
                height: "100%",
                width: "auto",
                maxWidth: "120px",
                objectFit: "contain",
                position: "absolute",
                left: "1110px",
              }}
            />
          </Box>

          <Typography
            variant="h4"
            component="h1"
            sx={{ color: "text.primary", textAlign: "center", flexGrow: 1 }}
          >
            {headerName || ""}
          </Typography>
          

          <Stack direction="row" alignItems="center" spacing={1}>
            <EmailPopup  />
           <Tooltip title="Screen Mode">
              <Box>
            <ColorModeIconDropdown />
            </Box>
              </Tooltip>

            {/* Logout Icon Button  */}
             <Tooltip title="Logout">
            <IconButton onClick={handleLogout} style={{width:"35px",height: "35px",}}>
              <LogoutRoundedIcon />
            </IconButton>
              </Tooltip>
            <MenuButton
              aria-label="menu"
              onClick={toggleDrawer(true)}
              sx={{ display: { md: "none" } }}
            >
              <MenuRoundedIcon />
            </MenuButton>
          </Stack>
        </Stack>
        <SideMenuMobile open={open} toggleDrawer={toggleDrawer} user={user} />
      </Toolbar>
    </AppBar>
  );
}
