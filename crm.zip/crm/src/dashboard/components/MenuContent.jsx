// import * as React from 'react';
// import List from '@mui/material/List';
// import ListItem from '@mui/material/ListItem';
// import ListItemButton from '@mui/material/ListItemButton';
// import ListItemIcon from '@mui/material/ListItemIcon';
// import ListItemText from '@mui/material/ListItemText';
// import Stack from '@mui/material/Stack';
// import HomeRoundedIcon from '@mui/icons-material/HomeRounded';
// import AnalyticsRoundedIcon from '@mui/icons-material/AnalyticsRounded';
// import PeopleRoundedIcon from '@mui/icons-material/PeopleRounded';
// import UploadIcon from '@mui/icons-material/Upload'
// import AssignmentRoundedIcon from '@mui/icons-material/AssignmentRounded';
// import FileDownloadDoneIcon from '@mui/icons-material/FileDownloadDone'
// import { useLocation, useNavigate } from 'react-router-dom';

// const mainListItems = [
//   { text: 'Home', icon: <HomeRoundedIcon />, path:'/' },
//   { text: 'Cases', icon: <PeopleRoundedIcon />, path:'/cases' },
//   { text: 'Single Case Upload', icon: <PeopleRoundedIcon />, path:'/singlecaseupload' },
//   { text: 'Batch Upload', icon : <UploadIcon />, path:'/batchupload'},
//   { text: 'Insuff Client', icon: <AssignmentRoundedIcon />, path:'/insufClient' },
//   { text: 'Accept Batch', icon :<FileDownloadDoneIcon />, path:'/acceptbatch'},
//   { text: 'Client Tracker', icon :<FileDownloadDoneIcon />, path:'/clienttracker'}
// ];

// export default function MenuContent() {
//   const navigate = useNavigate() 
//   const loaction = useLocation()
//   return (
//     <Stack sx={{ flexGrow: 1, p: 1, justifyContent: "space-between" }}>
//       <List dense>
//         {mainListItems.map((item, index) => {
//             const isSelected = location.pathname === item.path || (item.path !== "/" && location.pathname.startsWith(item.path));
//             return (
//               <ListItem key={index} disablePadding sx={{ display: "block" }}>
//                 <ListItemButton selected={isSelected} onClick={() => navigate(item.path)}>
//                   <ListItemIcon sx={{ color: isSelected ? "primary.main" : "inherit" }}>
//                     {item.icon}
//                   </ListItemIcon>
//                   <ListItemText primary={item.text}/>
//                 </ListItemButton>
//               </ListItem>
//             );
//           }
//         )}
//       </List>
//     </Stack>
//   );
// }

///data colapse code...

// import * as React from 'react';
// import { Box, List, ListItem, ListItemButton, ListItemIcon, ListItemText, Tooltip } from '@mui/material';
// import HomeRoundedIcon from '@mui/icons-material/HomeRounded';
// import PeopleRoundedIcon from '@mui/icons-material/PeopleRounded';
// import UploadIcon from '@mui/icons-material/Upload';
// import AssignmentRoundedIcon from '@mui/icons-material/AssignmentRounded';
// import FileDownloadDoneIcon from '@mui/icons-material/FileDownloadDone';
// import { useLocation, useNavigate } from 'react-router-dom';

// const mainListItems = [
//   { text: 'Home', icon: <HomeRoundedIcon />, path: '/' },
//   { text: 'Cases', icon: <PeopleRoundedIcon />, path: '/cases' },
//   { text: 'Single Case Upload', icon: <PeopleRoundedIcon />, path: '/singlecaseupload' },
//   { text: 'Batch Upload', icon: <UploadIcon />, path: '/batchupload' },
//   { text: 'Insuff Client', icon: <AssignmentRoundedIcon />, path: '/insufClient' },
//   { text: 'Accept Batch', icon: <FileDownloadDoneIcon />, path: '/acceptbatch' },
//   { text: 'Client Tracker', icon: <FileDownloadDoneIcon />, path: '/clienttracker' }
// ];

// export default function MenuContent() {
//   const navigate = useNavigate();
//   const location = useLocation();
//   const [isCollapsed, setIsCollapsed] = React.useState(true);

//   return (
//     <Box
//       sx={{
//         width: isCollapsed ? '70px' : '220px', // adjust collapsed width smaller
//         transition: 'width 0.3s ease',
//         overflowX: 'hidden',
//         bgcolor: 'background.paper',
//         height: '100vh',
//         display: 'flex',
//         flexDirection: 'column',
//       }}
//       onMouseEnter={() => setIsCollapsed(false)}
//       onMouseLeave={() => setIsCollapsed(true)}
//     >
//       <List dense sx={{ p: 0 }}>
//         {mainListItems.map((item, index) => {
//           const isSelected = location.pathname === item.path || (item.path !== "/" && location.pathname.startsWith(item.path));
//           return (
//             <ListItem key={index} disablePadding sx={{ display: "block" }}>
//               <Tooltip title={isCollapsed ? item.text : ''} placement="right">
//                 <ListItemButton
//                   selected={isSelected}
//                   onClick={() => navigate(item.path)}
//                   sx={{
//                     justifyContent: isCollapsed ? 'center' : 'flex-start',
//                     px: 2,
//                     py: 1.5,
//                     minHeight: '56px',
//                     width: '100%',
//                     transition: 'all 0.3s ease',
//                   }}
//                 >
//                   <ListItemIcon
//                     sx={{
//                       color: isSelected ? "primary.main" : "inherit",
//                       minWidth: 'unset',
//                       mr: isCollapsed ? 0 : 2,
//                       display: 'flex',
//                       justifyContent: 'center',
//                       '& svg': {
//                         fontSize: '2rem',
//                       },
//                     }}
//                   >
//                     {item.icon}
//                   </ListItemIcon>

//                   {!isCollapsed && (
//                     <ListItemText
//                       primary={item.text}
//                       primaryTypographyProps={{ fontSize: '1rem', fontWeight: 500 }}
//                     />
//                   )}
//                 </ListItemButton>
//               </Tooltip>
//             </ListItem>
//           );
//         })}
//       </List>
//     </Box>
//   );
// }


// new code

import * as React from 'react';
import { Box, List, ListItem, ListItemButton, ListItemIcon, ListItemText, Tooltip } from '@mui/material';
import HomeRoundedIcon from '@mui/icons-material/HomeRounded';
import PeopleRoundedIcon from '@mui/icons-material/PeopleRounded';
import UploadIcon from '@mui/icons-material/Upload';
import AssignmentRoundedIcon from '@mui/icons-material/AssignmentRounded';
import FileDownloadDoneIcon from '@mui/icons-material/FileDownloadDone';
import { useLocation, useNavigate } from 'react-router-dom';

const mainListItems = [
  { text: 'Home', icon: <HomeRoundedIcon />, path: '/' },
  { text: 'Cases', icon: <PeopleRoundedIcon />, path: '/cases' },
  { text: 'Single Case Upload', icon: <PeopleRoundedIcon />, path: '/singlecaseupload' },
  { text: 'Batch Upload', icon: <UploadIcon />, path: '/batchupload' },
  { text: 'Accept Batch', icon: <FileDownloadDoneIcon />, path: '/acceptbatch' },
  { text: 'Clear Insuff', icon: <AssignmentRoundedIcon />, path: '/insufClient' },
  { text: 'Client Tracker', icon: <FileDownloadDoneIcon />, path: '/clienttracker' }
];

export default function MenuContent({ isCollapsed }) {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <Box
      sx={{
        width: isCollapsed ? '70px' : '220px',
        transition: 'width 0.3s ease',
        overflowX: 'hidden',
        bgcolor: 'background.paper',
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <List dense sx={{ p: 0 }}>
        {mainListItems.map((item, index) => {
          const isSelected = location.pathname === item.path || (item.path !== "/" && location.pathname.startsWith(item.path));
          return (
            <ListItem key={index} disablePadding sx={{ display: "block" }}>
              <Tooltip title={isCollapsed ? item.text : ''} placement="right">
                <ListItemButton
                  selected={isSelected}
                  onClick={() => navigate(item.path)}
                  sx={{
                    justifyContent: isCollapsed ? 'center' : 'flex-start',
                    px: 2,
                    py: 1.5,
                    minHeight: '56px',
                    width: '100%',
                    transition: 'all 0.3s ease',
                  }}
                >
                  <ListItemIcon
                    sx={{
                      color: isSelected ? "primary.main" : "inherit",
                      minWidth: 'unset',
                      mr: isCollapsed ? 0 : 2,
                      display: 'flex',
                      justifyContent: 'center',
                       transition: 'transform 0.3s ease',
                       transform: isSelected ? 'scale(1.4)' : 'scale(1.0)', 
                      '& svg': {
                        fontSize: '2  rem',
                      },
                    }}
                  >
                    {item.icon}
                  </ListItemIcon>

                  {!isCollapsed && (
                    <ListItemText
                      primary={item.text}
                      primaryTypographyProps={{ fontSize: '1rem', fontWeight: 500 }}
                    />
                  )}
                </ListItemButton>
              </Tooltip>
            </ListItem>
          );
        })}
      </List>
    </Box>
  );
}





