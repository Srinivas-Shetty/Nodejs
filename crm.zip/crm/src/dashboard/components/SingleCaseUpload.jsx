// import { useState, useEffect } from 'react';
// import { useRef } from 'react';

// import {
//   Grid,
//   Box,
//   Typography,
//   Button,
//   TextField,
//   Select,
//   MenuItem,
//   InputLabel,
//   FormControl,
//   CircularProgress
// } from '@mui/material';
// import api from '../../auth/api';
// import { Snackbar, Alert } from '@mui/material';



// function SingleCaseUpload() {
//   const [formData, setFormData] = useState({
//     clientId: '',
//     subclientId: '',
//     candidateName: '',
//     employeeId: '',
//     packageProfileAlacarte: '',
//     packageId: '',
//     profileId: '',
//     alacarteId: '',
//     tat: '',
//     price: '',
//     caseZipFile: null,
//     contractId: '',
//   });

//   const [loading, setLoading] = useState(false);
//   const [clientOptions, setClientOptions] = useState([]);
//   const [subclientOptions, setSubclientOptions] = useState([]);
//   const [contractOptions, setContractOptions] = useState([]);
//   const [contractDetails, setContractDetails] = useState(null);
//   const [packageOptions, setPackageOptions] = useState([]);
//   const [profileOptions, setProfileOptions] = useState([]);
//   const [alacarteOptions, setAlacarteOptions] = useState([]);
//   const [selectedPackageDetails, setSelectedPackageDetails] = useState([]);
//   const [selectedProfileDetails, setSelectedProfileDetails] = useState([]);
//   const [selectedAlacarteDetails, setSelectedAlacarteDetails] = useState([]);
//   const [selectedAlacarteIds, setSelectedAlacarteIds] = useState([]);
//   const [notification, setNotification] = useState({ open: false, message: '', severity: 'success' });
//   let userId = localStorage.getItem('userId') || '';

//   useEffect(() => {
//     const fetchClientData = async () => {
//       try {
//         const res = await api.get(`/usersubclientaccess/useremail/${userId}`);
//         if (res.data) {
//           const clients = res.data.reduce((acc, item) => {
//             if (!acc.some(client => client.id === item.client._id)) {
//               acc.push({ id: item.client._id, name: item.client.name });
//             }
//             return acc;
//           }, []);

//           const clientSubMap = res.data.reduce((map, item) => {
//             if (!map[item.client._id]) map[item.client._id] = [];
//             map[item.client._id].push({ id: item.subclient._id, name: item.subclient.name });
//             return map;
//           }, {});

//           setClientOptions(clients);
//           localStorage.setItem('clientSubclientMap', JSON.stringify(clientSubMap));
//         }
//       } catch (error) {
//         console.error('Error fetching client/subclient data:', error);
//       }
//     };
//     fetchClientData();
//   }, []);

//   useEffect(() => {
//     const fetchContractData = async () => {
//       if (!formData.clientId) return;
//       setLoading(true);

//       try {
//         const contractsRes = await api.get(`/clientcontracts/client/${formData.clientId}`);
//         setContractOptions(contractsRes.data);

//         if (contractsRes.data.length > 0) {
//           const contractId = contractsRes.data[0]._id;

//           setFormData(prev => ({ ...prev, contractId }));

//           const [detailsRes, componentsRes, packagesRes, profilesRes] = await Promise.all([
//             api.get(`/clientcontracts/${contractId}`),
//             api.get(`/clientcontractcomponents/clientcontract/${contractId}`),
//             api.get(`/clientcontractpackages/clientcontract/${contractId}`),
//             api.get(`/clientcontractprofiles/clientcontract/${contractId}`)
//           ]);

//           setContractDetails(detailsRes.data);
//           setAlacarteOptions(componentsRes.data);
//           setPackageOptions(packagesRes.data);
//           setProfileOptions(profilesRes.data);
//         }
//       } catch (error) {
//         console.error('Error fetching contract data:', error);
//         setContractOptions([]);
//         setContractDetails(null);
//         setAlacarteOptions([]);
//         setPackageOptions([]);
//         setProfileOptions([]);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchContractData();
//   }, [formData.clientId]);




//   useEffect(() => {
//     if (formData.clientId) {
//       const clientSubMap = JSON.parse(localStorage.getItem('clientSubclientMap') || '{}');
//       const validSubs = clientSubMap[formData.clientId] || [];
//       setSubclientOptions(validSubs);

//       const isStillValid = validSubs.some(sub => sub.id === formData.subclientId);
//       if (!isStillValid) {
//         setFormData(prev => ({ ...prev, subclientId: '' }));
//       }
//     } else {
//       setSubclientOptions([]);
//     }
//   }, [formData.clientId]);


//   useEffect(() => {
//     let selectedItem = null;

//     if (formData.packageId) {
//       selectedItem = packageOptions.find(item => item._id === formData.packageId);
//     } else if (formData.profileId) {
//       selectedItem = profileOptions.find(item => item._id === formData.profileId);
//     } else if (formData.alacarteId) {
//       selectedItem = alacarteOptions.find(item => item._id === formData.alacarteId);
//     }

//     if (selectedItem) {
//       setFormData(prev => ({
//         ...prev,
//         tat: selectedItem.tat || '',
//         price: selectedItem.price || '',
//       }));
//     } else {
//       setFormData(prev => ({ ...prev, tat: '', price: '' }));
//     }
//   }, [formData.packageId, formData.profileId, formData.alacarteId, packageOptions, profileOptions, alacarteOptions]);

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     if (name === 'packageProfileAlacarte') {
//       setFormData(prev => ({
//         ...prev,
//         [name]: value,
//         packageId: '',
//         profileId: '',
//         alacarteId: '',
//         tat: '',
//         price: '',
//       }));
//     } else {
//       setFormData(prev => ({ ...prev, [name]: value }));
//     }
//   };

//   const handleFileChange = (e) => {
//     setFormData(prev => ({ ...prev, caseZipFile: e.target.files[0] }));
//   };


//   const fileInputRef = useRef(null);

//   const handleUpload = async () => {
//     if (!formData.caseZipFile) return;

//     setLoading(true);

//     try {
//       const aCase = {
//         client: formData.clientId,
//         subclient: formData.subclientId,
//         candidateName: formData.candidateName,
//         employeeId: formData.employeeId,
//         status: 'INITIATED',
//       };

//       if (formData.packageProfileAlacarte === 'PACKAGE') {
//         aCase.package = formData.packageId;
//         aCase.tat = formData.tat;
//       } else if (formData.packageProfileAlacarte === 'PROFILE') {
//         aCase.profile = formData.profileId;
//         aCase.tat = formData.tat;
//       } else if (formData.packageProfileAlacarte === 'A-LA-CARTE') {
//         aCase.tat = selectedComponentsToUpload.reduce((max, comp) => Math.max(max, comp.tat || 0), 0);
//         aCase.componentsToCheck = selectedComponentsToUpload.map(comp => ({
//           component: comp.component?._id || comp.component,
//           componentName: comp.component?.name || comp.name,
//           componentDisplayName: comp.component?.displayName,
//           tat: comp.tat ?? comp.component?.internalTaT,
//           instructions: comp.instructions || '',
//           maxChecks: comp.maxChecks || '1',
//           selected: true,
//         }));
//       }

//       const formDataToSend = new FormData();
//       Object.entries(aCase).forEach(([key, value]) => {
//         formDataToSend.append(key, typeof value === 'object' ? JSON.stringify(value) : value);
//       });

//       formDataToSend.append('caseZipFile', formData.caseZipFile);

//       // await api.post('/cases', formDataToSend, {
//       //   headers: { 'Content-Type': 'multipart/form-data' },
//       // });

//       // setNotification({ open: true, message: 'Case uploaded successfully!', severity: 'success' });

//       const response = await api.post('/cases', formDataToSend, {
//         headers: { 'Content-Type': 'multipart/form-data' },
//       });

//       const uploadedCaseId = response.data?.caseId || '';

//       setNotification({
//         open: true,
//         message: `Case ID: ${uploadedCaseId} uploaded successfully!`,
//         severity: 'success',
//       });

//       setFormData({
//         clientId: '',
//         subclientId: '',
//         candidateName: '',
//         employeeId: '',
//         packageProfileAlacarte: '',
//         packageId: '',
//         profileId: '',
//         alacarteId: '',
//         tat: '',
//         price: '',
//         caseZipFile: null,
//         caseId: "",
//       });
//       if (fileInputRef.current) {
//         fileInputRef.current.value = '';
//       }
//     } catch (error) {
//       console.error('Upload failed:', error);
//       setNotification({ open: true, message: 'Upload failed. Please try again.', severity: 'error' });
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     const fetchPackageDetails = async () => {
//       if (!formData.packageId || !formData.contractId) {
//         setSelectedPackageDetails(null);
//         return;
//       }
//       try {
//         const res = await api.get(`/clientcontractpackages/${formData.packageId}`);
//         setSelectedPackageDetails(res.data);
//       } catch (error) {
//         console.error('Error fetching package details:', error);
//         setSelectedPackageDetails(null);
//       }
//     };
//     fetchPackageDetails();
//   }, [formData.packageId, formData.contractId]);

//   useEffect(() => {
//     const fetchProfileDetails = async () => {
//       if (!formData.profileId) {
//         setSelectedProfileDetails(null);
//         return;
//       }
//       try {
//         const res = await api.get(`/clientcontractprofiles/${formData.profileId}`);
//         setSelectedProfileDetails(res.data);
//       } catch (error) {
//         console.error('Error fetching profile details:', error);
//         setSelectedProfileDetails(null);
//       }
//     };
//     fetchProfileDetails();
//   }, [formData.profileId]);

//   useEffect(() => {
//     const fetchAlacarteDetails = async () => {
//       if (!formData.contractId) return;

//       try {
//         const res = await api.get(`/clientcontractcomponents/clientcontract/${formData.contractId}`);
//         setSelectedAlacarteDetails(res.data);
//       } catch (error) {
//         console.error('Error fetching a-la-carte details:', error);
//         setSelectedAlacarteDetails([]);
//       }
//     };

//     fetchAlacarteDetails();
//   }, [formData.contractId]);

//   const handleAlacarteCheckboxChange = (id) => {
//     setSelectedAlacarteIds((prev) =>
//       prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
//     );
//   };

//   const selectedComponentsToUpload = selectedAlacarteDetails.filter(comp =>
//     selectedAlacarteIds.includes(comp._id)
//   );
//   const handleInstructionChange = (index, value) => {
//     const updated = [...selectedAlacarteDetails];
//     updated[index].instruction = value;
//     setSelectedAlacarteDetails(updated);
//   };

//   const handleMaxChecksChange = (index, value) => {
//     const updated = [...selectedAlacarteDetails];
//     updated[index].maxChecks = value.replace(/\D/g, '');
//     setSelectedAlacarteDetails(updated);
//   };




//   return (
//     <Box sx={{ p: 4 }}>
//       <Typography variant="h4" gutterBottom>
//         Upload a Case
//       </Typography>
   


// <Grid container spacing={2}>
//   {/* Client Dropdown */}
//   <Grid item xs={12} sm={8} md={6}>
//     <FormControl sx={{ width: "400px" }}>
//       <InputLabel sx={{ bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' }}>
//         Client
//       </InputLabel>
//       <Select
//         name="clientId"
//         value={formData.clientId}
//         onChange={handleInputChange}
//         label="Client"
//         disabled={loading}
//         sx={{
//           '& .MuiOutlinedInput-notchedOutline': { borderColor: 'grey.500' },
//           '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: 'primary.main' },
//           '& .MuiSelect-select': { minWidth: '100%' },
//         }}
//         MenuProps={{
//           PaperProps: {
//             sx: { minWidth: '300px !important' },
//           },
//         }}
//       >
//         {clientOptions.map((client) => (
//           <MenuItem key={client.id} value={client.id}>
//             {client.name}
//           </MenuItem>
//         ))}
//       </Select>
//     </FormControl>
//   </Grid>

//   {/* Subclient Dropdown */}
//   <Grid item xs={12} sm={6} md={4}>
//     <FormControl sx={{ width: "400px" }}>
//       <InputLabel sx={{ bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' }}>
//         Subclient
//       </InputLabel>
//       <Select
//         name="subclientId"
//         value={formData.subclientId}
//         onChange={handleInputChange}
//         label="Subclient"
//         disabled={!formData.clientId || loading}
//         sx={{
//           '& .MuiOutlinedInput-notchedOutline': { borderColor: 'grey.500' },
//           '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: 'primary.main' },
//         }}
//       >
//         {subclientOptions.map((subclient) => (
//           <MenuItem key={subclient.id} value={subclient.id}>
//             {subclient.name}
//           </MenuItem>
//         ))}
//       </Select>
//     </FormControl>
//   </Grid>

//   {/* Candidate Name */}
//   <Grid item xs={12} sm={6} md={4}>
//     <TextField
//       fullWidth
//       label="Candidate Name"
//       name="candidateName"
//       value={formData.candidateName}
//       onChange={handleInputChange}
//       disabled={loading}
//       sx={{
//         width: "250px",
//         '& .MuiOutlinedInput-root': {
//           '& fieldset': { borderColor: 'grey.500' },
//           '&:hover fieldset': { borderColor: 'primary.main' },
//         },
//       }}
//       InputLabelProps={{ sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
//     />
//   </Grid>

//   {/* Employee ID */}
//   <Grid item xs={12} sm={6} md={4}>
//     <TextField
//       fullWidth
//       label="Employee ID"
//       name="employeeId"
//       value={formData.employeeId}
//       onChange={handleInputChange}
//       disabled={loading}
//       sx={{
//         '& .MuiOutlinedInput-root': {
//           '& fieldset': { borderColor: 'grey.500' },
//           '&:hover fieldset': { borderColor: 'primary.main' },
//         },
//       }}
//       InputLabelProps={{ sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
//     />
//   </Grid>

//   {/* Package/Profile/A la carte */}
//   <Grid item xs={12} sm={6} md={4}>
//     <FormControl sx={{ width: "400px" }}>
//       <InputLabel sx={{ bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' }}>
//         Package/Profile/A la carte
//       </InputLabel>
//       <Select
//         name="packageProfileAlacarte"
//         value={formData.packageProfileAlacarte}
//         onChange={handleInputChange}
//         label="Package/Profile/A la carte"
//         disabled={!formData.clientId || loading}
//         sx={{
//           '& .MuiOutlinedInput-notchedOutline': { borderColor: 'grey.500' },
//           '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: 'primary.main' },
//         }}
//       >
//         <MenuItem value="PACKAGE">Package</MenuItem>
//         <MenuItem value="PROFILE">Profile</MenuItem>
//         <MenuItem value="A-LA-CARTE">A la carte</MenuItem>
//       </Select>
//     </FormControl>
//   </Grid>

//   {/* Conditional Package/Profile Fields */}
//   {formData.packageProfileAlacarte === 'PACKAGE' && (
//     <Grid item xs={12} sm={6} md={4}>
//       <FormControl fullWidth>
//         <InputLabel sx={{ bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' }}>
//           Package
//         </InputLabel>
//         <Select
//           name="packageId"
//           value={formData.packageId}
//           onChange={handleInputChange}
//           label="Package"
//           disabled={!packageOptions.length || loading}
//           sx={{
//             '& .MuiOutlinedInput-notchedOutline': { borderColor: 'grey.500' },
//             '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: 'primary.main' },
//           }}
//         >
//           {packageOptions.map((pkg) => (
//             <MenuItem key={pkg._id} value={pkg._id}>
//               {pkg.name}
//             </MenuItem>
//           ))}
//         </Select>
//       </FormControl>
//     </Grid>
//   )}

//   {formData.packageProfileAlacarte === 'PROFILE' && (
//     <Grid item xs={12} sm={6} md={4}>
//       <FormControl fullWidth>
//         <InputLabel sx={{ bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' }}>
//           Profile
//         </InputLabel>
//         <Select
//           name="profileId"
//           value={formData.profileId}
//           onChange={handleInputChange}
//           label="Profile"
//           disabled={!profileOptions.length || loading}
//           sx={{
//             '& .MuiOutlinedInput-notchedOutline': { borderColor: 'grey.500' },
//             '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: 'primary.main' },
//           }}
//         >
//           {profileOptions.map((prf) => (
//             <MenuItem key={prf._id} value={prf._id}>
//               {prf.name}
//             </MenuItem>
//           ))}
//         </Select>
//       </FormControl>
//     </Grid>
//   )}

//   {/* TAT and Price Fields */}
//   {['PACKAGE', 'PROFILE'].includes(formData.packageProfileAlacarte) && (
//     <Grid item xs={12} sm={6} md={2}>
//       <TextField
//         fullWidth
//         label="TAT"
//         name="tat"
//         value={formData.tat}
//         InputProps={{ readOnly: true }}
//         sx={{
//           '& .MuiOutlinedInput-root': {
//             '& fieldset': { borderColor: 'grey.500' },
//             '&:hover fieldset': { borderColor: 'primary.main' },
//           },
//         }}
//         InputLabelProps={{ sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
//       />
//     </Grid>
//   )}

//   {formData.packageProfileAlacarte === 'PACKAGE' && (
//     <Grid item xs={12} sm={6} md={2}>
//       <TextField
//         fullWidth
//         label="Price"
//         name="price"
//         value={formData.price}
//         InputProps={{ readOnly: true }}
//         sx={{
//           '& .MuiOutlinedInput-root': {
//             '& fieldset': { borderColor: 'grey.500' },
//             '&:hover fieldset': { borderColor: 'primary.main' },
//           },
//         }}
//         InputLabelProps={{ sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
//       />
//     </Grid>
//   )}

//   {/* File Upload and Submit Button */}
//   <Grid item xs={12} sm={6}>
//     <TextField
//       fullWidth
//       type="file"
//       onChange={handleFileChange}
//       inputProps={{ accept: '.zip' }}
//       disabled={loading}
//       inputRef={fileInputRef}
//       sx={{
//         '& .MuiOutlinedInput-root': {
//           '& fieldset': { borderColor: 'grey.500' },
//           '&:hover fieldset': { borderColor: 'primary.main' },
//         },
//       }}
//       InputLabelProps={{ sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
//     />
//   </Grid>

//   <Grid item xs={12} sm={6} sx={{ display: 'flex', justifyContent: 'flex-end' }}>
//     <Button
//       variant="contained"
//       color="secondary"
//       sx={{ color: 'white', minWidth: 150, bgcolor: 'secondary.main', '&:hover': { bgcolor: 'secondary.dark' } }}
//       disabled={!formData.caseZipFile || loading}
//       onClick={handleUpload}
//       startIcon={loading && <CircularProgress size={20} color="inherit" />}
//     >
//       {loading ? 'Uploading...' : 'Upload'}
//     </Button>
//   </Grid>
// </Grid>

//       {/* Snackbar remains the same */}
//       <Snackbar
//         open={notification.open}
//         autoHideDuration={3000}
//         onClose={() => setNotification({ ...notification, open: false })}
//         anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
//       >
//         <Alert
//           onClose={() => setNotification({ ...notification, open: false })}
//           severity={notification.severity}
//           sx={{ width: '100%' }}
//         >
//           {notification.message}
//         </Alert>
//       </Snackbar>

//       {/* Table section remains the same */}
//       {['PACKAGE', 'PROFILE', 'A-LA-CARTE'].includes(formData.packageProfileAlacarte) && (
//         <Box mt={4}>
//           {/* ... existing table code ... */}
//         </Box>
//       )}
//     </Box>
//   );
// }


// export default SingleCaseUpload;




  //  <Grid container spacing={2}>

  //       {/* Client Dropdown - Fixed Width Issues */}
  //       <Grid item xs={15} sm={8} md={6}>
  //         <FormControl sx={{ width: "400px" }}>
  //           <InputLabel>Client</InputLabel>
  //           <Select
  //             name="clientId"
  //             value={formData.clientId}
  //             onChange={handleInputChange}
  //             label="Client"
  //             disabled={loading}
  //             sx={{
  //               '& .MuiSelect-select': {
  //                 minWidth: '100%',
  //               },
  //             }}
  //             MenuProps={{
  //               PaperProps: {
  //                 sx: {
  //                   minWidth: '300px !important',
  //                 },
  //               },
  //             }}
  //           >
  //             {clientOptions.map((client) => (
  //               <MenuItem key={client.id} value={client.id}>
  //                 {client.name}
  //               </MenuItem>
  //             ))}
  //           </Select>
  //         </FormControl>
  //       </Grid>

  //       {/* Subclient Dropdown */}
  //       <Grid item xs={12} sm={6} md={4}>
  //         <FormControl sx={{ width: "400px" }}>
  //           <InputLabel>Subclient</InputLabel>
  //           <Select
  //             name="subclientId"
  //             value={formData.subclientId}
  //             onChange={handleInputChange}
  //             label="Subclient"
  //             disabled={!formData.clientId || loading}
  //           >
  //             {subclientOptions.map((subclient) => (
  //               <MenuItem key={subclient.id} value={subclient.id}>
  //                 {subclient.name}
  //               </MenuItem>
  //             ))}
  //           </Select>
  //         </FormControl>
  //       </Grid>

  //       {/* Candidate Name */}
  //       <Grid item xs={12} sm={6} md={4}>
  //         <TextField
  //           fullWidth
  //           label="Candidate Name"
  //           name="candidateName"
  //           value={formData.candidateName}
  //           onChange={handleInputChange}
  //           // size="small"
  //           disabled={loading}
  //           sx={{ width: "250px" }}
  //         />
  //       </Grid>

  //       {/* Employee ID */}
  //       <Grid item xs={12} sm={6} md={4}>
  //         <TextField
  //           fullWidth
  //           label="Employee ID"
  //           name="employeeId"
  //           value={formData.employeeId}
  //           onChange={handleInputChange}
  //           size="small"
  //           disabled={loading}
  //         />
  //       </Grid>

  //       {/* Package/Profile/A la carte */}
  //       <Grid item xs={12} sm={6} md={4}>
  //         <FormControl sx={{ width: "400px" }}>
  //           <InputLabel>Package/Profile/A la carte</InputLabel>
  //           <Select
  //             name="packageProfileAlacarte"
  //             value={formData.packageProfileAlacarte}
  //             onChange={handleInputChange}
  //             label="Package/Profile/A la carte"
  //             disabled={!formData.clientId || loading}
  //           >
  //             <MenuItem value="PACKAGE">Package</MenuItem>
  //             <MenuItem value="PROFILE">Profile</MenuItem>
  //             <MenuItem value="A-LA-CARTE">A la carte</MenuItem>
  //           </Select>
  //         </FormControl>
  //       </Grid>

  //       {/* Conditional Package/Profile Fields */}
  //       {formData.packageProfileAlacarte === 'PACKAGE' && (
  //         <Grid item xs={12} sm={6} md={4}>
  //           <FormControl fullWidth size="small">
  //             <InputLabel>Package</InputLabel>
  //             <Select
  //               name="packageId"
  //               value={formData.packageId}
  //               onChange={handleInputChange}
  //               label="Package"
  //               disabled={!packageOptions.length || loading}
  //             >
  //               {packageOptions.map((pkg) => (
  //                 <MenuItem key={pkg._id} value={pkg._id}>
  //                   {pkg.name}
  //                 </MenuItem>
  //               ))}
  //             </Select>
  //           </FormControl>
  //         </Grid>
  //       )}

  //       {formData.packageProfileAlacarte === 'PROFILE' && (
  //         <Grid item xs={12} sm={6} md={4}>
  //           <FormControl fullWidth size="small">
  //             <InputLabel>Profile</InputLabel>
  //             <Select
  //               name="profileId"
  //               value={formData.profileId}
  //               onChange={handleInputChange}
  //               label="Profile"
  //               disabled={!profileOptions.length || loading}
  //             >
  //               {profileOptions.map((prf) => (
  //                 <MenuItem key={prf._id} value={prf._id}>
  //                   {prf.name}
  //                 </MenuItem>
  //               ))}
  //             </Select>
  //           </FormControl>
  //         </Grid>
  //       )}

  //       {/* TAT and Price Fields */}
  //       {['PACKAGE', 'PROFILE'].includes(formData.packageProfileAlacarte) && (
  //         <Grid item xs={12} sm={6} md={2}>
  //           <TextField
  //             fullWidth
  //             label="TAT"
  //             name="tat"
  //             value={formData.tat}
  //             InputProps={{ readOnly: true }}
  //             size="small"
  //           />
  //         </Grid>
  //       )}

  //       {formData.packageProfileAlacarte === 'PACKAGE' && (
  //         <Grid item xs={12} sm={6} md={2}>
  //           <TextField
  //             fullWidth
  //             label="Price"
  //             name="price"
  //             value={formData.price}
  //             InputProps={{ readOnly: true }}
  //             size="small"
  //           />
  //         </Grid>
  //       )}

  //       {/* File Upload and Submit Button */}
  //       <Grid item xs={12} sm={6}>
  //         <TextField
  //           fullWidth
  //           type="file"
  //           onChange={handleFileChange}
  //           inputProps={{ accept: '.zip' }}
  //           size="small"
  //           disabled={loading}
  //           inputRef={fileInputRef}
  //         />
  //       </Grid>

  //       <Grid item xs={12} sm={6} sx={{ display: 'flex', justifyContent: 'flex-end' }}>
  //         <Button
  //           variant="contained"
  //           color="secondary"
  //           sx={{ color: 'white', minWidth: 150 }}
  //           disabled={!formData.caseZipFile || loading}
  //           onClick={handleUpload}
  //           startIcon={loading && <CircularProgress size={20} color="inherit" />}
  //         >
  //           {loading ? 'Uploading...' : 'Upload'}
   
  //         </Button>
  //       </Grid>
  //     </Grid>


import { useState, useEffect } from 'react';
import { useRef } from 'react';

import {
  Grid,
  Box,
  Typography,
  Button,
  TextField,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  CircularProgress,
  Table,
  TableHead,
  TableRow,
  TableCell,
  Checkbox,
  TableBody,
  TableContainer
} from '@mui/material';
import api from '../../auth/api';
import { Snackbar, Alert } from '@mui/material';

import Paper from "@mui/material/Paper";


function SingleCaseUpload() {
  const [formData, setFormData] = useState({
    clientId: '',
    subclientId: '',
    candidateName: '',
    employeeId: '',
    packageProfileAlacarte: '',
    packageId: '',
    profileId: '',
    alacarteId: '',
    tat: '',
    price: '',
    caseZipFile: null,
    contractId: '',
  });

  const [loading, setLoading] = useState(false);
  const [clientOptions, setClientOptions] = useState([]);
  const [subclientOptions, setSubclientOptions] = useState([]);
  const [contractOptions, setContractOptions] = useState([]);
  const [contractDetails, setContractDetails] = useState(null);
  const [packageOptions, setPackageOptions] = useState([]);
  const [profileOptions, setProfileOptions] = useState([]);
  const [alacarteOptions, setAlacarteOptions] = useState([]);
  const [selectedPackageDetails, setSelectedPackageDetails] = useState([]);
  const [selectedProfileDetails, setSelectedProfileDetails] = useState([]);
  const [selectedAlacarteDetails, setSelectedAlacarteDetails] = useState([]);
  const [selectedAlacarteIds, setSelectedAlacarteIds] = useState([]);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'success' });
  let userId = localStorage.getItem('userId') || '';
console.log(packageOptions,"packageOptions");
console.log(selectedPackageDetails,"selectedPackageDetails");
console.log(profileOptions,"profileOptions");
console.log(alacarteOptions,"alacarteOptions");

  useEffect(() => {
    const fetchClientData = async () => {
      try {
        const res = await api.get(`/usersubclientaccess/useremail/${userId}`);
        if (res.data) {
          const clients = res.data.reduce((acc, item) => {
            if (!acc.some(client => client.id === item.client._id)) {
              acc.push({ id: item.client._id, name: item.client.name });
            }
            return acc;
          }, []);

          const clientSubMap = res.data.reduce((map, item) => {
            if (!map[item.client._id]) map[item.client._id] = [];
            map[item.client._id].push({ id: item.subclient._id, name: item.subclient.name });
            return map;
          }, {});

          setClientOptions(clients);
          localStorage.setItem('clientSubclientMap', JSON.stringify(clientSubMap));
        }
      } catch (error) {
        console.error('Error fetching client/subclient data:', error);
      }
    };
    fetchClientData();
  }, []);

  

  useEffect(() => {
    const fetchContractData = async () => {
      if (!formData.clientId) return;
      setLoading(true);

      try {
        const contractsRes = await api.get(`/clientcontracts/client/${formData.clientId}`);
        setContractOptions(contractsRes.data);

        if (contractsRes.data.length > 0) {
          const contractId = contractsRes.data[0]._id;

          setFormData(prev => ({ ...prev, contractId }));

          const [detailsRes, componentsRes, packagesRes, profilesRes] = await Promise.all([
            api.get(`/clientcontracts/${contractId}`),
            api.get(`/clientcontractcomponents/clientcontract/${contractId}`),
            api.get(`/clientcontractpackages/clientcontract/${contractId}`),
            api.get(`/clientcontractprofiles/clientcontract/${contractId}`)
          ]);

          setContractDetails(detailsRes.data);
          setAlacarteOptions(componentsRes.data);
          setPackageOptions(packagesRes.data);
          setProfileOptions(profilesRes.data);
        }
      } catch (error) {
        console.error('Error fetching contract data:', error);
        setContractOptions([]);
        setContractDetails(null);
        setAlacarteOptions([]);
        setPackageOptions([]);
        setProfileOptions([]);
      } finally {
        setLoading(false);
      }
    };

    fetchContractData();
  }, [formData.clientId]);




  useEffect(() => {
    if (formData.clientId) {
      const clientSubMap = JSON.parse(localStorage.getItem('clientSubclientMap') || '{}');
      const validSubs = clientSubMap[formData.clientId] || [];
      setSubclientOptions(validSubs);

      const isStillValid = validSubs.some(sub => sub.id === formData.subclientId);
      if (!isStillValid) {
        setFormData(prev => ({ ...prev, subclientId: '' }));
      }
    } else {
      setSubclientOptions([]);
    }
  }, [formData.clientId]);


  useEffect(() => {
    let selectedItem = null;

    if (formData.packageId) {
      selectedItem = packageOptions.find(item => item._id === formData.packageId);
    } else if (formData.profileId) {
      selectedItem = profileOptions.find(item => item._id === formData.profileId);
    } else if (formData.alacarteId) {
      selectedItem = alacarteOptions.find(item => item._id === formData.alacarteId);
    }

    if (selectedItem) {
      setFormData(prev => ({
        ...prev,
        tat: selectedItem.tat || '',
        price: selectedItem.price || '',
      }));
    } else {
      setFormData(prev => ({ ...prev, tat: '', price: '' }));
    }
  }, [formData.packageId, formData.profileId, formData.alacarteId, packageOptions, profileOptions, alacarteOptions]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (name === 'packageProfileAlacarte') {
      setFormData(prev => ({
        ...prev,
        [name]: value,
        packageId: '',
        profileId: '',
        alacarteId: '',
        tat: '',
        price: '',
      }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleFileChange = (e) => {
    setFormData(prev => ({ ...prev, caseZipFile: e.target.files[0] }));
  };


  const fileInputRef = useRef(null);

  const handleUpload = async () => {
    if (!formData.caseZipFile) return;

    setLoading(true);

    try {
      const aCase = {
        client: formData.clientId,
        subclient: formData.subclientId,
        candidateName: formData.candidateName,
        employeeId: formData.employeeId,
        status: 'INITIATED',
      };

      if (formData.packageProfileAlacarte === 'PACKAGE') {
        aCase.package = formData.packageId;
        aCase.tat = formData.tat;
      } else if (formData.packageProfileAlacarte === 'PROFILE') {
        aCase.profile = formData.profileId;
        aCase.tat = formData.tat;
      } else if (formData.packageProfileAlacarte === 'A-LA-CARTE') {
  const selectedComponentsToUpload = alacarteOptions.filter(comp => comp.selected);

  aCase.tat = selectedComponentsToUpload.reduce(
    (max, comp) => Math.max(max, comp.tat || comp.component?.internalTat || 0),
    0
  );

  aCase.componentsToCheck = selectedComponentsToUpload.map(comp => ({
    component: comp.component?._id || comp.component,
    componentName: comp.component?.name || comp.name,
    componentDisplayName: comp.component?.displayName,
    tat: comp.tat ?? comp.component?.internalTat,
    instructions: comp.instructions || '',
    maxChecks: comp.maxChecks || '1',
    selected: true,
  }));
}


      const formDataToSend = new FormData();
      Object.entries(aCase).forEach(([key, value]) => {
        formDataToSend.append(key, typeof value === 'object' ? JSON.stringify(value) : value);
      });

      formDataToSend.append('caseZipFile', formData.caseZipFile);

      // await api.post('/cases', formDataToSend, {
      //   headers: { 'Content-Type': 'multipart/form-data' },
      // });

      // setNotification({ open: true, message: 'Case uploaded successfully!', severity: 'success' });

      const response = await api.post('/cases', formDataToSend, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      const uploadedCaseId = response.data?.caseId || '';

      setNotification({
        open: true,
        message: `Case ID: ${uploadedCaseId} uploaded successfully!`,
        severity: 'success',
      });

      setFormData({
        clientId: '',
        subclientId: '',
        candidateName: '',
        employeeId: '',
        packageProfileAlacarte: '',
        packageId: '',
        profileId: '',
        alacarteId: '',
        tat: '',
        price: '',
        caseZipFile: null,
        caseId: "",
      });
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      console.error('Upload failed:', error);
      setNotification({ open: true, message: 'Upload failed. Please try again.', severity: 'error' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const fetchPackageDetails = async () => {
      if (!formData.packageId || !formData.contractId) {
        setSelectedPackageDetails(null);
        return;
      }
      try {
        const res = await api.get(`/clientcontractpackages/${formData.packageId}`);
        setSelectedPackageDetails(res.data);
      } catch (error) {
        console.error('Error fetching package details:', error);
        setSelectedPackageDetails(null);
      }
    };
    fetchPackageDetails();
  }, [formData.packageId, formData.contractId]);

  useEffect(() => {
    const fetchProfileDetails = async () => {
      if (!formData.profileId) {
        setSelectedProfileDetails(null);
        return;
      }
      try {
        const res = await api.get(`/clientcontractprofiles/${formData.profileId}`);
        setSelectedProfileDetails(res.data);
      } catch (error) {
        console.error('Error fetching profile details:', error);
        setSelectedProfileDetails(null);
      }
    };
    fetchProfileDetails();
  }, [formData.profileId]);

  useEffect(() => {
    const fetchAlacarteDetails = async () => {
      if (!formData.contractId) return;

      try {
        const res = await api.get(`/clientcontractcomponents/clientcontract/${formData.contractId}`);
        setSelectedAlacarteDetails(res.data);
      } catch (error) {
        console.error('Error fetching a-la-carte details:', error);
        setSelectedAlacarteDetails([]);
      }
    };

    fetchAlacarteDetails();
  }, [formData.contractId]);

  // const handleAlacarteCheckboxChange = (id) => {
  //   setSelectedAlacarteIds((prev) =>
  //     prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
  //   );
  // };

  const selectedComponentsToUpload = selectedAlacarteDetails.filter(comp =>
    selectedAlacarteIds.includes(comp._id)
  );
  // const handleInstructionChange = (index, value) => {
  //   const updated = [...selectedAlacarteDetails];
  //   updated[index].instruction = value;
  //   setSelectedAlacarteDetails(updated);
  // };

  // const handleMaxChecksChange = (index, value) => {
  //   const updated = [...selectedAlacarteDetails];
  //   updated[index].maxChecks = value.replace(/\D/g, '');
  //   setSelectedAlacarteDetails(updated);
  // };

const handleInstructionChange = (id, value) => {
  setAlacarteOptions((prev) =>
    prev.map((item) =>
      item._id === id ? { ...item, instructions: value } : item
    )
  );
};
console.log(selectedAlacarteDetails,"selectedAlacarteDetails123");

const handleMaxChecksChange = (id, value) => {
  const cleanedValue = value.replace(/\D/g, ''); // allow only numbers
  setAlacarteOptions((prev) =>
    prev.map((item) =>
      item._id === id ? { ...item, maxChecks: cleanedValue } : item
    )
  );
};

const handleAlacarteCheckboxChange = (id, checked) => {
  setAlacarteOptions((prev) =>
    prev.map((item) =>
      item._id === id ? { ...item, selected: checked } : item
    )
  );
};




  return (
    <Box sx={{ p: 4 }}>
      <Typography variant="h4" gutterBottom>
        Upload a Case
      </Typography>
   


<Grid container spacing={2}>
  {/* Client Dropdown */}
  <Grid item xs={12} sm={8} md={6}>
    <FormControl sx={{ width: "400px" }}>
      <InputLabel sx={{ bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' }}>
        Client
      </InputLabel>
      <Select
        name="clientId"
        value={formData.clientId}
        onChange={handleInputChange}
        label="Client"
        disabled={loading}
        sx={{
          '& .MuiOutlinedInput-notchedOutline': { borderColor: 'grey.500' },
          '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: 'primary.main' },
          '& .MuiSelect-select': { minWidth: '100%' },
        }}
        MenuProps={{
          PaperProps: {
            sx: { minWidth: '300px !important' },
          },
        }}
      >
        {clientOptions.map((client) => (
          <MenuItem key={client.id} value={client.id}>
            {client.name}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  </Grid>

  {/* Subclient Dropdown */}
  <Grid item xs={12} sm={6} md={4}>
    <FormControl sx={{ width: "400px" }}>
      <InputLabel sx={{ bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' }}>
        Subclient
      </InputLabel>
      <Select
        name="subclientId"
        value={formData.subclientId}
        onChange={handleInputChange}
        label="Subclient"
        disabled={!formData.clientId || loading}
        sx={{
          '& .MuiOutlinedInput-notchedOutline': { borderColor: 'grey.500' },
          '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: 'primary.main' },
        }}
      >
        {subclientOptions.map((subclient) => (
          <MenuItem key={subclient.id} value={subclient.id}>
            {subclient.name}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  </Grid>

  {/* Candidate Name */}
  <Grid item xs={12} sm={6} md={4}>
    <TextField
      fullWidth
      label="Candidate Name"
      name="candidateName"
      value={formData.candidateName}
      onChange={handleInputChange}
      disabled={loading}
      sx={{
        width: "250px",
        '& .MuiOutlinedInput-root': {
          '& fieldset': { borderColor: 'grey.500' },
          '&:hover fieldset': { borderColor: 'primary.main' },
        },
      }}
      InputLabelProps={{ sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
    />
  </Grid>

  {/* Employee ID */}
  <Grid item xs={12} sm={6} md={4}>
    <TextField
      fullWidth
      label="Employee ID"
      name="employeeId"
      value={formData.employeeId}
      onChange={handleInputChange}
      disabled={loading}
      sx={{
        '& .MuiOutlinedInput-root': {
          '& fieldset': { borderColor: 'grey.500' },
          '&:hover fieldset': { borderColor: 'primary.main' },
        },
      }}
      InputLabelProps={{ sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
    />
  </Grid>

  {/* Package/Profile/A la carte */}
  <Grid item xs={12} sm={6} md={4}>
    <FormControl sx={{ width: "400px" }}>
      <InputLabel sx={{ bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' }}>
        Package/Profile/A la carte
      </InputLabel>
      <Select
        name="packageProfileAlacarte"
        value={formData.packageProfileAlacarte}
        onChange={handleInputChange}
        label="Package/Profile/A la carte"
        disabled={!formData.clientId || loading}
        sx={{
          '& .MuiOutlinedInput-notchedOutline': { borderColor: 'grey.500' },
          '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: 'primary.main' },
        }}
      >
        <MenuItem value="PACKAGE">Package</MenuItem>
        <MenuItem value="PROFILE">Profile</MenuItem>
        <MenuItem value="A-LA-CARTE">A la carte</MenuItem>
      </Select>
    </FormControl>
  </Grid>

  {/* Conditional Package/Profile Fields */}
  {formData.packageProfileAlacarte === 'PACKAGE' && (
    <Grid item xs={12} sm={6} md={4}>
      <FormControl fullWidth>
        <InputLabel sx={{ bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' }}>
          Package
        </InputLabel>
        <Select
          name="packageId"
          value={formData.packageId}
          onChange={handleInputChange}
          label="Package"
          disabled={!packageOptions.length || loading}
          sx={{
            '& .MuiOutlinedInput-notchedOutline': { borderColor: 'grey.500' },
            '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: 'primary.main' },
          }}
        >
          {packageOptions.map((pkg) => (
            <MenuItem key={pkg._id} value={pkg._id}>
              {pkg.name}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </Grid>
  )}

  {formData.packageProfileAlacarte === 'PROFILE' && (
    <Grid item xs={12} sm={6} md={4}>
      <FormControl fullWidth>
        <InputLabel sx={{ bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' }}>
          Profile
        </InputLabel>
        <Select
          name="profileId"
          value={formData.profileId}
          onChange={handleInputChange}
          label="Profile"
          disabled={!profileOptions.length || loading}
          sx={{
            '& .MuiOutlinedInput-notchedOutline': { borderColor: 'grey.500' },
            '&:hover .MuiOutlinedInput-notchedOutline': { borderColor: 'primary.main' },
          }}
        >
          {profileOptions.map((prf) => (
            <MenuItem key={prf._id} value={prf._id}>
              {prf.name}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </Grid>
  )}

  {/* TAT and Price Fields */}
  {['PACKAGE', 'PROFILE'].includes(formData.packageProfileAlacarte) && (
    <Grid item xs={12} sm={6} md={2}>
      <TextField
        fullWidth
        label="TAT"
        name="tat"
        value={formData.tat}
        InputProps={{ readOnly: true }}
        sx={{
          '& .MuiOutlinedInput-root': {
            '& fieldset': { borderColor: 'grey.500' },
            '&:hover fieldset': { borderColor: 'primary.main' },
          },
        }}
        InputLabelProps={{ sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
      />
    </Grid>
  )}

  {formData.packageProfileAlacarte === 'PACKAGE' && (
    <Grid item xs={12} sm={6} md={2}>
      <TextField
        fullWidth
        label="Price"
        name="price"
        value={formData.price}
        InputProps={{ readOnly: true }}
        sx={{
          '& .MuiOutlinedInput-root': {
            '& fieldset': { borderColor: 'grey.500' },
            '&:hover fieldset': { borderColor: 'primary.main' },
          },
        }}
        InputLabelProps={{ sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
      />
    </Grid>
  )}

  {/* File Upload and Submit Button */}
  <Grid item xs={12} sm={6}>
    <TextField
      fullWidth
      type="file"
      onChange={handleFileChange}
      inputProps={{ accept: '.zip' }}
      disabled={loading}
      inputRef={fileInputRef}
      sx={{
        '& .MuiOutlinedInput-root': {
          '& fieldset': { borderColor: 'grey.500' },
          '&:hover fieldset': { borderColor: 'primary.main' },
        },
      }}
      InputLabelProps={{ sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
    />
  </Grid>

  <Grid item xs={12} sm={6} sx={{ display: 'flex', justifyContent: 'flex-end' }}>
    <Button
      variant="contained"
      color="secondary"
      sx={{ color: 'white', minWidth: 150, bgcolor: 'secondary.main', '&:hover': { bgcolor: 'secondary.dark' } }}
      disabled={!formData.caseZipFile || loading}
      onClick={handleUpload}
      startIcon={loading && <CircularProgress size={20} color="inherit" />}
    >
      {loading ? 'Uploading...' : 'Upload'}
    </Button>
  </Grid>
</Grid>


<TableContainer component={Paper} sx={{ maxHeight: 350, mt: 2 }}>
  <Table stickyHeader>
    <TableHead>
      {/* Section Header */}
      <TableRow>
        <TableCell
          colSpan={
            formData.packageProfileAlacarte === "PACKAGE"
              ? 4
              : formData.packageProfileAlacarte === "PROFILE"
              ? 4
              : 7
          }
          align="center"
          sx={{ backgroundColor: "lightskyblue", fontWeight: "bold" }}
        >
          {formData.packageProfileAlacarte === "PACKAGE" &&
            "Components In Package"}
          {formData.packageProfileAlacarte === "PROFILE" &&
            "Components In Profile"}
          {formData.packageProfileAlacarte === "A-LA-CARTE" &&
            "Select Components to Check"}
        </TableCell>
      </TableRow>

      {/* Dynamic Column Headers */}
      <TableRow sx={{ backgroundColor: "aliceblue" }}>
        

        {formData.packageProfileAlacarte === "PACKAGE" && (
          <>
          <TableCell>#</TableCell>
        <TableCell>Component Name</TableCell>
            <TableCell>Details</TableCell>
            <TableCell>Max Checks</TableCell>
          </>
        )}

        {formData.packageProfileAlacarte === "PROFILE" && (
          <>
          <TableCell>#</TableCell>
        <TableCell>Component Name</TableCell>
            <TableCell>Details</TableCell>
            <TableCell>Max Checks</TableCell>
          </>
        )}

        {formData.packageProfileAlacarte === "A-LA-CARTE" && (
          <>
          <TableCell>#</TableCell>
        <TableCell>Component Name</TableCell>
            <TableCell align="right">TAT</TableCell>
            <TableCell align="right">Rate per Check</TableCell>
            <TableCell align="center">Instructions</TableCell>
            <TableCell align="center">Max Checks</TableCell>
            <TableCell align="center">Select</TableCell>
          </>
        )}
      </TableRow>
    </TableHead>

    <TableBody>
      {/* PACKAGE Rows */}
      {formData.packageProfileAlacarte === "PACKAGE" &&
        selectedPackageDetails?.clientContractPackageComponents?.map(
          (comp, i) => (
            <TableRow key={comp.component}>
              <TableCell>{i + 1}</TableCell>
              <TableCell>{comp.componentName}</TableCell>
              <TableCell>{comp.details}</TableCell>
              <TableCell>{comp.maxChecks}</TableCell>
            </TableRow>
          )
        )}

      {/* PROFILE Rows */}
      {formData.packageProfileAlacarte === "PROFILE" &&
        selectedProfileDetails?.clientContractProfileComponents?.map(
          (comp, i) => (
            <TableRow key={comp.component}>
              <TableCell>{i + 1}</TableCell>
              <TableCell>{comp.componentName}</TableCell>
              <TableCell>{comp.details}</TableCell>
              <TableCell>{comp.maxChecks}</TableCell>
            </TableRow>
          )
        )}

      {/* A-LA-CARTE Rows */}
      {formData.packageProfileAlacarte === "A-LA-CARTE" &&
  alacarteOptions.map((item, index) => (
    <TableRow key={item._id}>
      <TableCell>{index + 1}</TableCell>
      <TableCell>{item.component.displayName}</TableCell>
      <TableCell align="right">{item.tat}</TableCell>
      <TableCell align="right">{item.price}</TableCell>

      {/* Instructions */}
      <TableCell align="center">
        <TextField
          size="small"
          value={item.instructions || ""}
          onChange={(e) => handleInstructionChange(item._id, e.target.value)}
        />
      </TableCell>

      {/* Max Checks */}
      <TableCell align="center">
        <TextField
          size="small"
          type="number"
          value={item.maxChecks || ""}
          onChange={(e) => handleMaxChecksChange(item._id, e.target.value)}
        />
      </TableCell>

      {/* Checkbox */}
      <TableCell align="center">
        <Checkbox
          checked={item.selected || false}
          disabled={
            !item.instructions ||
            item.instructions.trim() === "" ||
            !item.maxChecks ||
            item.maxChecks <= 0
          }
          onChange={(e) => handleAlacarteCheckboxChange(item._id, e.target.checked)}
        />
      </TableCell>
    </TableRow>
  ))}

    </TableBody>
  </Table>
</TableContainer>














      {/* Snackbar remains the same */}
      <Snackbar
        open={notification.open}
        autoHideDuration={3000}
        onClose={() => setNotification({ ...notification, open: false })}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Alert
          onClose={() => setNotification({ ...notification, open: false })}
          severity={notification.severity}
          sx={{ width: '100%' }}
        >
          {notification.message}
        </Alert>
      </Snackbar>

      {/* Table section remains the same */}
      {['PACKAGE', 'PROFILE', 'A-LA-CARTE'].includes(formData.packageProfileAlacarte) && (
        <Box mt={4}>
          {/* ... existing table code ... */}
        </Box>
      )}
    </Box>
  );
}


export default SingleCaseUpload;



