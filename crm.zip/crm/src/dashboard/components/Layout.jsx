// import * as React from 'react';
// import { Outlet } from 'react-router-dom';
// import { alpha } from '@mui/material/styles';
// import CssBaseline from '@mui/material/CssBaseline';
// import Box from '@mui/material/Box';
// import AppNavbar from './AppNavbar';
// import SideMenu from './SideMenu';
// import AppTheme from '../../shared-theme/AppTheme';

// import {
//   chartsCustomizations,
//   dataGridCustomizations,
//   datePickersCustomizations,
//   treeViewCustomizations,
// } from '../theme/customizations';

// const xThemeComponents = {
//   ...chartsCustomizations,
//   ...dataGridCustomizations,
//   ...datePickersCustomizations,
//   ...treeViewCustomizations,
// };

// export default function MainLayout() {
//   return (
//     <AppTheme themeComponents={xThemeComponents}>
//       <CssBaseline enableColorScheme />
//       <Box sx={{ display: 'flex' }}>
//         <AppNavbar />
//         <SideMenu />
//         <Box
//           component="main"
//           sx={(theme) => ({
//             flexGrow: 1,
//             backgroundColor: theme.vars
//               ? `rgba(${theme.vars.palette.background.defaultChannel} / 1)`
//               : alpha(theme.palette.background.default, 1),
//             overflow: 'auto',
//             marginTop: '64px', // Navbar height
//             // marginLeft: { md: '240px' }, // Sidebar width
//             padding: 3,
//           })}
//         >
//           <Box sx={{ 
//             width: '100%', 
//             maxWidth: { sm: '100%', md: '1700px' },
//             mx: 'auto'
//           }}>
//             <Outlet />
//           </Box>
//         </Box>
//       </Box>
//     </AppTheme>
//   );
// }

// import * as React from 'react';
// import { Outlet, useLocation } from 'react-router-dom';
// import { alpha } from '@mui/material/styles';
// import CssBaseline from '@mui/material/CssBaseline';
// import Box from '@mui/material/Box';
// import AppNavbar from './AppNavbar';
// import SideMenu from './SideMenu';
// import AppTheme from '../../shared-theme/AppTheme';
// import {
//   chartsCustomizations,
//   dataGridCustomizations,
//   datePickersCustomizations,
//   treeViewCustomizations,
// } from '../theme/customizations';
// import { useEffect } from 'react';
// import api from '../../auth/api';

// const drawerWidth = 240; // Define sidebar width

// const xThemeComponents = {
//   ...chartsCustomizations,
//   ...dataGridCustomizations,
//   ...datePickersCustomizations,
//   ...treeViewCustomizations,
// };

// const mainListItems = [
//   { text: 'Home', path:'/' },
//   { text: 'Cases', path:'/cases' },
//   { text: 'Insuff Client', path:'/insufClient' },
//   { text: 'Single Case Upload', path:'/singlecaseupload' },
//   { text: 'Batch Upload', path:'/batchupload'},
//   { text: 'Accept Batch', path:'/acceptbatch'},
//   { text: 'Client Tracker', path:'/clienttracker'}
// ];

// export default function MainLayout() {
//   const [user, setUser] = React.useState({})
//   const [headerName, setHeaderName] = React.useState('')
//   const location = useLocation()

//   const getUser = async () => {
//     try {
//       let response = await api.get(`/users/getmyuserid/nouserid/nouserid`)
//       if (response.data) {
//         let userName = response.data.name
//         let userId = response.data.userId
//         setUser({userName, userId}) 
//       }
//     } catch (error) {
//       console.log('err = ', error);
      
//     }
//   }

//   useEffect(() => {
//     getUser()
//   },[])

//   const getHeaderNames = () => {
//     let pathName = mainListItems.find(menu => menu.path === location.pathname)
//     if (pathName) {
//       setHeaderName(pathName.text)
//     } else {
//       setHeaderName('')
//     }
//   }

//   useEffect(() => { 
//     getHeaderNames()  
//   },[location])

//   return (
//     <AppTheme themeComponents={xThemeComponents}>
//       <CssBaseline enableColorScheme />
//       <Box sx={{ 
//         display: 'flex',
//         minHeight: '100vh',
//         flexDirection: 'column'
//       }}>
//         <AppNavbar user={user} headerName={headerName}/>

//         <Box sx={{ 
//           display: 'flex',
//           flex: 1, 
//           mt: '64px',
//         }}>
//           <Box
//             component="nav"
//             sx={{
//               width: { md: drawerWidth },
//               flexShrink: { md: 0 },
//               position: 'fixed',
//               height: 'calc(100vh - 64px)',
//               overflowY: 'auto',
//               zIndex: 1,
//             }}
//           >
//             <SideMenu user={user}/>
//           </Box>

//           <Box
//             component="main"
//             sx={(theme) => ({
//               flexGrow: 1,
//               backgroundColor: theme.vars
//                 ? `rgba(${theme.vars.palette.background.defaultChannel} / 1)`
//                 : alpha(theme.palette.background.default, 1),
//               overflow: 'auto',
//               ml: { md: `${drawerWidth}px` }, 
//               width: { md: `calc(100% - ${drawerWidth}px)` }, 
//               p: 3,
//               minHeight: 'calc(100vh - 64px)',
//             })}
//           >
//             <Box sx={{ 
//               width: '100%', 
//               maxWidth: { sm: '100%', md: '1700px' },
//               mx: 'auto'
//             }}>
//               <Outlet />
//             </Box>
//           </Box>
//         </Box>
//       </Box>
//     </AppTheme>
//   );
// }


import * as React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { alpha } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import AppNavbar from './AppNavbar';
import SideMenu from './SideMenu';
import AppTheme from '../../shared-theme/AppTheme';
import {
  chartsCustomizations,
  dataGridCustomizations,
  datePickersCustomizations,
  treeViewCustomizations,
} from '../theme/customizations';
import { useEffect } from 'react';
import api from '../../auth/api';

const drawerWidth = 240;
const collapsedWidth = 80;

const xThemeComponents = {
  ...chartsCustomizations,
  ...dataGridCustomizations,
  ...datePickersCustomizations,
  ...treeViewCustomizations,
};

const mainListItems = [
  { text: 'Home', path:'/' },
  { text: 'Cases', path:'/cases' },
  { text: 'Insuff Client', path:'/insufClient' },
  { text: 'Single Case Upload', path:'/singlecaseupload' },
  { text: 'Batch Upload', path:'/batchupload'},
  { text: 'Accept Batch', path:'/acceptbatch'},
  { text: 'Client Tracker', path:'/clienttracker' }
];

export default function MainLayout() {
  const [user, setUser] = React.useState({});
  const [headerName, setHeaderName] = React.useState('');
  const [isCollapsed, setIsCollapsed] = React.useState(false);
  const location = useLocation();

  const getUser = async () => {
    try {
      let response = await api.get(`/users/getmyuserid/nouserid/nouserid`);
      if (response.data) {
        let userName = response.data.name;
        let userId = response.data.userId;
        setUser({ userName, userId });
      }
    } catch (error) {
      console.log('err = ', error);
    }
  };

  useEffect(() => {
    getUser();
  }, []);

  const getHeaderNames = () => {
    let pathName = mainListItems.find(menu => menu.path === location.pathname);
    if (pathName) {
      setHeaderName(pathName.text);
    } else {
      setHeaderName('');
    }
  };

  useEffect(() => {
    getHeaderNames();
  }, [location]);

  return (
    <AppTheme themeComponents={xThemeComponents}>
      <CssBaseline enableColorScheme />
      <Box sx={{ display: 'flex', minHeight: '100vh', flexDirection: 'column' }}>
        <AppNavbar user={user} headerName={headerName} />
        
        <Box sx={{ display: 'flex', flex: 1, mt: '64px' }}>
          {/* Sidebar */}
          <Box
            component="nav"
            sx={{
              width: isCollapsed ? collapsedWidth : drawerWidth,
              flexShrink: 0,
              position: 'fixed',
              height: 'calc(100vh - 64px)',
              overflowY: 'auto',
              zIndex: 1,
              transition: 'width 0.3s ease'
            }}
          >
            <SideMenu user={user} isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} />
          </Box>

          {/* Main content */}
          <Box
            component="main"
            sx={(theme) => ({
              flexGrow: 1,
              backgroundColor: theme.vars
                ? `rgba(${theme.vars.palette.background.defaultChannel} / 1)`
                : alpha(theme.palette.background.default, 1),
              overflow: 'auto',
              ml: isCollapsed ? `${collapsedWidth}px` : `${drawerWidth}px`,
              width: `calc(100% - ${isCollapsed ? collapsedWidth : drawerWidth}px)`,
              transition: 'all 0.3s ease',
              p: 3,
              minHeight: 'calc(100vh - 64px)',
            })}
          >
            <Box sx={{ width: '100%', maxWidth: { sm: '100%', md: '1700px' }, mx: 'auto' }}>
              <Outlet />
            </Box>
          </Box>
        </Box>
      </Box>
    </AppTheme>
  );
}
