import React, { useEffect, useState } from 'react';
import {
  Button,
  Typography,
  Box,
  Card,
  CardContent,
  FormControl,
  InputLabel,
  MenuItem,
} from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import Select from 'react-select';
import api from '../../auth/api';
import localreportsApi from '../../auth/localreportApi';
import { saveAs } from "file-saver";

const ClientTracker = () => {
  const [selectedClient, setSelectedClient] = useState({});
  const [clients, setClients] = useState([])

  const getClients = async () => {
    try {
        let response = await api.get(`/clients`)
        if (response?.data) {
            const respData = response.data.map(item => ({
                value: item._id,
                label: item.name,
              }));
            setClients(respData);
        }
    } catch (error) {
        console.log('err == ', error);
    }
  }

  const handleClientChange = (event) => {
    setSelectedClient(event.target.value);
  };

  const handleDownload = async () => {
    if (!selectedClient) {
      return;
    }
    try {
        const response = await localreportsApi.get(`/reports/getClientTracker/${selectedClient?.value}`)
        if (response?.data) {
          console.log(response,"response data..");
          
            const reportBase64 = response.data.report;
            const byteCharacters = atob(reportBase64);
            const byteNumbers = new Array(byteCharacters.length);
            for (let i = 0; i < byteCharacters.length; i++) {
              byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            const byteArray = new Uint8Array(byteNumbers);
            const blob = new Blob([byteArray], { type: "application/pdf" });
    
            saveAs(blob, `${caseIdForDownload}.pdf`);
        }
    } catch (error) {
        console.log('error == ', error);
        
    }
  };

  useEffect(() => {
    getClients()
  },[])

  return (
    <Card variant="outlined" sx={{ maxWidth: 500, mx: "auto", mt: 5 }}>
      <CardContent>
        <Typography variant="h5" gutterBottom>
          Client Tracker
        </Typography>

        <Box sx={{ display: "flex", flexDirection: "column", gap: 3, mt: 3, height:"50vh" }}>
          <Select
            options={clients}
            value={selectedClient}
            onChange={setSelectedClient}
            placeholder="Select a client..."
            isSearchable
            isClearable
          />

          <Button
            variant="contained"
            startIcon={<DownloadIcon />}
            onClick={handleDownload}
            disabled={!selectedClient}
          >
            Download Tracker
          </Button>
        </Box>
      </CardContent>
    </Card>
  );
};

export default ClientTracker;
