// import * as React from 'react';
// import PropTypes from 'prop-types';
// import Avatar from '@mui/material/Avatar';
// import Button from '@mui/material/Button';
// import Divider from '@mui/material/Divider';
// import Drawer, { drawerClasses } from '@mui/material/Drawer';
// import Stack from '@mui/material/Stack';
// import Typography from '@mui/material/Typography';
// import LogoutRoundedIcon from '@mui/icons-material/LogoutRounded';
// import NotificationsRoundedIcon from '@mui/icons-material/NotificationsRounded';
// import MenuButton from './MenuButton';
// import MenuContent from './MenuContent';
// import CardAlert from './CardAlert';
// import { useNavigate } from 'react-router-dom';

// function SideMenuMobile({ open, toggleDrawer, user }) {
//   const navigate = useNavigate()

//   const handleLogout = async () => {
//     localStorage.clear();
//     navigate('/login')
//   }

//   return (
//     <Drawer
//       anchor="right"
//       open={open}
//       onClose={toggleDrawer(false)}
//       sx={{
//         zIndex: (theme) => theme.zIndex.drawer + 1,
//         [`& .${drawerClasses.paper}`]: {
//           backgroundImage: 'none',
//           backgroundColor: 'background.paper',
//         },
//       }}
//     >
//       <Stack
//         sx={{
//           maxWidth: '70dvw',
//           height: '100%',
//         }}
//       >
//         <Stack direction="row" sx={{ p: 2, pb: 0, gap: 1 }}>
//           <Stack
//             direction="row"
//             sx={{ gap: 1, alignItems: 'center', flexGrow: 1, p: 1 }}
//           >
//             <Avatar
//               sizes="big"
//               alt={user?.userName}
//               src="/static/images/avatar/7.jpg"
//               sx={{ width: 24, height: 24 }}
//             />
//             <Typography component="p" variant="h6">
//               {user?.userName}
//             </Typography>
//           </Stack>
//           <MenuButton showBadge>
//             <NotificationsRoundedIcon />
//           </MenuButton>
//         </Stack>
//         <Divider />
//         <Stack sx={{ flexGrow: 4 }}>
//           <MenuContent />
//           <Divider />
//         </Stack>
//         {/* <CardAlert /> */}
//         <Stack sx={{ p: 2 }}>
//           <Button variant="outlined" fullWidth startIcon={<LogoutRoundedIcon />} onClick={handleLogout}>
//             Logout
//           </Button>
//         </Stack>
//       </Stack>
//     </Drawer>
//   );
// }

// SideMenuMobile.propTypes = {
//   open: PropTypes.bool,
//   toggleDrawer: PropTypes.func.isRequired,
// };

// export default SideMenuMobile;

///new code...

// import * as React from 'react';
// import PropTypes from 'prop-types';
// import Avatar from '@mui/material/Avatar';
// import Button from '@mui/material/Button';
// import Divider from '@mui/material/Divider';
// import Drawer, { drawerClasses } from '@mui/material/Drawer';
// import Stack from '@mui/material/Stack';
// import Typography from '@mui/material/Typography';
// import LogoutRoundedIcon from '@mui/icons-material/LogoutRounded';
// import NotificationsRoundedIcon from '@mui/icons-material/NotificationsRounded';
// import MenuButton from './MenuButton';
// import MenuContent from './MenuContent';
// import CardAlert from './CardAlert';
// import { useNavigate } from 'react-router-dom';

// function SideMenuMobile({ open, toggleDrawer, user, isCollapsed }) {
//   const navigate = useNavigate();

//   const handleLogout = async () => {
//     localStorage.clear();
//     navigate('/login');
//   };

//   return (
//     <Drawer
//       anchor="right"
//       open={open}
//       onClose={toggleDrawer(false)}
//       sx={{
//         zIndex: (theme) => theme.zIndex.drawer + 1,
//         [`& .${drawerClasses.paper}`]: {
//           backgroundImage: 'none',
//           backgroundColor: 'background.paper',
//         },
//       }}
//     >
//       <Stack
//         sx={{
//           maxWidth: '70dvw',
//           height: '100%',
//         }}
//       >
//         <Stack direction="row" sx={{ p: 2, pb: 0, gap: 1 }}>
//           <Stack
//             direction="row"
//             sx={{ gap: 1, alignItems: 'center', flexGrow: 1, p: 1 }}
//           >
//             <Avatar
//               sizes="big"
//               alt={user?.userName}
//               src="/static/images/avatar/7.jpg"
//               sx={{ width: 24, height: 24 }}
//             />
//             {!isCollapsed && (
//               <Typography component="p" variant="h6">
//                 {user?.userName}
//               </Typography>
//             )}
//           </Stack>
//           <MenuButton showBadge>
//             <NotificationsRoundedIcon />
//           </MenuButton>
//         </Stack>
//         <Divider />
//         <Stack sx={{ flexGrow: 4 }}>
//           <MenuContent isCollapsed={isCollapsed} />
//           <Divider />
//         </Stack>
//         {/* <CardAlert /> */}
//         <Stack sx={{ p: 2 }}>
//           {isCollapsed ? (
//             <Button variant="outlined" onClick={handleLogout} sx={{ minWidth: 0, p: 1 }}>
//               <LogoutRoundedIcon />
//             </Button>
//           ) : (
//             <Button variant="outlined" fullWidth startIcon={<LogoutRoundedIcon />} onClick={handleLogout}>
//               Logout
//             </Button>
//           )}
//         </Stack>
//       </Stack>
//     </Drawer>
//   );
// }

// SideMenuMobile.propTypes = {
//   open: PropTypes.bool,
//   toggleDrawer: PropTypes.func.isRequired,
//   isCollapsed: PropTypes.bool, // added prop validation
// };

// export default SideMenuMobile;



import * as React from 'react';
import PropTypes from 'prop-types';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import Divider from '@mui/material/Divider';
import Drawer, { drawerClasses } from '@mui/material/Drawer';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import LogoutRoundedIcon from '@mui/icons-material/LogoutRounded';
import NotificationsRoundedIcon from '@mui/icons-material/NotificationsRounded';
import IconButton from '@mui/material/IconButton';
import Tooltip from '@mui/material/Tooltip';
import MenuButton from './MenuButton';
import MenuContent from './MenuContent';
import CardAlert from './CardAlert';
import { useNavigate } from 'react-router-dom';

function SideMenuMobile({ open, toggleDrawer, user, isCollapsed }) {
  const navigate = useNavigate();

  const handleLogout = async () => {
    localStorage.clear();
    navigate('/login');
  };

  return (
    <Drawer
      anchor="right"
      open={open}
      onClose={toggleDrawer(false)}
      sx={{
        zIndex: (theme) => theme.zIndex.drawer + 1,
        [`& .${drawerClasses.paper}`]: {
          backgroundImage: 'none',
          backgroundColor: 'background.paper',
        },
      }}
    >
      <Stack
        sx={{
          maxWidth: '70dvw',
          height: '100%',
        }}
      >
        <Stack direction="row" sx={{ p: 2, pb: 0, gap: 1 }}>
          <Stack
            direction="row"
            sx={{ gap: 1, alignItems: 'center', flexGrow: 1, p: 1 }}
          >
            <Avatar
              sizes="big"
              alt={user?.userName}
              src="/static/images/avatar/7.jpg"
              sx={{ width: 24, height: 24 }}
            />
            {!isCollapsed && (
              <Typography component="p" variant="h6">
                {user?.userName}
              </Typography>
            )}
          </Stack>

          {/* Notifications Button */}
          <MenuButton showBadge>
            <NotificationsRoundedIcon />
          </MenuButton>

          {/* Logout IconButton at top */}
          <Tooltip title="Logout">
            <IconButton onClick={handleLogout} sx={{ p: 1 }}>
              <LogoutRoundedIcon />
            </IconButton>
          </Tooltip>
        </Stack>

        <Divider />

        <Stack sx={{ flexGrow: 4 }}>
          <MenuContent isCollapsed={isCollapsed} />
          <Divider />
        </Stack>

        {/* <CardAlert /> */}

        <Stack sx={{ p: 2 }}>
          {isCollapsed ? (
            <Button variant="outlined" onClick={handleLogout} sx={{ minWidth: 0, p: 1 }}>
              <LogoutRoundedIcon />
            </Button>
          ) : (
            <Button variant="outlined" fullWidth startIcon={<LogoutRoundedIcon />} onClick={handleLogout}>
              Logout
            </Button>
          )}
        </Stack>
      </Stack>
    </Drawer>
  );
}

SideMenuMobile.propTypes = {
  open: PropTypes.bool,
  toggleDrawer: PropTypes.func.isRequired,
  isCollapsed: PropTypes.bool,
  user: PropTypes.object,
};

export default SideMenuMobile;





