// import { useEffect, useState } from "react";
// import { Card, CardContent, Typography, CircularProgress, Box, Stack } from "@mui/material";
// import { PieChart } from "@mui/x-charts/PieChart";
// import api from "../../auth/api";

// const ClientCaseBreak = () => {
//   const [countData, setCountData] = useState({});
//   const [loading, setLoading] = useState(true);

//   const getClientCaseData = async () => {
//     setLoading(true);
//     try {
//       const response = await api.get(`/cases/getCasesBreakdown`);
//       console.log("Case Breakdown Data:", response.data);
//       setCountData(response.data);
//     } catch (error) {
//       console.error("Error fetching client case data:", error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     getClientCaseData();
//   }, []);

//   const pieChartData = [
//     {
//       id: 0,
//       value: countData.greenCasesCount || 0,
//       label: "Green",
//       color: "#080",
//     },
//     {
//       id: 1,
//       value: countData.redCasesCount || 0,
//       label: "Red",
//       color: "#F00",
//     },
//     {
//       id: 2,
//       value: countData.amberCasesCount || 0,
//       label: "Amber",
//       color: "#FFBF00",
//     },
//   ];

//   return (
//     <Card variant="outlined" sx={{ height: "350px" }}>
//       <CardContent>
//         <Typography variant="h6" gutterBottom>
//           Client Case Breakdown
//         </Typography>

//         {loading ? (
//           <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
//             <CircularProgress />
//           </Box>
//         ) : (
//           <Stack alignItems="center" spacing={2}>
//             <PieChart
//               series={[
//                 {
//                   data: pieChartData,
//                   innerRadius: 0,  // reduced for thinner slices
//                   outerRadius: 80,  // reduced for smaller chart
//                   paddingAngle: 1,
//                   cornerRadius: 2,
//                 },
//               ]}
//               width={280} 
//               height={280} 
//               colors={pieChartData.map((item) => item.color)}
//             />
//           </Stack>
//         )}
//       </CardContent>
//     </Card>
//   );
// };

// export default ClientCaseBreak;

import { useEffect, useState } from "react";
import { Card, CardContent, Typography, CircularProgress, Box, Stack } from "@mui/material";
import { PieChart } from "@mui/x-charts/PieChart";
import api from "../../auth/api";

const ClientCaseBreak = () => {
  const [countData, setCountData] = useState({});
  const [loading, setLoading] = useState(true);

  const getClientCaseData = async () => {
    setLoading(true);
    try {
      const response = await api.get(`/cases/getCasesBreakdown`);
      console.log("Case Breakdown Data:", response.data);
      setCountData(response.data);
    } catch (error) {
      console.error("Error fetching client case data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getClientCaseData();
  }, []);

  const pieChartData = [
    {
      id: 0,
      value: countData.greenCasesCount || 0,
      label: `Green (${countData.greenCasesCount || 0})`,
      color: "#22c55e",
    },
    {
      id: 1,
      value: countData.redCasesCount || 0,
      label: `Red (${countData.redCasesCount || 0})`,
      color: "#ef4444",
    },
    {
      id: 2,
      value: countData.amberCasesCount || 0,
      label: `Amber (${countData.amberCasesCount || 0})`,
      color: "#f59e0b",
    },
  ];

  return (
    // <Card
    //   variant="outlined"
    //   sx={{
    //     width: "100%",
    //     height: "100%",
    //     display: "flex",
    //     flexDirection: "column",
    //     // bgcolor: "background.paper",
    //      backgroundColor: '#fdfafdff',
    //     boxShadow: 3,
    //     borderRadius: 1,
    //   }}
    // >
    //   <CardContent
    //     sx={{
    //       p: 3,
    //       flexGrow: 1,
    //       display: "flex",
    //       flexDirection: "column",
    //     }}
    //   >
       <Card variant="outlined" sx={{ width: '100%',height: "100%", backgroundColor: '#fdfafdff' }}>
          <CardContent>
        <Typography component="h2" variant="subtitle1" gutterBottom sx={{ color: '#black' }}>
          Client Case Breakdown
        </Typography>

        {loading ? (
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              flexGrow: 1,
            }}
          >
            <CircularProgress size={40} sx={{ color: "primary.main" }} />
          </Box>
        ) : (
          <Stack
            direction="column"
            alignItems="center"
            spacing={2}
            sx={{ flexGrow: 1, justifyContent: "center" }}
          >
            <Box sx={{ display: "flex", justifyContent: "center" }}>
              <PieChart
                series={[
                  {
                    data: pieChartData,
                    innerRadius: 30,
                    outerRadius: 100,
                    paddingAngle: 2,
                    cornerRadius: 5,
                    highlightScope: { faded: "global", highlighted: "item" },
                    faded: { innerRadius: 30, additionalRadius: -10, color: "gray" },
                  },
                ]}
                width={300}
                height={200}
                slotProps={{
                  legend: { hidden: true }, // Hide default legend
                }}
              />
            </Box>
            <Stack
              direction="row"
              spacing={2}
              sx={{ justifyContent: "center", mt: 2 }}
            >
              {pieChartData.map((item) => (
                <Box
                  key={item.id}
                  sx={{ display: "flex", alignItems: "center", gap: 1 }}
                >
                  <Box
                    sx={{
                      width: 12,
                      height: 12,
                      borderRadius: "50%",
                      bgcolor: item.color,
                    }}
                  />
                  <Typography
                    variant="body2"
                    sx={{ color: "text.secondary", fontSize: "0.875rem" }}
                  >
                    {item.label}
                  </Typography>
                </Box>
              ))}
            </Stack>
          </Stack>
        )}
      </CardContent>
    </Card>
  );
};

export default ClientCaseBreak;