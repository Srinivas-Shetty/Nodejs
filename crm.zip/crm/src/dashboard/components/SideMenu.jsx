// import * as React from 'react';
// import { styled } from '@mui/material/styles';
// import Avatar from '@mui/material/Avatar';
// import MuiDrawer, { drawerClasses } from '@mui/material/Drawer';
// import Box from '@mui/material/Box';
// import Stack from '@mui/material/Stack';
// import Typography from '@mui/material/Typography';
// import MenuContent from './MenuContent';
// import OptionsMenu from './OptionsMenu';

// const drawerWidth = 240;

// const Drawer = styled(MuiDrawer)({
//   width: drawerWidth,
//   flexShrink: 0,
//   boxSizing: 'border-box',
//   mt: 10,
//   [`& .${drawerClasses.paper}`]: {
//     width: drawerWidth,
//     boxSizing: 'border-box',
//     top: 64,
//     height: 'calc(100vh - 64px)',
//   },
// });

// export default function SideMenu({user}) {
//   return (
//     <Drawer
//       variant="permanent"
//       sx={{
//         display: { xs: 'none', md: 'block' },
//         [`& .${drawerClasses.paper}`]: {
//           backgroundColor: 'background.paper',
//         },
//         top: 64,
//       }}
//     >
//       <Box
//         sx={{
//           overflow: 'auto',
//           height: '100%',
//           display: 'flex',
//           flexDirection: 'column',
//         }}
//       >
//         <MenuContent />
//       </Box>
//       <Stack
//         direction="row"
//         sx={{
//           p: 2,
//           gap: 1,
//           alignItems: 'center',
//           borderTop: '1px solid',
//           borderColor: 'divider',
//         }}
//       >
//         <Avatar
//           sizes="small"
//           alt={user?.userName}
//           src="/static/images/avatar/7.jpg"
//           sx={{ width: 36, height: 36 }}
//         />
//         <Box sx={{ mr: 'auto' }}>
//           <Typography variant="body2" sx={{ fontWeight: 500, lineHeight: '16px' }}>
//            {user?.userName}
//           </Typography>
//           <Typography variant="caption" sx={{ color: 'text.secondary' }}>
//             {user?.userId}
//           </Typography>
//         </Box>
//         <OptionsMenu />
//       </Stack>
//     </Drawer>
//   );
// }




//// new caode colpse

import * as React from 'react';
import { styled } from '@mui/material/styles';
import Avatar from '@mui/material/Avatar';
import MuiDrawer, { drawerClasses } from '@mui/material/Drawer';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import MenuContent from './MenuContent';
import OptionsMenu from './OptionsMenu';

const drawerWidth = 240;
const collapsedWidth = 80;

const Drawer = styled(MuiDrawer)(({ theme }) => ({
  flexShrink: 0,
  whiteSpace: 'nowrap',
  boxSizing: 'border-box',
  [`& .${drawerClasses.paper}`]: {
    top: 64,
    height: 'calc(100vh - 64px)',
    overflowX: 'hidden',
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.standard,
    }),
  },
}));

export default function SideMenu({ user, isCollapsed, setIsCollapsed }) {
// export default function SideMenu({ user }) {
  // const [isCollapsed, setIsCollapsed] = React.useState(true);

  // const handleMouseEnter = () => setIsCollapsed(false);
  // const handleMouseLeave = () => setIsCollapsed(true);


const handleMouseEnter = () => setIsCollapsed(false);
const handleMouseLeave = () => setIsCollapsed(true);
  // return (
  //   <Drawer
  //     variant="permanent"
  //     onMouseEnter={handleMouseEnter}
  //     onMouseLeave={handleMouseLeave}
  //     sx={{
  //       width: isCollapsed ? collapsedWidth : drawerWidth,
  //       [`& .${drawerClasses.paper}`]: {
  //         width: isCollapsed ? collapsedWidth : drawerWidth,
  //         backgroundColor: 'background.paper',
  //       },
  //       display: { xs: 'none', md: 'block' },
  //     }}
  //   >
  //     <Box
  //       sx={{
  //         overflow: 'auto',
  //         height: '100%',
  //         display: 'flex',
  //         flexDirection: 'column',
  //       }}
  //     >
  //       <MenuContent isCollapsed={isCollapsed} /> {/* pass state as prop */}
  //     </Box>

  //     <Stack
  //       direction="row"
  //       sx={{
  //         p: 2,
  //         gap: 1,
  //         alignItems: 'center',
  //         borderTop: '1px solid',
  //         borderColor: 'divider',
  //         justifyContent: isCollapsed ? 'center' : 'flex-start',
  //       }}
  //     >
  //       <Avatar
  //         sizes="small"
  //         alt={user?.userName}
  //         src="/static/images/avatar/7.jpg"
  //         sx={{ width: 36, height: 36 }}
  //       />
  //       {!isCollapsed && (
  //         <Box sx={{ mr: 'auto' }}>
  //           <Typography variant="body2" sx={{ fontWeight: 500, lineHeight: '16px' }}>
  //             {user?.userName}
  //           </Typography>
  //           <Typography variant="caption" sx={{ color: 'text.secondary' }}>
  //             {user?.userId}
  //           </Typography>
  //         </Box>
  //       )}
  //       {!isCollapsed && <OptionsMenu />}
  //     </Stack>
  //   </Drawer>
  // );

return (
    <Drawer
      variant="permanent"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      sx={{
        width: isCollapsed ? collapsedWidth : drawerWidth,
        [`& .${drawerClasses.paper}`]: {
          width: isCollapsed ? collapsedWidth : drawerWidth,
          backgroundColor: 'background.paper',
        },
        display: { xs: 'none', md: 'block' },
      }}
    >
      <Box
        sx={{
          overflow: 'auto',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <MenuContent isCollapsed={isCollapsed} />
      </Box>

      <Stack
        direction="row"
        sx={{
          p: 2,
          gap: 1,
          alignItems: 'center',
          borderTop: '1px solid',
          borderColor: 'divider',
          justifyContent: isCollapsed ? 'center' : 'flex-start',
        }}
      >
        <Avatar
          sizes="small"
          alt={user?.userName}
          src="/static/images/avatar/7.jpg"
          sx={{ width: 36, height: 36 }}
        />
        {!isCollapsed && (
          <Box sx={{ mr: 'auto' }}>
            <Typography variant="body2" sx={{ fontWeight: 500, lineHeight: '16px' }}>
              {user?.userName}
            </Typography>
            <Typography variant="caption" sx={{ color: 'text.secondary' }}>
              {user?.userId}
            </Typography>
          </Box>
        )}
        {!isCollapsed && <OptionsMenu />}
      </Stack>
    </Drawer>
  );
}

