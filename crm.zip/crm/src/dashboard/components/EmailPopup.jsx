import React, { useState } from "react";
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  Select,
  FormControl,
  Snackbar,
  Alert,
  Stack,
  Chip,
} from "@mui/material";
import axios from "axios";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import api from "../../auth/api";

export default function EmailPopup() {
  const [open, setOpen] = useState(false);
  const [type, setType] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [files, setFiles] = useState([]);

  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  const handleClickOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const handleSnackbarClose = () => setSnackbar({ ...snackbar, open: false });

  const handleFileSelect = (e) => {
    const selectedFiles = Array.from(e.target.files);
    setFiles((prev) => [...prev, ...selectedFiles]);
    e.target.value = null;
  };

  const handleFileDelete = (fileToDelete) => {
    setFiles((prev) => prev.filter((file) => file !== fileToDelete));
  };

  const handleSubmit = async () => {
    let toEmail = "";
    if (type === "CAM") {
      toEmail = "ebrahim@adamma.in";
    } else if (type === "Escalations") {
      toEmail = "nithyanandan@adamma.in";
    }

    if (!toEmail) {
      setSnackbar({
        open: true,
        message: "Please select CAM or Escalations",
        severity: "warning",
      });
      return;
    }

    const formData = new FormData();
    formData.append("to", toEmail);
    formData.append("from", "info@adamma.in");
    formData.append("subject", subject);
    formData.append("body", body);
    files.forEach((file) => formData.append("attachments", file));

    try {
      await api.post("/dashboardData/send-mail-crm-esc", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      setSnackbar({
        open: true,
        message: "Email sent successfully!",
        severity: "success",
      });
      handleClose();
      setType("");
      setSubject("");
      setBody("");
      setFiles([]);
    } catch (err) {
      setSnackbar({
        open: true,
        message: "Failed to send email.",
        severity: "error",
      });
    }
  };

  return (
    <div>
      <Button
        variant="contained"
        color="primary"
        onClick={handleClickOpen}
      >
        Email...
      </Button>

      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="sm">
        <DialogTitle>Send Email</DialogTitle>
        <DialogContent sx={{ pt: 2 }}>
          <FormControl fullWidth sx={{ mb: 2 }}>
            <Select
              value={type}
              onChange={(e) => setType(e.target.value)}
              displayEmpty
              renderValue={(selected) => {
                if (!selected) {
                  return <em>Select To</em>;
                }
                return selected;
              }}
            >
              <MenuItem value="CAM">CAM</MenuItem>
              <MenuItem value="Escalations">Escalations</MenuItem>
            </Select>
          </FormControl>

          <TextField
            placeholder="Subject"
            fullWidth
            variant="outlined"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            sx={{ mb: 2 }}
          />

          <div style={{ marginBottom: "48px" }}>
            <ReactQuill
              theme="snow"
              value={body}
              onChange={setBody}
              placeholder="Write your message..."
              style={{ height: "200px" }}
              modules={{
                toolbar: [
                  ["bold", "italic", "underline"],
                  [{ list: "ordered" }, { list: "bullet" }],
                  ["link"],
                  ["clean"],
                ],
              }}
            />
          </div>

          <div style={{ marginTop: "16px", marginBottom: "16px" }}>
            <input
              id="file-input"
              type="file"
              multiple
              style={{ display: "none" }}
              onChange={handleFileSelect}
            />
            <label htmlFor="file-input">
              <Button variant="outlined" component="span" sx={{ width: "100%" }}>
                Attach Files
              </Button>
            </label>

            {files.length > 0 && (
              <Stack direction="row" flexWrap="wrap" spacing={1} sx={{ mt: 2 }}>
                {files.map((file, index) => (
                  <Chip
                    key={index}
                    label={file.name}
                    onDelete={() => handleFileDelete(file)}
                    color="primary"
                    variant="outlined"
                  />
                ))}
              </Stack>
            )}
          </div>
        </DialogContent>

        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button variant="contained" onClick={handleSubmit}>
            Send
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={handleSnackbarClose}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        <Alert
          severity={snackbar.severity}
          onClose={handleSnackbarClose}
          sx={{ width: "100%" }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </div>
  );
}