
import { useState, useEffect, useMemo } from 'react';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import { Button, TextField, Typography, FormControl, InputLabel, Select,  MenuItem, Autocomplete } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import api from '../../auth/api';
import CaseDetailsModal from './CaseDetailsModal';
import Swal from 'sweetalert2';
import { Snackbar, Alert } from '@mui/material';

const columns = [
    { 
      field: 'serialNumber', 
      headerName: 'Sl.No', 
      flex: 1, 
      minWidth: 60 ,
      cellClassName: 'wrap-text',
    },
    { 
      field: 'caseId', 
      headerName: 'Case ID', 
      flex: 1, 
      minWidth: 120,
      cellClassName: 'wrap-text',
    },
    { 
      field: 'candidateName', 
      headerName: 'Candidate Name', 
      flex: 1.5, 
      minWidth: 150,
      cellClassName: 'wrap-text',
    },
    { 
      field: 'employeeId', 
      headerName: 'Employee ID', 
      flex: 1, 
      minWidth: 130,
      cellClassName: 'wrap-text',
    },
    { 
      field: 'clientName', 
      headerName: 'Client Name', 
      flex: 1, 
      minWidth: 180,
      cellClassName: 'wrap-text',
    },
    { 
      field: 'subclientName', 
      headerName: 'Subclient Name', 
      flex: 1, 
      minWidth: 180,
      cellClassName: 'wrap-text',
    },
    { 
      field: 'initiationDate', 
      headerName: 'Initiation Date', 
      flex: 1, 
      minWidth: 150,
      cellClassName: 'wrap-text', 
      renderCell: (params) => new Date(params.value).toLocaleDateString(),  // Example of date formatting
    },
    { 
      field: 'tatEndDate', 
      headerName: 'TAT End Date', 
      flex: 1, 
      minWidth: 150,
      cellClassName: 'wrap-text', 
      renderCell: (params) => new Date(params.value).toLocaleDateString(),
    },
    // { 
    //   field: 'pendingcomponents', 
    //   headerName: 'Pending Components', 
    //   flex: 1,
    //   minWidth: 150,
    //   cellClassName: 'wrap-text', 
    // },
   {
    field: "gradeColor",
    headerName: "Grade",
    width: 80,
    sortable: false,
    renderCell: (params) => (
      <div
        style={{
          marginTop:'10px',
          width: "30px",
          height: "10px",
          borderRadius: "3px",
          backgroundColor: params.value || "transparent",
        }}
      />
    ),
  },
    { 
      field: 'displayStatus', 
      headerName: 'Display Status', 
      flex: 1, 
      minWidth: 150,
      cellClassName: 'wrap-text', 
      renderCell: (params) => <span>{params.value}</span>, // You can apply custom formatting here if needed
    },
    { 
      field: 'completionDate', 
      headerName: 'Completion Date', 
      flex: 1, 
      minWidth: 150,
      cellClassName: 'wrap-text', 
      renderCell: (params) => new Date(params.value).toLocaleDateString(),
    }
  ];
  
function Cases() {
    const [cases, setCases] = useState([])
    const [caseId, setCaseId] = useState('')

    const [requiredCases, setRequiredCases] = useState('-1');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [nameSearchValue, setNameSearchValue] = useState('');
    const [initiationStartDate, setInitiationStartDate] = useState('');
    const [initiationEndDate, setInitiationEndDate] = useState('');
    const [requiredClient, setRequiredClient] = useState(null);
    const [clients, setClients] = useState([]);
    const [inputValue, setInputValue] = useState('');
    const [loading, setLoading] = useState(false)
  

    const [selectedCase, setSelectedCase] = useState(null);
    const [modalOpen, setModalOpen] = useState(false)

    const [notification, setNotification] = useState({ open: false, message: '', severity: 'success' });

    const handleRowClick = (params) => {
        setSelectedCase(params.row);
        setModalOpen(true);
    };

    const handleCloseModal = () => {
        setModalOpen(false);
    };

    const handlecaseType = (e) => {
      if (e.target.value === 'PENDING') {
        searchPendingCases()
      }
      setRequiredCases(e.target.value)
    }

  useEffect(() => {
    api.get('/usersubclientaccess')
      .then((response) => {
        const newClients = [];

        response.data.forEach((item) => {
          const clientId = item.subclient.client._id;
          const existing = clients.find(c => c._id === clientId);

          if (!existing) {
            newClients.push({
              _id: clientId,
              name: item.subclient.client.name,
            });
          }
        });

        setClients(prev => [...prev, ...newClients]);
      })
      .catch((err) => {
        console.log('error  == ', err);
      });
      
  }, []);

  const filteredOptions = useMemo(() => {
    const lowercased = inputValue.toLowerCase();
    return clients.filter(client =>
      client.name.toLowerCase().includes(lowercased)
    );
  }, [clients, inputValue]);

  const displayFn = (client) => client?.name || '';

  const searchPendingCases = async () => {
    let pageCount = 0;
    let clientId = requiredClient?._id || '-';
    setLoading(true)
    try {
      const response = await api.get(`/cases/pendingcases/${clientId}?pageCount=${pageCount}`);
  
      if (response.data) {
        const respArr = response.data.resp || [];
  
        const modifiedRes = respArr.map((item, index) => {
          const employeeId = item.personalDetails?.[0]?.empid || item.employeeId || '';
  
          let displayStatus = 'Pending';
          if (item.status === 'OUTPUTQC-ACCEPTED') {
            displayStatus = 'Completed';
          } else if (item.status === 'DELETED-CASE') {
            displayStatus = 'Deleted';
          }
  
          return {
            id: item._id,
            serialNumber: index + 1,
            caseId: item.caseId,
            candidateName: item.candidateName,
            employeeId,
            clientName: item.subclient.client.name,
            subclientName: item.subclient.name,
            initiationDate: item.initiationDate,
            tatEndDate: item.tatEndDate,
            displayStatus,
            pendingComponentsCount: item.pendingComponentsCount,
            completionDate: null,
            details: 'Case details placeholder',
            gradeColor: item.grade?.colorCode || null,
  gradeName: item.grade?.name || "", 
          };
        });
  
        console.log("modifiedRes == ", modifiedRes);
  
        setCases(modifiedRes); 
        setLoading(false)
      }
    } catch (error) {
      console.log('Error fetching pending cases', error);
    } finally{
      setLoading(false)
    }
  };
  
  const searchByCompletionDate = async () => {
    if (!startDate || !endDate) {
      // alert('Both Start Date and End Date are mandatory');

//       Swal.fire({
//   icon: 'warning',
//   title: 'Missing Dates',
//   text: 'Both Start Date and End Date are mandatory',
// });
setNotification({ open: true, message: 'Both Start Date and End Date are mandatory.', severity: 'error' });
      return;
    }
  
    let pageCount = 0
    const clientId = requiredClient?._id || '-';
  
    try {
      setLoading(true);
      const response = await api.get(`/cases/searchbycompletiondate/datefrom${startDate}/dateto/${endDate}/${clientId}?pageCount=${pageCount}`);
      const { totalCount, resp } = response.data;
      const caseList = resp.map((item, index) => {
        let displayStatus = 'Pending';
        if (item.status === 'OUTPUTQC-ACCEPTED') {
          displayStatus = 'Completed';
        } else if (item.status === 'DELETED-CASE') {
          displayStatus = 'Deleted';
        }
  
        return {
          id: item._id,
          serialNumber: index + 1,
          caseId: item.caseId,
          candidateName: item.candidateName,
          clientName: item.subclient.client.name,
          subclientName: item.subclient.name,
          initiationDate: item.initiationDate,
          tatEndDate: item.tatEndDate,
          displayStatus,
          status: item.status,
          pendingComponentsCount: item.pendingComponentsCount,
          employeeId: item.personalDetails?.[0]?.empid || item.employeeId || '',
           gradeColor: item.grade?.colorCode || null,
  gradeName: item.grade?.name || "", 
        };
      });
  
      setCases(caseList);
    } catch (err) {
      console.log('Error fetching completed cases', err);
    } finally {
      setLoading(false);
    }
  };

  const searchByInitiationDate = async () => {
    if (!initiationStartDate) {
      // alert('Enter Initiation Date');

//       Swal.fire({
//   icon: 'warning',
//   title: 'Missing Date',
//   text: 'Please enter an Initiation Start Date.',
// });
 setNotification({ open: true, message: 'Please enter an Initiation Start Date.', severity: 'error' });
      return;
    }
  
    let pageCount = 0
    const clientId = requiredClient?._id || '-';
  
    try {
      setLoading(true);
      const response = await api.get(`/cases/searchbyinitiationdate/datefrom/${initiationStartDate}/dateto/${initiationEndDate}/${clientId}?pageCount=${pageCount}`);
      const { totalCount, resp } = response.data;
      const caseList = resp.map((item, index) => {
        let displayStatus = 'Pending';
        if (item.status === 'OUTPUTQC-ACCEPTED') {
          displayStatus = 'Completed';
        } else if (item.status === 'DELETED-CASE') {
          displayStatus = 'Deleted';
        }
  
        return {
          id: item._id,
          serialNumber: index + 1,
          caseId: item.caseId,
          candidateName: item.candidateName,
          clientName: item.subclient.client.name,
          subclientName: item.subclient.name,
          initiationDate: item.initiationDate,
          tatEndDate: item.tatEndDate,
          displayStatus,
          status: item.status,
          pendingComponentsCount: item.pendingComponentsCount,
          employeeId: item.personalDetails?.[0]?.empid || item.employeeId || '',
           gradeColor: item.grade?.colorCode || null,
  gradeName: item.grade?.name || "", 
        };
      });
  
      setCases(caseList);
    } catch (err) {
      console.log('Error fetching initiation cases', err);
    } finally {
      setLoading(false);
    }
  };

  const searchByName = async () => {
    if (!nameSearchValue) {
      // alert('Type a name to search for');

//       Swal.fire({
//   icon: 'info',
//   title: 'Candidate Name Required',
//   text: 'Please type a name to search.',
// });

 setNotification({ open: true, message: 'Please type a name to search.', severity: 'error' });

      return;
    }
  
    let pageCount = 0
    const clientId = requiredClient?._id || '-';
  
    try {
      setLoading(true);
      const response = await api.get(`/cases/searchbyname/candidatename/${nameSearchValue}?pageCount=${pageCount}`);
  
      const { totalCount, resp } = response.data;
      const caseList = resp.map((item, index) => {
        let displayStatus = 'Pending';
        if (item.status === 'OUTPUTQC-ACCEPTED') {
          displayStatus = 'Completed';
        } else if (item.status === 'DELETED-CASE') {
          displayStatus = 'Deleted';
        }
  
        return {
          id: item._id,
          serialNumber: index + 1,
          caseId: item.caseId,
          candidateName: item.candidateName,
          clientName: item.subclient.client.name,
          subclientName: item.subclient.name,
          initiationDate: item.initiationDate,
          tatEndDate: item.tatEndDate,
          displayStatus,
          status: item.status,
          pendingComponentsCount: item.pendingComponentsCount,
          employeeId: item.personalDetails?.[0]?.empid || item.employeeId || '',
           gradeColor: item.grade?.colorCode || null,
  gradeName: item.grade?.name || "", 
        };
      });
  
      setCases(caseList);
    } catch (err) {
      console.log('Error fetching search by name cases', err);
    } finally {
      setLoading(false);
    }
  };
  
  const handleExport = () => {
    // Implement export to Excel logic
  };

  const handleSearch = async () => {
      let pageCount = 0
      try {
          let response = await api.get(`/cases/searchbycaseid/caseid/${caseId}?pageCount=${pageCount}`)
          if (response.data) {
              let respArr = response.data.resp 
              let modifiedRes = respArr.map((resp, index) => {
                  return  {
                      id: resp?._id,
                      serialNumber: index + 1,
                      caseId: resp?.caseId,
                      candidateName: resp?.candidateName,
                      employeeId: 'EMP003',
                      clientName: resp?.subclient?.client?.name,
                      subclientName: resp?.subclient?.name,
                      initiationDate: resp?.initiationDate,
                      tatEndDate: resp?.tatEndDate,
                      pendingcomponents: 'Component 4, Component 5, Component 6',
                      displayStatus: resp?.status,
                      completionDate: null,
                      details: 'Information regarding the third case.',
                       gradeColor: resp.grade?.colorCode || null,
  gradeName: resp.grade?.name || "", 
                    }
              })
              console.log("modifiedRes == ", modifiedRes);
              
              setCases(modifiedRes)
          }
      } catch (error) {
          console.log('error == ', error);
      }
  }

  return (
    <Box
      sx={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        px: 3,
      }}
    >
      <Box
        sx={{
          width: "100%",
          maxWidth: "1700px",
          height: "100%",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <Typography component="h2" variant="h6" sx={{ mb: 2 }}>
          Case Details
        </Typography>
 

<Box display="flex" alignItems="center" gap={2} flexWrap="wrap">
  <FormControl sx={{ minWidth: 200, marginRight: 2 }} variant="outlined">
    <InputLabel id="required-cases-label" sx={{ bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' }}>
      Show Cases that are
    </InputLabel>
    <Select
      labelId="required-cases-label"
      value={requiredCases}
      label="Show Cases that are"
      onChange={handlecaseType}
      sx={{ '& .MuiOutlinedInput-notchedOutline': { borderColor: 'grey.500' } }}
    >
      <MenuItem value="-1">Select One</MenuItem>
      <MenuItem value="PENDING">Pending</MenuItem>
      <MenuItem value="COMPLETED">Completed</MenuItem>
      <MenuItem value="NAME-SEARCH">Search by name</MenuItem>
      <MenuItem value="INITIATION-DATE">Search by Initiation Date</MenuItem>
      <MenuItem value="CASE-ID">Search by Case Id</MenuItem>
    </Select>
  </FormControl>

  {/* PENDING CASES */}
  {requiredCases === "PENDING" && (
    <Button variant="contained" onClick={searchPendingCases} sx={{ bgcolor: 'primary.main', '&:hover': { bgcolor: 'primary.dark' } }}>
      Fetch
    </Button>
  )}

  {/* COMPLETED: Start and End Date */}
  {requiredCases === "COMPLETED" && (
    <Box display="flex" gap={2} alignItems="center">
      <TextField
        label="Start Date"
        type="date"
        value={startDate}
        onChange={(e) => setStartDate(e.target.value)}
        InputLabelProps={{ shrink: true, sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
        sx={{ '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: 'grey.500' }, '&:hover fieldset': { borderColor: 'primary.main' } } }}
      />
      <TextField
        label="End Date"
        type="date"
        value={endDate}
        onChange={(e) => setEndDate(e.target.value)}
        InputLabelProps={{ shrink: true, sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
        sx={{ '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: 'grey.500' }, '&:hover fieldset': { borderColor: 'primary.main' } } }}
      />
      <Button
        variant="contained"
        onClick={() => searchByCompletionDate()}
        sx={{ bgcolor: 'primary.main', '&:hover': { bgcolor: 'primary.dark' } }}
      >
        Fetch
      </Button>
    </Box>
  )}

  {/* NAME-SEARCH */}
  {requiredCases === "NAME-SEARCH" && (
    <Box display="flex" alignItems="center" gap={2}>
      <TextField
        label="Provide a Candidate Name to Search"
        value={nameSearchValue}
        onChange={(e) => setNameSearchValue(e.target.value)}
        InputLabelProps={{ sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
        sx={{ '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: 'grey.500' }, '&:hover fieldset': { borderColor: 'primary.main' } } }}
      />
      <Button variant="contained" onClick={() => searchByName()} sx={{ bgcolor: 'primary.main', '&:hover': { bgcolor: 'primary.dark' } }}>
        Fetch
      </Button>
    </Box>
  )}

  {/* INITIATION-DATE */}
  {requiredCases === "INITIATION-DATE" && (
    <Box display="flex" alignItems="center" gap={2}>
      <TextField
        label="Initiation Start Date"
        type="date"
        value={initiationStartDate}
        onChange={(e) => setInitiationStartDate(e.target.value)}
        InputLabelProps={{ shrink: true, sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
        sx={{ '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: 'grey.500' }, '&:hover fieldset': { borderColor: 'primary.main' } } }}
      />
      <TextField
        label="Initiation End Date"
        type="date"
        value={initiationEndDate}
        onChange={(e) => setInitiationEndDate(e.target.value)}
        InputLabelProps={{ shrink: true, sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
        sx={{ '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: 'grey.500' }, '&:hover fieldset': { borderColor: 'primary.main' } } }}
      />
      <Button
        variant="contained"
        onClick={() => searchByInitiationDate()}
        sx={{ bgcolor: 'primary.main', '&:hover': { bgcolor: 'primary.dark' } }}
      >
        Fetch
      </Button>
    </Box>
  )}

  {/* CASE-ID */}
  {requiredCases === "CASE-ID" && (
    <Box display="flex" alignItems="center" gap={2}>
      <TextField
        label="Provide a Case Id to Search"
        value={caseId}
        onChange={(e) => setCaseId(e.target.value)}
        InputLabelProps={{ sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
        sx={{ '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: 'grey.500' }, '&:hover fieldset': { borderColor: 'primary.main' } } }}
      />
      <Button variant="contained" onClick={() => handleSearch()} sx={{ bgcolor: 'primary.main', '&:hover': { bgcolor: 'primary.dark' } }}>
        Fetch
      </Button>
    </Box>
  )}

  {/* Autocomplete Client Filter */}
  <Box sx={{ marginTop: 0.3, minWidth: 300 }}>
    <Autocomplete
      value={requiredClient}
      onChange={(e, newValue) => setRequiredClient(newValue)}
      options={filteredOptions}
      getOptionLabel={(option) => option.name}
      renderInput={(params) => (
        <TextField
          {...params}
          label="Apply Client Filter"
          variant="outlined"
          InputLabelProps={{ sx: { bgcolor: 'background.paper', px: 1, transform: 'translate(14px, -6px) scale(0.75)' } }}
          sx={{ '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: 'grey.500' }, '&:hover fieldset': { borderColor: 'primary.main' } } }}
        />
      )}
      sx={{
        '& .MuiAutocomplete-popupIndicator': {
          marginRight: '-10px !important',
        },
        '& .MuiSvgIcon-root': {
          fontSize: '1.5rem',
        },
      }}
    />
  </Box>
</Box>


        <Box
          sx={{
            flex: 1,
            width: "100%",
            overflow: "auto",
            minHeight: 0,
          }}
        >
          <Grid container spacing={2} sx={{ height: "100%" }}>
            <Grid
              sx={{
                height: "100%",
                width: "100%",
              }}
            >
              <Box sx={{ height: "100%", marginTop: "1em" }}>
                <DataGrid
                  rows={cases}
                  columns={columns}
                  onRowDoubleClick={handleRowClick}
                  getRowClassName={(params) =>
                    params.indexRelativeToCurrentPage % 2 === 0 ? "even" : "odd"
                  }
                  initialState={{
                    pagination: { paginationModel: { pageSize: 20 } },
                  }}
                  loading={loading}
                  pageSizeOptions={[10, 20, 50]}
                  density="compact"
                  slotProps={{
                    filterPanel: {
                      filterFormProps: {
                        logicOperatorInputProps: {
                          variant: "outlined",
                          size: "small",
                        },
                        columnInputProps: {
                          variant: "outlined",
                          size: "small",
                          sx: { mt: "auto" },
                        },
                        operatorInputProps: {
                          variant: "outlined",
                          size: "small",
                          sx: { mt: "auto" },
                        },
                        valueInputProps: {
                          InputComponentProps: {
                            variant: "outlined",
                            size: "small",
                          },
                        },
                      },
                    },
                  }}
                  sx={{
                    whiteSpace: "normal",
                    "& .MuiDataGrid-cell:focus": {
                      outline: "none",
                      backgroundColor: "transparent",
                    },
                  }}
                />
              </Box>
            </Grid>
          </Grid>
            {/* Snackbar remains the same */}
                <Snackbar
                  open={notification.open}
                  autoHideDuration={3000}
                  onClose={() => setNotification({ ...notification, open: false })}
                  anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                >
                  <Alert
                    onClose={() => setNotification({ ...notification, open: false })}
                    severity={notification.severity}
                    sx={{ width: '100%' }}
                  >
                    {notification.message}
                  </Alert>
                </Snackbar>
        </Box>
      </Box>
      {modalOpen && (
        <CaseDetailsModal
          open={modalOpen}
          onClose={handleCloseModal}
          caseData={selectedCase}
        />
      )}
    </Box>
  );
}

export default Cases




      //  <Box display="flex" alignItems="center" gap={2} flexWrap="wrap">
      //     <FormControl
      //       sx={{ minWidth: 200, marginRight: 2 }}
      //       variant="outlined"
      //     >
      //       <InputLabel id="required-cases-label">
      //         Show Cases that are
      //       </InputLabel>
      //       <Select
      //         labelId="required-cases-label"
      //         value={requiredCases}
      //         label="Show Cases that are"
      //         onChange={handlecaseType}
      //       >
      //         <MenuItem value="-1">Select One</MenuItem>
      //         <MenuItem value="PENDING">Pending</MenuItem>
      //         <MenuItem value="COMPLETED">Completed</MenuItem>
      //         <MenuItem value="NAME-SEARCH">Search by name</MenuItem>
      //         <MenuItem value="INITIATION-DATE">
      //           Search by Initiation Date
      //         </MenuItem>
      //         <MenuItem value="CASE-ID">Search by Case Id</MenuItem>
      //       </Select>
      //     </FormControl>


      //   {/* PENDING CASES */}

      //   {requiredCases==="PENDING" &&(
      //       <Button variant='contained'
      //    onClick={()=>searchPendingCases}>
      //     Fetch
      //   </Button>
        
          
      //   )}

      //     {/* COMPLETED: Start and End Date */}
      //     {requiredCases === "COMPLETED" && (
      //       <Box display="flex" gap={2} alignItems="center">
      //         <TextField
      //           label="Start Date"
      //           type="date"
      //           value={startDate}
      //           onChange={(e) => setStartDate(e.target.value)}
      //           InputLabelProps={{ shrink: true }}
      //         />
      //         <TextField
      //           label="End Date"
      //           type="date"
      //           value={endDate}
      //           onChange={(e) => setEndDate(e.target.value)}
      //           InputLabelProps={{ shrink: true }}
      //         />
      //         <Button
      //           variant="contained"
      //           onClick={() => searchByCompletionDate()}
      //         >
      //           Fetch
      //         </Button>
      //       </Box>
      //     )}

      //     {/* NAME-SEARCH */}
      //     {requiredCases === "NAME-SEARCH" && (
      //       <Box display="flex" alignItems="center" gap={2}>
      //         <TextField
      //           label="Provide a Candidate Name to Search"
      //           value={nameSearchValue}
      //           onChange={(e) => setNameSearchValue(e.target.value)}
      //         />
      //         <Button variant="contained" onClick={() => searchByName()}>
      //           Fetch
      //         </Button>
      //       </Box>
      //     )}

      //     {/* INITIATION-DATE */}
      //     {requiredCases === "INITIATION-DATE" && (
      //       <Box display="flex" alignItems="center" gap={2}>
      //         <TextField
      //           label="Initiation Start Date"
      //           type="date"
      //           value={initiationStartDate}
      //           onChange={(e) => setInitiationStartDate(e.target.value)}
      //           InputLabelProps={{ shrink: true }}
      //         />
      //         <TextField
      //           label="Initiation End Date"
      //           type="date"
      //           value={initiationEndDate}
      //           onChange={(e) => setInitiationEndDate(e.target.value)}
      //           InputLabelProps={{ shrink: true }}
      //         />
      //         <Button
      //           variant="contained"
      //           onClick={() => searchByInitiationDate()}
      //         >
      //           Fetch
      //         </Button>
      //       </Box>
      //     )}

      //     {/* CASE-ID */}
      //     {requiredCases === "CASE-ID" && (
      //       <Box display="flex" alignItems="center" gap={2}>
      //         <TextField
      //           label="Provide a Case Id to Search"
      //           value={caseId}
      //           onChange={(e) => setCaseId(e.target.value)}
      //         />
      //         <Button variant="contained" onClick={() => handleSearch()}>
      //           Fetch
      //         </Button>
      //       </Box>
      //     )}

      //     {/* Autocomplete Client Filter */}
      //     <Box sx={{ marginTop: 0.3, minWidth: 300 }}>
      //       <Autocomplete
      //         value={requiredClient}
      //         onChange={(e, newValue) => setRequiredClient(newValue)}
      //         options={filteredOptions}
      //         getOptionLabel={(option) => option.name}
      //         renderInput={(params) => (
      //           <TextField
      //             {...params}
      //             label="Apply Client Filter"
      //             variant="outlined"
      //           />
      //         )}
      //           sx={{
      //       '& .MuiAutocomplete-popupIndicator': {
      //         marginRight: '-10px !important',
      //       },
      //       '& .MuiSvgIcon-root': {
      //         fontSize: '1.5rem',
      //       }
      //     }}
      //       />
      //     </Box>

      //     {/* Export to Excel */}
      //     {/* <Button
      //       variant="contained"
      //       color="primary"
      //       sx={{
      //         height: "35px",
      //         marginTop: "16px",
      //         marginLeft: "20px",
      //         bottom: "6px",
      //       }}
      //       onClick={handleExport}
      //     >
      //       Export to xls
      //     </Button> */}
      //   </Box>