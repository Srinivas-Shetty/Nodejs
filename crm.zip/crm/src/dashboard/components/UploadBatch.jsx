import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  TextField,
  Button,
  Grid,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Snackbar
} from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import UploadIcon from '@mui/icons-material/Upload';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { Alert } from '@mui/material';
import api from '../../auth/api';
const columns = [
  { field: 'batchId', headerName: 'Batch ID', flex: 1, minWidth: 100 },
  { field: 'batchDescription', headerName: 'Batch Description', flex: 2, minWidth: 200 },
  { field: 'uploadDate', headerName: 'Upload Date', flex: 1, minWidth: 120 },
  { field: 'numberOfCases', headerName: 'No. of Cases', flex: 1, minWidth: 120 },
  { field: 'accepted-Cases', headerName: 'Accepted Cases', flex: 1, minWidth: 120 },
];


const UploadBatch = () => {
  const [rows, setRows] = useState([])
  const [client, setClient] = useState('');
  const [subclient, setSubclient] = useState('');
  const [clientOptions, setClientOptions] = useState([]);
  const [clientSubMap, setClientSubMap] = useState({});
  const [batchDesc, setBatchDesc] = useState('');
  const [caseCount, setCaseCount] = useState('');
  const [selectedFiles, setSelectedFiles] = useState('');
  const [fileError, setFileError] = useState(false);
  // const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'info' });

  const [notification, setNotification] = useState({ open: false, message: '', severity: 'info' });

  const fileInputRef = React.useRef(null);
  let userId = localStorage.getItem('userId') || '';

  const fetchClientSubclientMap = async (userId) => {
    try {
      const res = await api.get(`/usersubclientaccess/useremail/${userId}`);

      if (res.data) {
        const clients = res.data.reduce((acc, item) => {
          if (!acc.some(client => client.id === item.client._id)) {
            acc.push({ id: item.client._id, name: item.client.name });
          }
          return acc;
        }, []);

        const clientSubMap = res.data.reduce((map, item) => {
          if (!map[item.client._id]) map[item.client._id] = [];
          map[item.client._id].push({ id: item.subclient._id, name: item.subclient.name });
          return map;
        }, {});

        return { clients, clientSubMap };
      }
    } catch (error) {
      // console.error('Error fetching client/subclient data:', error);
      setNotification({ open: true, message: 'Error fetching client/subclient data:', severity: 'error' });
      throw error;
    }
  };

  useEffect(() => {
    const fetchClientData = async () => {
      try {
        const { clients, clientSubMap } = await fetchClientSubclientMap(userId);
        setClientOptions(clients);
        setClientSubMap(clientSubMap);
      } catch (error) {
        console.error('Error fetching client/subclient data:', error);
        // showSnackbar('Error fetching client/subclient data:', 'error');

        setNotification({ open: true, message: 'Error fetching client/subclient data:', severity: 'error' });
      }
    };
    fetchClientData();
  }, [userId]);

  useEffect(() => {
    const fetchClientData = async () => {
      try {
        const { clients, clientSubMap } = await fetchClientSubclientMap(userId);
        setClientOptions(clients);
        setClientSubMap(clientSubMap);
      } catch (error) {
        console.error('Error fetching client/subclient data:', error);
        // showSnackbar('Error fetching client/subclient data:', 'error');

        setNotification({ open: true, message: 'Error fetching client/subclient data:', severity: 'error' });
      }
    };
    fetchClientData();
  }, [userId]);

  useEffect(() => {
    const readBatches = async () => {
      try {
        const res = await api.get(`/batches/client/${client}/subclient/${subclient}`)
        let data = res.data.map((resp, index) => ({ ...resp, id: index + 1 }))
        console.log(data,
          '55555555555555555'
        );
        
        setRows(data)
      } catch (error) {
        console.log('error == ', error);
        // showSnackbar('Error fectching batches', 'error');
        setNotification({ open: true, message: 'Error fetching batches', severity: 'error' });
      }
    }
    readBatches()

  }, [subclient])

  const handleFileChange = (event) => {
    const files = event.target.files;
    if (files.length > 0) {
      setSelectedFiles(Array.from(files));
      setFileError(false);
    }
  };

  const handleUpload = async () => {
    if (selectedFiles.length === 0) {
      setFileError(true);
      return;
    }
    let zipFile = selectedFiles[0]
    const formData = new FormData();
    formData.append('batchZipFile', zipFile, zipFile.name);
    formData.append('client', client);
    formData.append('subclient', subclient);
    formData.append('batchDescription', batchDesc);
    formData.append('numberOfCases', caseCount.toString());

    try {
      const res = await api.post(`/batches`, formData)
      console.log('res = ', res.data);
      // showSnackbar('Batch uploaded successfully', 'success');

      setNotification({ open: true, message: 'Batch uploaded successfully', severity: 'success' });
    } catch (error) {
      console.log('err == ', error);
      // showSnackbar('Error uploading file', 'error');

      setNotification({ open: true, message: 'Error uploading file', severity: 'error' });
    }

  };

  // const showSnackbar = (message, severity) => {
  //   setSnackbar({ open: true, message, severity });
  // };

  // const handleCloseSnackbar = () => {
  //   setSnackbar({ ...snackbar, open: false });
  // };

  const handleCloseSnackbar = () => {
    setNotification({ ...notification, open: false });
  };



  return (
    <Box
      sx={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        px: 3,
      }}
    >
      <Box
        sx={{
          width: "100%",
          maxWidth: "1700px",
          height: "100%",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <Typography component="h2" variant="h6" sx={{ mb: 2 }}>
          Upload Batch
        </Typography>

        {/* <Box sx={{ display: "flex", gap: 3, mb: 4, flexWrap: "wrap" }}>
          <FormControl required sx={{ width: "30%" }}>
            <InputLabel id="client-label">Client</InputLabel>
            <Select
              labelId="client-label"
              value={client}
              onChange={(e) => {
                setClient(e.target.value);
                setSubclient("");
              }}
              IconComponent={KeyboardArrowDownIcon}
              label="Client"
            >
              <MenuItem value="">
                <em>Select</em>
              </MenuItem>

              {clientOptions.map((clientOption) => (
                <MenuItem key={clientOption.id} value={clientOption.id}>
                  {clientOption.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <FormControl required sx={{ width: "30%" }}>
            <InputLabel id="subclient-label">Subclient</InputLabel>
            <Select
              labelId="subclient-label"
              value={subclient}
              onChange={(e) => setSubclient(e.target.value)}
              IconComponent={KeyboardArrowDownIcon}
              label="Subclient"
              disabled={!client}
            >
              <MenuItem value="">
                <em>Select</em>
              </MenuItem>
              {client && clientSubMap[client] ? (
                clientSubMap[client].map((subclientOption) => (
                  <MenuItem
                    key={subclientOption.id}
                    value={subclientOption.id}
                  >
                    {subclientOption.name}
                  </MenuItem>
                ))
              ) : (
                <MenuItem disabled>No subclients available</MenuItem>
              )}
            </Select>
          </FormControl>
          <TextField
            label="Batch Description"
            value={batchDesc}
            onChange={(e) => setBatchDesc(e.target.value)}
            required
            sx={{ width: "30%" }}
          />

          <TextField
            label="No. of Cases"
            type="number"
            value={caseCount}
            onChange={(e) => {
              const val = e.target.value;
              if (!isNaN(val) && Number(val) >= 0) {
                setCaseCount(val);
              }
            }}
            onKeyDown={(e) => {
              if (e.key === "ArrowUp") {
                setCaseCount((prev) => String(Number(prev || 0) + 0));
              } else if (e.key === "ArrowDown") {
                setCaseCount((prev) => {
                  const newVal = Number(prev || 0) - 1;
                  return newVal >= 0 ? String(newVal) : "0";
                });
              }
            }}
            required
            sx={{ width: "20%" }}
            slotProps={{
              input: {
                min: 0,
              },
            }}
          />

          <Box
            sx={{ width: "25%", display: "flex", flexDirection: "column" }}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".zip"
              placeholder="click here to select a zip file"
              // multiple
              style={{ display: "none" }}
              onChange={handleFileChange}
            />

            <Button
              variant="outlined"
              onClick={() => fileInputRef.current.click()}
              sx={{
                textAlign: "left",
                mb: 1,
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {selectedFiles.length > 0
                ? selectedFiles.map((file) => file.name).join(", ")
                : "Click to select ZIP files"}
            </Button>

            {fileError && (
              <Typography variant="caption" color="error">
                Please select files before uploading.
              </Typography>
            )}
          </Box>

          <Button
            variant="contained"
            color="secondary"
            startIcon={<UploadIcon />}
            sx={{ height: "fit-content" }}
            onClick={handleUpload}
          >
            Upload
          </Button>
        </Box> */}

        {/* 19sep2025 */}
        <Box sx={{ display: "flex", gap: 3, mb: 4, flexWrap: "wrap" }}>
          <FormControl required sx={{ width: "30%", '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: 'grey.500' }, '&:hover fieldset': { borderColor: 'primary.main' } } }} variant="outlined">
            <InputLabel id="client-label" sx={{ bgcolor: 'background.paper', px: 1, transform: client ? 'translate(14px, -6px) scale(0.75)' : 'translate(14px, 10px) scale(1)' }}>
              Client
            </InputLabel>
            <Select
              labelId="client-label"
              value={client}
              onChange={(e) => {
                setClient(e.target.value);
                setSubclient("");
              }}
              IconComponent={KeyboardArrowDownIcon}
              label="Client"
            >
              <MenuItem value="">
                <em>Select</em>
              </MenuItem>
              {clientOptions.map((clientOption) => (
                <MenuItem key={clientOption.id} value={clientOption.id}>
                  {clientOption.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <FormControl required sx={{ width: "30%", '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: 'grey.500' }, '&:hover fieldset': { borderColor: 'primary.main' } } }} variant="outlined">
            <InputLabel id="subclient-label" sx={{ bgcolor: 'background.paper', px: 1, transform: subclient ? 'translate(14px, -6px) scale(0.75)' : 'translate(14px, 10px) scale(1)' }}>
              Subclient
            </InputLabel>
            <Select
              labelId="subclient-label"
              value={subclient}
              onChange={(e) => setSubclient(e.target.value)}
              IconComponent={KeyboardArrowDownIcon}
              label="Subclient"
              disabled={!client}
            >
              <MenuItem value="">
                <em>Select</em>
              </MenuItem>
              {client && clientSubMap[client] ? (
                clientSubMap[client].map((subclientOption) => (
                  <MenuItem key={subclientOption.id} value={subclientOption.id}>
                    {subclientOption.name}
                  </MenuItem>
                ))
              ) : (
                <MenuItem disabled>No subclients available</MenuItem>
              )}
            </Select>
          </FormControl>

          <TextField
            label="Batch Description"
            value={batchDesc}
            onChange={(e) => setBatchDesc(e.target.value)}
            required
            sx={{ width: "30%", '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: 'grey.500' }, '&:hover fieldset': { borderColor: 'primary.main' } } }}
            variant="outlined"
            InputLabelProps={{ sx: { bgcolor: 'background.paper', px: 1, transform: batchDesc ? 'translate(14px, -6px) scale(0.75)' : 'translate(14px, 10px) scale(1)' } }}
          />

          <TextField
            label="No. of Cases"
            type="number"
            value={caseCount}
            onChange={(e) => {
              const val = e.target.value;
              if (!isNaN(val) && Number(val) >= 0) {
                setCaseCount(val);
              }
            }}
            onKeyDown={(e) => {
              if (e.key === "ArrowUp") {
                setCaseCount((prev) => String(Number(prev || 0) + 1));
              } else if (e.key === "ArrowDown") {
                setCaseCount((prev) => {
                  const newVal = Number(prev || 0) - 1;
                  return newVal >= 0 ? String(newVal) : "0";
                });
              }
            }}
            required
            sx={{ width: "20%", '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: 'grey.500' }, '&:hover fieldset': { borderColor: 'primary.main' } } }}
            variant="outlined"
            slotProps={{
              input: {
                min: 0,
              },
            }}
            InputLabelProps={{ sx: { bgcolor: 'background.paper', px: 1, transform: caseCount ? 'translate(14px, -6px) scale(0.75)' : 'translate(14px, 10px) scale(1)' } }}
          />

          <Box sx={{ width: "25%", display: "flex", flexDirection: "column" }}>
            <input
              ref={fileInputRef}
              type="file"
              accept=".zip"
              style={{ display: "none" }}
              onChange={handleFileChange}
            />
            <Button
              variant="outlined"
              onClick={() => fileInputRef.current.click()}
              sx={{
                textAlign: "left",
                mb: 1,
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {selectedFiles.length > 0
                ? selectedFiles.map((file) => file.name).join(", ")
                : "Click to select ZIP files"}
            </Button>
            {fileError && (
              <Typography variant="caption" color="error">
                Please select files before uploading.
              </Typography>
            )}
          </Box>

          <Button
            variant="contained"
            color="secondary"
            startIcon={<UploadIcon />}
            sx={{ height: "fit-content" }}
            onClick={handleUpload}
          >
            Upload
          </Button>
        </Box>
        {/* 19sep2025 */}

        <Box sx={{ width: "100%", height: "100vh", overflow: "hidden" }}>
          <Grid container spacing={2}>
            <Box sx={{ height: 500, width: "100%" }}>
              <DataGrid
                rows={rows}
                columns={columns}
                disableRowSelectionOnClick
                getRowClassName={(params) =>
                  params.indexRelativeToCurrentPage % 2 === 0 ? "even" : "odd"
                }
                initialState={{
                  pagination: { paginationModel: { pageSize: 10 } },
                }}
                pageSizeOptions={[10, 20, 50]}
                density="compact"
                sx={{
                  whiteSpace: "normal",
                  "& .MuiDataGrid-cell:focus": {
                    outline: "none",
                    backgroundColor: "transparent",
                  },
                  "& .MuiDataGrid-columnHeaders": {
                    backgroundColor: "#f5f5f5",
                    fontWeight: "bold",
                  },
                }}
              />
            </Box>
          </Grid>
        </Box>
      </Box>
      {/* <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        message={snackbar.message}
        /> */}

      {/* <Snackbar
  open={notification.open}
  autoHideDuration={6000}
  onClose={handleCloseSnackbar}
  message={notification.message}
/> */}

      <Snackbar
        open={notification.open}
        autoHideDuration={3000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={notification.severity}
          sx={{ width: '100%' }}
        >
          {notification.message}
        </Alert>
      </Snackbar>


    </Box>
  );
};

export default UploadBatch;