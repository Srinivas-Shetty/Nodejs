// import React from 'react'

// function InsuffClinet() {
//   return (
//     <div>InsuffClinet</div>
//   )
// }

// export default InsuffClinet

import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Autocomplete,
  Snackbar,
  Pagination,
  Checkbox,
  CircularProgress
} from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import api from '../../auth/api';
import ClientInsufDetailsDialog from './InsufClientDetailsModal';


const InsuffClinet = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [searchCaseId, setSearchCaseId] = useState('');
  const [totalCount, setTotalCount] = useState(0);
  const [pageCount, setPageCount] = useState(0);
  const [insufficienciesData, setInsufficienciesData] = useState([]);
  const [subclients, setSubclients] = useState([]);
  const [isSendEmailButtonEnabled, setIsSendEmailButtonEnabled] = useState(false);
  const [selectedItems, setSelectedItems] = useState([]);
  const [selectedInsuffItems, setSelectedInsuffItems] = useState([]);
  const [clients, setClients] = useState([]);
  const [requiredClient, setRequiredClient] = useState(null);
  const [filteredOptions, setFilteredOptions] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedInsuffItem, setSelectedInsuffItem] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'info' });
  const navigate = useNavigate();

  const insuffItemsDisplayedColumns = [
    'serialNumber',
    'caseId',
    'candidateName',
    'clientName',
    'subclientName',
    'componentDisplayName',
    'field',
    'displayStatus',
    'insufficiencyRaisedDate',
    'insufficiencyComments',
    'details',
    'select',
  ];

  const columns = [
    // { field: 'index', headerName: '#', width: 50 },
    { field: 'caseId', headerName: 'Case ID', width: 150 },
    { field: 'candidateName', headerName: 'Candidate Name', width: 180 },
    { field: 'clientName', headerName: 'Client Name', width: 180 },
    { field: 'subclientName', headerName: 'Subclient Name', width: 180 },
    { field: 'componentDisplayName', headerName: 'Component', width: 180 },
    { field: 'field', headerName: 'Field', width: 150 },
    { field: 'displayStatus', headerName: 'Status', width: 120 },
    { field: 'insufficiencyRaisedDate', headerName: 'Date Raised', width: 180 },
    { field: 'insufficiencyComments', headerName: 'Comments', width: 250 },
    {
      field: 'details',
      headerName: 'Details',
      width: 120,
      renderCell: (params) => (
        <Button
          variant="outlined"
          onClick={() => insuffDetailsButtonClicked(params.row)}
        >
          Details
        </Button>
      ),
    },
    {
      field: 'checkbox',
      headerName: '',
      width: 80,
      renderCell: (params) => (
        <Checkbox
          checked={selectedInsuffItems.some(item => item._id === params.row._id)}
          onChange={() => toggleCheckbox(params.row)}
        />
      ),
    },
  ];

const exportInsufficienciesToExcel = () => {
  try {
    // Always define headers
    const headers = [
      "SL No",
      "Case ID",
      "Candidate Name",
      "Client",
      "Subclient",
      "Component",
      "Field",
      "Status",
      "Date Raised",
      "Comments",
    ];

    let exportData;

    if (!insufficienciesData || insufficienciesData.length === 0) {
      // No rows → create sheet with only headers
      exportData = [Object.fromEntries(headers.map(h => [h, ""]))];
    } else {
      // Normal case → fill with data
      exportData = insufficienciesData.map((row, index) => ({
        "SL No": index + 1,
        "Case ID": row.caseId || "-",
        "Candidate Name": row.candidateName || "-",
        "Client": row.clientName || "-",
        "Subclient": row.subclientName || "-",
        "Component": row.componentDisplayName || "-",
        "Field": row.field || "-",
        "Status": row.displayStatus || "-",
        "Date Raised": row.insufficiencyRaisedDate
          ? new Date(row.insufficiencyRaisedDate).toLocaleDateString()
          : "-",
        "Comments": row.insufficiencyComments || "-",
      }));
    }

    // Create worksheet
    const worksheet = XLSX.utils.json_to_sheet(exportData, { header: headers });

    // Create workbook
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Client Insufficiencies");

    // Write buffer
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });

    // Save file
    const data = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    saveAs(data, "Client_Insufficiencies.xlsx");

    showMessage(
      insufficienciesData.length === 0
        ? "Excel exported with only headers (no data found)"
        : "Excel exported successfully!"
    );
  } catch (error) {
    console.error("Error exporting to Excel:", error);
    showError("Error exporting to Excel");
  }
};
  useEffect(() => {
    fillData();
    fetchSubclients();
  }, []);


  useEffect(() => {
    if (requiredClient === null || requiredClient === '') {
      setFilteredOptions(clients);
    } else {
      const filterValue = typeof requiredClient === 'string' ? requiredClient.toLowerCase() : requiredClient.name.toLowerCase();
      setFilteredOptions(
        clients.filter(option => 
          option.name.toLowerCase().includes(filterValue)
      ));
    }
  }, [requiredClient, clients]);

  const fetchSubclients = async () => {
    try {        
      const response = await api.get('/usersubclientaccess');
      console.log(response,"insuffdata");
      
      const uniqueClients = [];
      response.data.forEach(item => {
        const exists = uniqueClients.some(client => 
          client._id === item.subclient.client._id
        );
        if (!exists) {
          uniqueClients.push({
            _id: item.subclient.client._id,
            name: item.subclient.client.name,
          });
        }
      });
      setClients(uniqueClients);
    } catch (error) {
      showError('Error getting the clients for the user');
    }
  };

  const fillData = async () => {
    await fillSubclientData();
    fillInsufficiencyData();
  };

  const fillInsufficiencyData = async () => {
    setIsLoading(true);
    try {
      console.log('Starting data fetch...');
      const componentsResponse = await api.get('/components');
    
  
      const allPromises = componentsResponse.data.map(async (component) => {
        try {
          const insuffResponse = await api.get(`/${component.name}/insuff/insuffforclient?pageCount=${pageCount}`);
  
          const componentInsuffData = insuffResponse.data.map(item => {
            const insuffComponent = {
              case_id: item.case?._id,
              caseId: item.case?.caseId,
              candidateName: item.case?.candidateName,
              clientName: item.case?.subclient?.client?.name,
              subclientName: item.case?.subclient?.name,
              subclientId: item.case?.subclient?._id,
              _id: item._id,
              componentName: component.name,
              componentDisplayName: component.displayName,
              status: item.status,
              insuffCategory: item.insuffCategory,
              displayStatus: getDisplayStatus(item.status),
              component_id: component._id,
              field: fillFieldDetails(component.name, item),
              insufficiencyRaisedDate: item.insufficiencyRaisedDate,
              insufficiencyComments: item.insufficiencyComments,
              insufficiencyClearanceRejectionComments: item.insufficiencyClearanceRejectionComments,
              _rawItem: item 
            };
  
            const hasAccess = checkSubclientAccess(item, insuffComponent);
            
            return hasAccess ? insuffComponent : null;
          }).filter(Boolean);
  
          return componentInsuffData;
        } catch (error) {
          console.error(`[ERROR] Failed to load ${component.name}:`, error);
          return [];
        }
      });
  
      const results = await Promise.all(allPromises);
      const insuffData = results.flat().map((data, index) => ({id: index + 1, ...data}));
      setInsufficienciesData(insuffData);
      
    } catch (error) {
      console.error('[CRITICAL ERROR] in fillInsufficiencyData:', error);
      setInsufficienciesData([]);
    } finally {
      setIsLoading(false);
    }
  };

  const checkSubclientAccess = (item, insuffComponent) => {
    if (!subclients || subclients.length === 0) {
      return true;
    }
    const hasAccess = subclients.some(subclient => {
      const match = subclient.subclient === item.case?.subclient?._id;
      return match;
    });
    return hasAccess;
  };

  const getDisplayStatus = (status) => {
    if (status.includes('INSUF') && status.includes('REQ-ACCEPTED')) {
      return 'Insufficiency';
    } else if (status.includes('INSUF') && status.includes('CLEARANCE-REJECTED')) {
      return 'Insuff Clearance Rejected';
    } else if (status === 'COST-APPROVAL-REQ-ACCEPTED') {
      return 'Cost Approval Request';
    } else if (status === 'COST-APPROVAL-CLEARANCE-REJECTED') {
      return 'Cost Approval Rejected';
    } else if (status === 'CLARIFICATION-REQ-ACCEPTED') {
      return 'Clarification Request';
    }
    return 'Clarification Clearance Rejected';
  };

  const fillFieldDetails = (componentName, item) => {
    const fieldMappings = {
      'address': item.typeofaddress,
      'addresscomprehensive': item.typeofaddress,
      'addressonline': item.typeofaddress,
      'addresstelephone': item.typeofaddress,
      'bankstmt': '-',
      'courtrecord': item.typeofaddress,
      'creditcheck': item.taxid,
      'creditequifax': item.pannumber,
      'credittrans': item.pannumber,
      'criminalrecord': item.typeofaddress,
      'directorshipcheck': item.dinnumber,
      'dlcheck': item.dlnumber,
      'drugtestfive': item.fulladdress,
      'drugtestsix': '-',
      'drugtestseven': item.fulladdress,
      'drugtesteight': item.address,
      'drugtestnine': item.fulladdress,
      'drugtestten': item.address,
      'education': item.typeofqualification,
      'educationadvanced': item.typeofqualifiction,
      'educationcomprehensive': item.typeofqualification,
      'empbasic': item.nameofemployer,
      'empadvance': item.nameofemployer,
      'employment': item.nameofemployer,
      'facisl3': item.stcode,
      'gapvnf': item.tenureofgap,
      'globaldatabase': '-',
      'identity': item.typeofid,
      'ofac': item.ofac,
      'passport': item.passportnumber,
      'physostan': '-',
      'refbasic': item.name,
      'reference': item.nameofreference,
      'sitecheck': item.name,
      'socialmedia': item.searchname,
      'vddadvance': item.companyname,
    };
    
    return fieldMappings[componentName] || item.epicnumber;
  };


  const fillSubclientData = async () => {
    try {
    //   const userId = localStorage.getItem('userId');
    let userId = "venkatesh.r@verifacts.co.in"
      const userResponse = await api.get(`/users/email/${userId}`);
      const subclientsResponse = await api.get(`/usersubclientaccess/${userResponse.data._id}`);
      setSubclients(subclientsResponse.data);
      return true;
    } catch (error) {
      console.error('Error fetching subclient data:', error);
      return false;
    }
  };

  const insuffDetailsButtonClicked = (insuffItem) => {
    setSelectedInsuffItem(insuffItem);
    setOpenDialog(true);
  };

  const handleDialogClose = (data) => {
    setOpenDialog(false);
    if (data) {
      clearInsuff(selectedInsuffItem, data);
    }
  };

  const clearInsuff = async (insuffItem, data) => {
    console.log('insuff = ', insuffItem);
    console.log('insuff = ', data);
    
    try {
      insuffItem.scrutinyRejectionReason = data.rejectionReason;
      insuffItem.insufficiencyClearedComments = data.insufficiencyClearanceComments;

      let response;
      if (insuffItem.status === 'INSUF-1-REQ-ACCEPTED' || insuffItem.status === 'INSUF-1-CLEARANCE-REJECTED') {
        response = await api.put(`${insuffItem.componentName}/clearinsuff1/${insuffItem.case_id}/${insuffItem._id}`, insuffItem);
      } else if (
        insuffItem.status === 'INSUF-2-REQ-ACCEPTED' || 
        insuffItem.status === 'INSUF-2-CLEARANCE-REJECTED' ||
        insuffItem.status === 'INSUF-3-REQ-ACCEPTED' ||
        insuffItem.status === 'INSUF-3-CLEARANCE-REJECTED' ||
        insuffItem.status === 'INSUF-4-REQ-ACCEPTED' ||
        insuffItem.status === 'INSUF-4-CLEARANCE-REJECTED' ||
        insuffItem.status === 'INSUF-5-REQ-ACCEPTED' ||
        insuffItem.status === 'INSUF-5-CLEARANCE-REJECTED'
      ) {
        response = await api.put(`${insuffItem.componentName}/clearinsuff2/${insuffItem.case_id}/${insuffItem._id}`, insuffItem);
      } else if (
        insuffItem.status === 'COST-APPROVAL-REQ-ACCEPTED' ||
        insuffItem.status === 'COST-APPROVAL-CLEARANCE-REJECTED'
      ) {
        response = await api.put(`/api/component-data/clearCostApproval/${insuffItem.componentName}`, insuffItem);
      }

      if (response) {
        await api.put(`${insuffItem.componentName}/clearcostapproval/${insuffItem.case_id}/${insuffItem._id}`, insuffItem);
        setInsufficienciesData(prevData => 
          prevData.filter(item => item._id !== insuffItem._id)
        );
        showMessage('Insuff cleared and mail sent successfully');
      }
    } catch (error) {
      showError(error.response?.data?.message || 'Error clearing insufficiency');
    }
  };

  // const exportInsufficienciesToExcel = async () => {
  //   try {
  //     let response;
  //     if (requiredClient?._id === '6065850a539cbc9b9754a1f8') {
  //       response = await api.get('/api/vibe-report/getClientTechMInsufficiencies', {
  //         responseType: 'blob'
  //       });
  //     } else {
  //       response = await api.get('/api/vibe-report/getClientInsufficiencies', {
  //         responseType: 'blob'
  //       });
  //     }
  //   //   saveAs(response.data, 'insufficiency_report.xlsx');
  //   } catch (error) {
  //     console.error('Error in downloading insuff report', error);
  //     showError('Error downloading insufficiency report');
  //   }
  // };


  const searchForCaseIdButtonClicked = async () => {
    if (!searchCaseId.trim()) {
      showError('Please enter a Case ID to search');
      return;
    }
  
    setIsLoading(true);
    setInsufficienciesData([]);
  
    try {
      const componentsResponse = await api.get('/components');
      const componentPromises = componentsResponse.data.map(async (component) => {
        try {
          const response = await api.get(
            `/${component.name}/insuff/searchacaseininsuffforclient?caseId=${searchCaseId}`
          );
          const items = response.data.map(item => ({
            case_id: item.case?._id,
            caseId: item.case?.caseId,
            candidateName: item.case?.candidateName,
            clientName: item.case?.subclient?.client?.name,
            subclientName: item.case?.subclient?.name,
            subclientId: item.case?.subclient?._id,
            _id: item._id,
            componentName: component.name,
            componentDisplayName: component.displayName,
            status: item.status,
            insuffCategory: item.insuffCategory,
            displayStatus: getDisplayStatus(item.status),
            component_id: component._id,
            insufficiencyRaisedDate: item.insufficiencyRaisedDate,
            insufficiencyComments: item.insufficiencyComments,
            insufficiencyClearanceRejectionComments: item.insufficiencyClearanceRejectionComments,
            _rawItem: item
          }));
          return items;
        } catch (error) {
          console.error(`Error searching ${component.name}:`, error);
          return [];
        }
      });
      const results = await Promise.all(componentPromises);
      const allItems = results.flat();
      
      let filteredItems = allItems;
      if (subclients.length > 0) {
        filteredItems = allItems.filter(insuffComponent => {
          const hasAccess = subclients.some(
            subclient => subclient.subclient === insuffComponent.subclientId
          );
          return hasAccess;
        });
      }
      
      let data = filteredItems.map((item, index) => ({ id: index + 1, ...item }));
      setInsufficienciesData(data);
  
      if (filteredItems.length === 0) {
        if (allItems.length > 0) {
          showError('No items match your current access permissions');
        } else {
          showMessage('No insufficiencies found for this Case ID');
        }
      }
    } catch (error) {
      console.error('Search failed:', error);
      showError('Search operation failed');
    } finally {
      setIsLoading(false);
    }
  };
  
  

  const isSelected = (item) => {
    return selectedItems.includes(item);
  };

  const toggleCheckbox = (insuffitem) => {
    setSelectedInsuffItems(prev => {
      const index = prev.findIndex(item => item._id === insuffitem._id);
      if (index === -1) {
        return [...prev, insuffitem];
      } else {
        return prev.filter(item => item._id !== insuffitem._id);
      }
    });
  };

  useEffect(() => {
    setIsSendEmailButtonEnabled(selectedInsuffItems.length > 0);
  }, [selectedInsuffItems]);

  const SendFollowupEmailButtonClicked = async () => {
    try {
      const reqBody = {
        data: selectedInsuffItems,
      };
      await api.post('/api/user/SendFollowupEmail', reqBody);
      showMessage('Follow-up emails sent successfully');
    } catch (error) {
      console.error('SendFollowupEmail error:', error);
      showError('Error sending follow-up emails');
    }
  };

  const showMessage = (msg) => {
    setSnackbar({ open: true, message: msg, severity: 'info' });
  };

  const showError = (msg) => {
    setSnackbar({ open: true, message: msg, severity: 'error' });
  };

  const handleSnackbarClose = () => {
    setSnackbar(prev => ({ ...prev, open: false }));
  };

  const loadMoreClicked = () => {
    setPageCount(prev => prev + 1);
    fillInsufficiencyData();
  };

  return (
    <div>
      <h2>Client Insufficiency List</h2>
      
      <div style={{ marginBottom: '20px', display:"flex", justifyContent:"space-between" }}>
        <div style={{display:"flex"}}>
        <TextField
          label="Search Case ID"
          value={searchCaseId}
          onChange={(e) => setSearchCaseId(e.target.value)}
          style={{ marginRight: '10px' }}
        />
        <Button 
          variant="contained"
          color="secondary"
          onClick={searchForCaseIdButtonClicked}
          disabled={isLoading}
        >
          Search
        </Button>
        
        <Autocomplete
          options={filteredOptions}
          getOptionLabel={(option) => option.name || ''}
          value={requiredClient}
          onChange={(event, newValue) => setRequiredClient(newValue)}
          renderInput={(params) => (
            <TextField 
              {...params} 
              label="Select Client" 
              style={{ marginLeft: '10px', width: '300px' }}
            />
          )}
          sx={{
            '& .MuiAutocomplete-popupIndicator': {
              marginRight: '-10px !important',
            },
            '& .MuiSvgIcon-root': {
              fontSize: '1.5rem',
            }
          }}
        />
        </div>

        <div>
        <Button 
          variant="contained" 
          color="secondary"
          onClick={exportInsufficienciesToExcel}
          style={{ marginLeft: '10px' }}
        >
          Export to Excel
        </Button>
        
        <Button 
          variant="contained"
          color="secondary" 
          onClick={SendFollowupEmailButtonClicked}
          style={{ marginLeft: '10px',color:'white' }}
          disabled={!isSendEmailButtonEnabled}
        >
          Send Follow-up Email
        </Button>
        </div>
      </div>
      
      {isLoading ? (
        <CircularProgress />
      ) : (
        // <TableContainer component={Paper}>
        //   <Table>
        //     <TableHead>
        //       <TableRow>
        //         {insuffItemsDisplayedColumns.map(column => (
        //           <TableCell key={column}>{column}</TableCell>
        //         ))}
        //       </TableRow>
        //     </TableHead>
        //     <TableBody>
        //       {insufficienciesData.map((row, index) => (
        //         <TableRow key={row._id}>
        //           <TableCell>{index + 1}</TableCell>
        //           <TableCell>{row.caseId}</TableCell>
        //           <TableCell>{row.candidateName}</TableCell>
        //           <TableCell>{row.clientName}</TableCell>
        //           <TableCell>{row.subclientName}</TableCell>
        //           <TableCell>{row.componentDisplayName}</TableCell>
        //           <TableCell>{row.field}</TableCell>
        //           <TableCell>{row.displayStatus}</TableCell>
        //           <TableCell>{row.insufficiencyRaisedDate}</TableCell>
        //           <TableCell>{row.insufficiencyComments}</TableCell>
        //           <TableCell>
        //             <Button 
        //               variant="outlined" 
        //               onClick={() => insuffDetailsButtonClicked(row)}
        //             >
        //               Details
        //             </Button>
        //           </TableCell>
        //           <TableCell>
        //             <Checkbox
        //               checked={selectedInsuffItems.some(item => item._id === row._id)}
        //               onChange={() => toggleCheckbox(row)}
        //             />
        //           </TableCell>
        //         </TableRow>
        //       ))}
        //     </TableBody>
        //   </Table>
        // </TableContainer>
        <Paper style={{ height: 400, width: '100%' }}>
        <DataGrid
          rows={insufficienciesData}
          columns={columns}
          pageSize={5}  
          rowsPerPageOptions={[5, 10, 25]} 
        //   checkboxSelection
          disableSelectionOnClick
        />
      </Paper>
      )}
      
      <div style={{ marginTop: '20px' }}>
        <Button variant="contained" onClick={loadMoreClicked}>
          Load More
        </Button>
      </div>
      
      {/* Insuff Details Dialog */}


      {/* {selectedInsuffItem && (
        <Dialog
          open={openDialog}
          onClose={() => setOpenDialog(false)}
          maxWidth="lg"
          fullWidth
        >
          <DialogTitle>Insufficiency Details</DialogTitle>
          <DialogContent>
            <p>Case ID: {selectedInsuffItem.caseId}</p>
            <p>Candidate: {selectedInsuffItem.candidateName}</p>
            <p>Component: {selectedInsuffItem.componentDisplayName}</p>
            <p>Status: {selectedInsuffItem.displayStatus}</p>
            <p>Comments: {selectedInsuffItem.insufficiencyComments}</p>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
            <Button 
              onClick={() => handleDialogClose({ 
                rejectionReason: 'Sample reason',
                insufficiencyClearanceComments: 'Sample comments'
              })}
              color="primary"
            >
              Submit
            </Button>
          </DialogActions>
        </Dialog>
      )} */}

{selectedInsuffItem && (
        <ClientInsufDetailsDialog
          open={openDialog}
          onClose={handleDialogClose}
          data={{
            component_id: selectedInsuffItem.component_id,
            caseId: selectedInsuffItem.caseId,
            candidateName: selectedInsuffItem.candidateName,
            componentDisplayName: selectedInsuffItem.componentDisplayName,
            insufficiencyDetails: selectedInsuffItem.insufficiencyComments,
            insufficiencyClearanceRejectionComments: selectedInsuffItem.insufficiencyClearanceRejectionComments,
            componentName: selectedInsuffItem.componentName,
            case_id: selectedInsuffItem.case_id,
            _id: selectedInsuffItem._id,
            status: selectedInsuffItem.status
          }}
        />
      )}
      
      {/* Snackbar for messages */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={handleSnackbarClose}
        message={snackbar.message}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      />
    </div>
  );
};

export default InsuffClinet;