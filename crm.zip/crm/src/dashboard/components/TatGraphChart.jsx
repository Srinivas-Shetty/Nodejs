import React, { useEffect, useState } from 'react';
import {
  Card,
  CardContent,
  Typography,
  FormControl,
  Select,
  MenuItem,
  Stack,
  Box,
} from '@mui/material';
import { BarChart } from '@mui/x-charts/BarChart';
import { useTheme } from '@mui/material/styles';
import api from '../../auth/api';

export default function TatClosureChart() {
  const theme = useTheme();
  const [tatType, setTatType] = useState('in');
  const [packageType, setPackageType] = useState('all');
  const [tatDuration, setTatDuration] = useState('6_months');
  const [monthlyData, setMonthlyData] = useState(null);
  const [loading, setLoading] = useState(true);

  const handleTatTypeChange = (e) => setTatType(e.target.value);
  const handlePackageChange = (e) => setPackageType(e.target.value);
  const handleTatDurationChange = (e) => setTatDuration(e.target.value);

  // Function to calculate the last 15 days and return the dates
  const getLast15Days = () => {
    const today = new Date();
    const dates = [];
    const dayLabels = [];

    // Get the last 15 days including today
    for (let i = 14; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);
      dates.push(date.toLocaleDateString());
      dayLabels.push(`Day ${14 - i}`); // Labeling the days for simplicity
    }

    return { dates, dayLabels };
  };

  // Mock data for the last 15 days, separated by package type
  const mockData = {
    all: {
      inTat: Array(15).fill().map(() => Math.floor(Math.random() * 100)),
      outTat: Array(15).fill().map(() => Math.floor(Math.random() * 50)),
    },
    employment: {
      inTat: Array(15).fill().map(() => Math.floor(Math.random() * 80)),
      outTat: Array(15).fill().map(() => Math.floor(Math.random() * 40)),
    },
    drug: {
      inTat: Array(15).fill().map(() => Math.floor(Math.random() * 60)),
      outTat: Array(15).fill().map(() => Math.floor(Math.random() * 30)),
    },
    education: {
      inTat: Array(15).fill().map(() => Math.floor(Math.random() * 90)),
      outTat: Array(15).fill().map(() => Math.floor(Math.random() * 60)),
    },
  };

  
  const getTatDetails = async () => {
   
     setLoading(true);
    try {
      // Start loading

      // Fetch data from the API
      
      const tatResponse = await api.get(`/case/tatupdate/:${case_id}`);
      console.log(tatResponse,"tatadataaaaa");

      if (tatResponse.data) {
        const tatInData = tatResponse.data.tatInData.map(item => item.count);
        const tatOutData = tatResponse.data.tatOutData.map(item => item.count);
        const months = tatResponse.data.tatInData.map(item => item.month);
      
        // Set the data for the bar chart
        setMonthlyData({
          xAxis: [{ id: 'days', data: months, scaleType: 'band' }],
          series: [
            {
              id: 'tatinflow',
              data: tatInData,
              label: 'Tat In',
              // color: theme.palette.primary.main,
              color: '#FFA500', // Orange
            },
            {
              id: 'tatoutflow',
              data: tatOutData,
              label: 'Tat Out',
              // color: theme.palette.secondary.main,
              color: '#A9A9A9', // Grey
            },
          ],
        });
      } else {
        // Fallback to mock data based on selected package
        const { dates, dayLabels } = getLast15Days();

        const packageData = mockData[packageType] || mockData.all;

        setMonthlyData({
          xAxis: [{ id: 'days', data: dayLabels, scaleType: 'band' }],
          series: [
            {
              id: 'tatinflow',
              data: packageData.inTat,
              label: 'Tat In',
              // color: theme.palette.primary.main,
              color: '#FFA500', // Orange
            },
            {
              id: 'tatoutflow',
              data: packageData.outTat,
              label: 'Tat Out',
              // color: theme.palette.secondary.main,
              color: '#A9A9A9', // Grey
            },
          ],
        });
      }
    } catch (error) {
      console.error('Error fetching TAT data:', error);
      // Fallback to mock data on error
      const { dates, dayLabels } = getLast15Days();
      const packageData = mockData[packageType] || mockData.all;

      setMonthlyData({
        xAxis: [{ id: 'days', data: dayLabels, scaleType: 'band' }],
        series: [
          {
            id: 'tatinflow',
            data: packageData.inTat,
            label: 'Tat In',
            // color: theme.palette.primary.main,
            color: '#FFA500', // Orange
          },
          {
            id: 'tatoutflow',
            data: packageData.outTat,
            label: 'Tat Out',
            // color: theme.palette.secondary.main,
            color: '#A9A9A9', // Grey
          },
        ],
      });
    } finally {
      setLoading(false); // Stop loading
    }
  };

  useEffect(() => {
    getTatDetails();
  }, [tatType, tatDuration, packageType]); // Trigger effect when tatType, tatDuration, or packageType changes

  return (
    <Card variant="outlined" sx={{ height: '350px', flex: 1 }}>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Typography component="h2" variant="subtitle1">
            %age TAT Closure
          </Typography>
          <Stack direction="row" spacing={2}>
            {/* <FormControl size="small">
              <Select value={packageType} onChange={handlePackageChange}>
                <MenuItem value="all">All Packages</MenuItem>
                <MenuItem value="employment">Employment</MenuItem>
                <MenuItem value="drug">Drug</MenuItem>
                <MenuItem value="education">Education</MenuItem>
              </Select>
            </FormControl> */}
            <FormControl size="small">
              <Select value={tatType} onChange={handleTatTypeChange}>
                <MenuItem value="in">In TAT</MenuItem>
                <MenuItem value="out">Out of TAT</MenuItem>
              </Select>
            </FormControl>
            {/* <FormControl size="small">
              <Select value={tatDuration} onChange={handleTatDurationChange}>
                <MenuItem value="6_months">Last 6 months</MenuItem>
                <MenuItem value="3_months">Last 3 months</MenuItem>
              </Select>
            </FormControl> */}
          </Stack>
        </Box>

        {loading ? (
          <Typography>Loading...</Typography>
        ) : monthlyData && monthlyData.series.length > 0 ? (
          <BarChart
            height={270}
            xAxis={monthlyData.xAxis}
            series={monthlyData.series}
            margin={{ top: 20, bottom: 30, left: 50, right: 20 }}
            grid={{ horizontal: true }}
          />
        ) : (
          <Typography>No data available.</Typography>
        )}
      </CardContent>
    </Card>
  );
}


// import { useEffect, useState } from "react";
// import {
//   Card,
//   CardContent,
//   Typography,
//   CircularProgress,
//   Box,
//   FormControl,
//   InputLabel,
//   Select,
//   MenuItem,
// } from "@mui/material";
// import { BarChart } from "@mui/x-charts/BarChart";
// import api from "../../auth/api";

// const TatStatusChart = () => {
//   const [loading, setLoading] = useState(true);
//   const [cases, setCases] = useState([]);
//   const [filter, setFilter] = useState("All");

//   const fetchCases = async () => {
//     try {
//       const response = await api.get(`/cases/tatupdate:${caseId}`); // Make sure GET route is added
//       console.log("tat data ",response);
      
//       setCases(response.data);
//     } catch (error) {
//       console.error("Error fetching cases:", error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const getTatCounts = () => {
//     const now = new Date();
//     let inTat = 0;
//     let outTat = 0;

//     cases.forEach((item) => {
//       const tatDate = new Date(item.tatEndDate);
//       if (!isNaN(tatDate)) {
//         if (tatDate >= now) inTat++;
//         else outTat++;
//       }
//     });

//     return {
//       All: [inTat, outTat],
//       "In TAT": [inTat, 0],
//       "Out of TAT": [0, outTat],
//     }[filter];
//   };

//   useEffect(() => {
//     fetchCases();
//   }, []);

//   const [inTatCount, outTatCount] = getTatCounts();

//   return (
//     <Card variant="outlined" sx={{ height: 400 }}>
//       <CardContent>
//         <Typography variant="h6" gutterBottom>
//           TAT Breakdown
//         </Typography>

//         <FormControl fullWidth sx={{ mb: 2 }}>
//           <InputLabel id="tat-filter-label">Filter</InputLabel>
//           <Select
//             labelId="tat-filter-label"
//             value={filter}
//             onChange={(e) => setFilter(e.target.value)}
//             label="Filter"
//           >
//             <MenuItem value="All">All</MenuItem>
//             <MenuItem value="In TAT">In TAT</MenuItem>
//             <MenuItem value="Out of TAT">Out of TAT</MenuItem>
//           </Select>
//         </FormControl>

//         {loading ? (
//           <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
//             <CircularProgress />
//           </Box>
//         ) : (
//           <BarChart
//             xAxis={[{ scaleType: "band", data: ["In TAT", "Out of TAT"] }]}
//             series={[
//               {
//                 data: [inTatCount, outTatCount],
//                 label: "Cases",
//                 color: "#FF9800",
//               },
//             ]}
//             width={400}
//             height={280}
//           />
//         )}
//       </CardContent>
//     </Card>
//   );
// };

// export default TatStatusChart;



