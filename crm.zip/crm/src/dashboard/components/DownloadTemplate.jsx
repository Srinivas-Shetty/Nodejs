import React, { useState, useEffect } from 'react';
import {
    Container, AppBar, Toolbar, Typography, IconButton, FormControl, InputLabel,
    Select, MenuItem, Table, TableBody, TableCell, TableContainer, TableHead,
    TableRow, Button, Checkbox, TextField, Dialog, DialogTitle, DialogContent,
    DialogActions, Snackbar, Alert, Box
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import GetAppIcon from '@mui/icons-material/GetApp';
import PublishIcon from '@mui/icons-material/Publish';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import axios from 'axios';
import api from '../../auth/api';

// Mock data models
const Client = { _id: '', name: '', subclients: [] };
const Subclient = { _id: '', name: '' };
const ClientContractPackage = { _id: '', name: '', clientContractPackageComponents: [], tat: 0, price: 0 };
const ClientContractProfile = { _id: '', name: '', clientContractProfileComponents: [], tat: 0 };
const ClientContractPackageComponent = { componentName: '', details: '' };
const ClientContractProfileComponent = { componentName: '', details: '' };
const CaseComponent = { component: '', componentName: '', price: 0, tat: 0, instructions: '', maxChecks: 0, selected: false };
const ExcelUpload = { referenceNumber: 0, client: '', subclient: '', package: '', profile: '', componentsToCheck: [], status: '' };
const Case = { client: '', subclient: '', batchId: 0, package: '', profile: '', tat: 0, componentsToCheck: [] };

// Mock data for packages, profiles, components, and excel uploads
const mockPackages = [
    { _id: 'pkg1', name: 'Package 1', clientContractPackageComponents: [{ componentName: 'Component 1', details: 'Details 1' }], tat: 5, price: 100 },
    { _id: 'pkg2', name: 'Package 2', clientContractPackageComponents: [{ componentName: 'Component 2', details: 'Details 2' }], tat: 7, price: 150 }
];
const mockProfiles = [
    { _id: 'prof1', name: 'Profile 1', clientContractProfileComponents: [{ componentName: 'Profile Component 1', details: 'Profile Details 1' }], tat: 3 },
    { _id: 'prof2', name: 'Profile 2', clientContractProfileComponents: [{ componentName: 'Profile Component 2', details: 'Profile Details 2' }], tat: 4 }
];
const mockComponents = [
    { component: 'comp1', componentName: 'Component A', price: 50, tat: 2, instructions: '', maxChecks: 1, selected: false },
    { component: 'comp2', componentName: 'Component B', price: 75, tat: 3, instructions: '', maxChecks: 2, selected: false }
];
const mockExcelUploads = [
    { referenceNumber: 1001, client: '6517db3077ee70737e7b691c', subclient: '6517dd9077ee70737e7b6a45', package: 'pkg1', profile: '', componentsToCheck: [], status: 'OPEN' },
    { referenceNumber: 1002, client: '6597b649fa2251e033e944e8', subclient: '6597bd0dfa2251e033e945f2', package: '', profile: 'prof1', componentsToCheck: [], status: 'OPEN' }
];
const mockPersonalDetailsFields = [
    { name: 'name', mandatory: true },
    { name: 'dateofbirth', mandatory: true },
    { name: 'fathername', mandatory: true },
    { name: 'mobile', mandatory: true },
    { name: 'employeeid', mandatory: true },
    { name: 'pan', mandatory: true }
];

const DownloadTemplate = () => {
    const [action, setAction] = useState('DOWNLOAD-TEMPLATE');
    const [clients, setClients] = useState([]);
    const [subclients, setSubclients] = useState([]);
    const [packages, setPackages] = useState([]);
    const [profiles, setProfiles] = useState([]);
    const [components, setComponents] = useState(mockComponents);
    const [excelUploads, setExcelUploads] = useState([]);
    const [selectedExcelUploadReferenceNumber, setSelectedExcelUploadReferenceNumber] = useState('');
    const [formData, setFormData] = useState({
        clientId: '',
        subclientId: '',
        packageProfileAlacarte: '',
        package: '',
        profile: '',
        tat: '',
        price: ''
    });
    const [packageComponents, setPackageComponents] = useState([]);
    const [profileComponents, setProfileComponents] = useState([]);
    const [openDialog, setOpenDialog] = useState(false);
    const [excelFile, setExcelFile] = useState(null);
    const [zipFile, setZipFile] = useState(null);
    const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'info' });
    const [relevantContractId, setRelevantContractId] = useState('');

    useEffect(() => {
        const fetchClientData = async () => {
            try {
                let userId = localStorage.getItem('userId') || '';
                 const res = await api.get(`/usersubclientaccess/useremail/${userId}`);
                if (res.data) {
                    const clients = res.data.reduce((acc, item) => {
                        if (!acc.some(client => client._id === item.client._id)) {
                            acc.push({ _id: item.client._id, name: item.client.name });
                        }
                        return acc;
                    }, []);

                    const clientSubMap = res.data.reduce((map, item) => {
                        if (!map[item.client._id]) map[item.client._id] = [];
                        map[item.client._id].push({ _id: item.subclient._id, name: item.subclient.name });
                        return map;
                    }, {});

                    setClients(clients);
                    setSubclients(clientSubMap[clients[0]?._id] || []);
                    localStorage.setItem('clientSubclientMap', JSON.stringify(clientSubMap));
                }
            } catch (error) {
                console.error('Error fetching client/subclient data:', error);
                setSnackbar({ open: true, message: 'Failed to fetch client data', severity: 'error' });
            }
        };
        fetchClientData();

        // Set mock data for packages, profiles, and excel uploads
        setPackages(mockPackages);
        setProfiles(mockProfiles);
        if (action === 'UPLOAD-DATA') {
            setExcelUploads(mockExcelUploads);
        }
    }, [action]);

    const handleActionChange = (event) => {
        setAction(event.target.value);
        if (event.target.value !== 'UPLOAD-DATA') {
            setExcelUploads([]);
            setSelectedExcelUploadReferenceNumber('');
        }
    };

    const handleClientChange = (event) => {
        const clientId = event.target.value;
        setFormData({ ...formData, clientId, subclientId: '' });
        const clientSubMap = JSON.parse(localStorage.getItem('clientSubclientMap') || '{}');
        setSubclients(clientSubMap[clientId] || []);
        setRelevantContractId(`contract-${clientId}`);
        setPackages(mockPackages);
        setProfiles(mockProfiles);
        setComponents(mockComponents);
    };

    const handleSubclientChange = (event) => {
        setFormData({ ...formData, subclientId: event.target.value });
    };

    const handlePackageProfileAlacarteChange = (event) => {
        const value = event.target.value;
        setFormData({ ...formData, packageProfileAlacarte: value, package: '', profile: '' });
    };

    const handlePackageChange = (event) => {
        const packageId = event.target.value;
        setFormData({ ...formData, package: packageId });
        const selectedPackage = packages.find(pkg => pkg._id === packageId);
        setPackageComponents(selectedPackage?.clientContractPackageComponents || []);
        setFormData(prev => ({
            ...prev,
            tat: selectedPackage?.tat || '',
            price: selectedPackage?.price || ''
        }));
    };

    const handleProfileChange = (event) => {
        const profileId = event.target.value;
        setFormData({ ...formData, profile: profileId });
        const selectedProfile = profiles.find(prof => prof._id === profileId);
        setProfileComponents(selectedProfile?.clientContractProfileComponents || []);
        setFormData(prev => ({ ...prev, tat: selectedProfile?.tat || '' }));
    };

    const handleComponentChange = (index, field, value) => {
        const updatedComponents = [...components];
        updatedComponents[index][field] = value;
        setComponents(updatedComponents);
    };

    const handleExcelUploadChange = (event) => {
        const refNumber = event.target.value;
        setSelectedExcelUploadReferenceNumber(refNumber);
        const upload = excelUploads.find(upload => upload.referenceNumber === refNumber);
        if (upload) {
            setFormData({
                clientId: upload.client,
                subclientId: upload.subclient,
                packageProfileAlacarte: upload.package ? 'PACKAGE' : upload.profile ? 'PROFILE' : 'A-LA-CARTE',
                package: upload.package || '',
                profile: upload.profile || '',
                tat: '',
                price: ''
            });
            const clientSubMap = JSON.parse(localStorage.getItem('clientSubclientMap') || '{}');
            setSubclients(clientSubMap[upload.client] || []);
            setRelevantContractId(`contract-${upload.client}`);
            setPackages(mockPackages);
            setProfiles(mockProfiles);
            setComponents(upload.componentsToCheck.length > 0 ? upload.componentsToCheck : mockComponents);
            if (upload.package) {
                const selectedPackage = mockPackages.find(pkg => pkg._id === upload.package);
                setPackageComponents(selectedPackage?.clientContractPackageComponents || []);
            } else if (upload.profile) {
                const selectedProfile = mockProfiles.find(prof => prof._id === upload.profile);
                setProfileComponents(selectedProfile?.clientContractProfileComponents || []);
            }
        }
    };

    const handleBackClick = () => {
        window.history.back();
    };

    const handleDownloadExcelTemplate = async () => {
        const excelUpload = {
            client: formData.clientId,
            subclient: formData.subclientId,
            package: formData.packageProfileAlacarte === 'PACKAGE' ? formData.package : '',
            profile: formData.packageProfileAlacarte === 'PROFILE' ? formData.profile : '',
            componentsToCheck: formData.packageProfileAlacarte === 'A-LA-CARTE' ? components : [],
            status: 'OPEN'
        };
        const referenceNumber = Math.floor(Math.random() * 10000);
        const wb = XLSX.utils.book_new();
        wb.SheetNames.push('Data');
        const dataArray = [];
        mockPersonalDetailsFields.forEach(field => {
            if (field.mandatory) {
                dataArray.push(field.name === 'dateofbirth' ? 'personalDetails_dateofbirth(MM/DD/YYYY)' : `personalDetails_${field.name}`);
            }
        });
        const ws_data = [dataArray];
        const ws = XLSX.utils.aoa_to_sheet(ws_data);
        wb.Sheets['Data'] = ws;
        const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });
        const blob = new Blob([s2ab(wbout)], { type: 'application/octet-stream' });
        saveAs(blob, `${referenceNumber}.xlsx`);
        setSnackbar({ open: true, message: 'Excel template downloaded successfully', severity: 'success' });
    };

    const s2ab = (s) => {
        const buf = new ArrayBuffer(s.length);
        const view = new Uint8Array(buf);
        for (let i = 0; i < s.length; i++) view[i] = s.charCodeAt(i) & 0xFF;
        return buf;
    };

    const handleOpenUploadDialog = () => {
        setOpenDialog(true);
    };

    const handleCloseUploadDialog = () => {
        setOpenDialog(false);
        setExcelFile(null);
        setZipFile(null);
    };

    const handleFileChange = (event, type) => {
        const file = event.target.files[0];
        if (type === 'excel') setExcelFile(file);
        else if (type === 'zip') setZipFile(file);
    };

    const handleUpload = () => {
        if (!excelFile) {
            setSnackbar({ open: true, message: 'Please select an Excel file', severity: 'error' });
            return;
        }
        const aCase = {
            client: formData.clientId,
            subclient: formData.subclientId,
            batchId: selectedExcelUploadReferenceNumber,
            package: formData.packageProfileAlacarte === 'PACKAGE' ? formData.package : '',
            profile: formData.packageProfileAlacarte === 'PROFILE' ? formData.profile : '',
            tat: formData.tat,
            componentsToCheck: formData.packageProfileAlacarte === 'A-LA-CARTE' ? components.filter(comp => comp.selected) : []
        };
        const formDataToSend = new FormData();
        formDataToSend.append('excel', excelFile);
        if (zipFile) formDataToSend.append('zip', zipFile);
        formDataToSend.append('aCase', JSON.stringify(aCase));
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                const sheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[sheetName];
                const jsonData = XLSX.utils.sheet_to_json(worksheet);
                setSnackbar({ open: true, message: 'Files uploaded and processed successfully', severity: 'success' });
                handleCloseUploadDialog();
            } catch (error) {
                setSnackbar({ open: true, message: 'Failed to process Excel file', severity: 'error' });
            }
        };
        reader.readAsArrayBuffer(excelFile);
    };

    const handleSnackbarClose = () => {
        setSnackbar({ ...snackbar, open: false });
    };

    return (
        <Container sx={{ mt: 5, p: 4, bgcolor: 'background.paper', boxShadow: 1, borderRadius: 1 }}>
            <AppBar position="static" sx={{ mb: 4 }}>
                <Toolbar sx={{ flexDirection: 'column' }}>
                    <Box sx={{ width: '100%', display: 'flex', justifyContent: 'center' }}>
                        <Typography variant="h6">Download Excel Template</Typography>
                    </Box>
                    <Box sx={{ width: '100%', display: 'flex', justifyContent: 'flex-start' }}>
                        <IconButton onClick={handleBackClick} color="inherit" title="Go Back">
                            <ArrowBackIcon />
                        </IconButton>
                    </Box>
                </Toolbar>
            </AppBar>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                <Box sx={{ display: 'flex', gap: 5, ml: 8 }}>
                    <FormControl sx={{ width: '33%' }}>
                        <InputLabel>I want to</InputLabel>
                        <Select value={action} onChange={handleActionChange} label="I want to">
                            <MenuItem value="DOWNLOAD-TEMPLATE">Download Template</MenuItem>
                            <MenuItem value="UPLOAD-DATA">Upload Data</MenuItem>
                        </Select>
                    </FormControl>
                    {action === 'UPLOAD-DATA' && (
                        <FormControl sx={{ width: '25%', ml: 5 }}>
                            <InputLabel>Excel Upload Ref. No.</InputLabel>
                            <Select value={selectedExcelUploadReferenceNumber} onChange={handleExcelUploadChange} label="Excel Upload Ref. No.">
                                {excelUploads.map(upload => (
                                    <MenuItem key={upload.referenceNumber} value={upload.referenceNumber}>
                                        {upload.referenceNumber}
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                    )}
                </Box>
                <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                    <Box sx={{ display: 'flex', gap: 5, ml: 8 }}>
                        <FormControl sx={{ width: '33%' }}>
                            <InputLabel>Client</InputLabel>
                            <Select value={formData.clientId} onChange={handleClientChange} label="Client">
                                {clients.map(client => (
                                    <MenuItem key={client._id} value={client._id}>{client.name}</MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                        <FormControl sx={{ width: '25%' }}>
                            <InputLabel>Subclient</InputLabel>
                            <Select value={formData.subclientId} onChange={handleSubclientChange} label="Subclient">
                                {subclients.map(subclient => (
                                    <MenuItem key={subclient._id} value={subclient._id}>{subclient.name}</MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                        <FormControl sx={{ width: '25%' }}>
                            <InputLabel>Package / Profile / A la carte</InputLabel>
                            <Select value={formData.packageProfileAlacarte} onChange={handlePackageProfileAlacarteChange} label="Package / Profile / A la carte">
                                <MenuItem value="PACKAGE">Package</MenuItem>
                                <MenuItem value="PROFILE">Profile</MenuItem>
                                <MenuItem value="A-LA-CARTE">A la carte</MenuItem>
                            </Select>
                        </FormControl>
                    </Box>
                    <Box sx={{ display: 'flex', gap: 5, ml: 8, mt: 4 }}>
                        {formData.packageProfileAlacarte === 'PACKAGE' && (
                            <FormControl sx={{ width: '25%' }}>
                                <InputLabel>Select a Package</InputLabel>
                                <Select value={formData.package} onChange={handlePackageChange} label="Select a Package">
                                    <MenuItem value="selectOne">Select One</MenuItem>
                                    {packages.map(pkg => (
                                        <MenuItem key={pkg._id} value={pkg._id}>{pkg.name}</MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        )}
                        {formData.packageProfileAlacarte === 'PROFILE' && (
                            <FormControl sx={{ width: '25%' }}>
                                <InputLabel>Select a Profile</InputLabel>
                                <Select value={formData.profile} onChange={handleProfileChange} label="Select a Profile">
                                    <MenuItem value="selectOne">Select One</MenuItem>
                                    {profiles.map(prof => (
                                        <MenuItem key={prof._id} value={prof._id}>{prof.name}</MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        )}
                    </Box>
                </Box>
                {formData.packageProfileAlacarte === 'PACKAGE' && (
                    <TableContainer sx={{ height: 250 }}>
                        <Table>
                            <TableHead>
                                <TableRow sx={{ bgcolor: 'lightskyblue' }}>
                                    <TableCell colSpan={3} align="center" sx={{ color: 'white' }}>
                                        Components In Package
                                    </TableCell>
                                </TableRow>
                                <TableRow sx={{ bgcolor: 'lightskyblue' }}>
                                    <TableCell sx={{ color: 'white', width: '10%' }}>#</TableCell>
                                    <TableCell sx={{ color: 'white', width: '40%' }}>Component Name</TableCell>
                                    <TableCell sx={{ color: 'white', width: '50%' }}>Details</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {packageComponents.map((component, index) => (
                                    <TableRow key={index}>
                                        <TableCell>{index + 1}</TableCell>
                                        <TableCell>{component.componentName}</TableCell>
                                        <TableCell>{component.details}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                )}
                {formData.packageProfileAlacarte === 'PROFILE' && (
                    <TableContainer sx={{ height: 250 }}>
                        <Table>
                            <TableHead>
                                <TableRow sx={{ bgcolor: 'lightskyblue' }}>
                                    <TableCell colSpan={3} align="center" sx={{ color: 'white' }}>
                                        Components In Profile
                                    </TableCell>
                                </TableRow>
                                <TableRow sx={{ bgcolor: 'lightskyblue' }}>
                                    <TableCell sx={{ color: 'white', width: '10%' }}>#</TableCell>
                                    <TableCell sx={{ color: 'white', width: '40%' }}>Component Name</TableCell>
                                    <TableCell sx={{ color: 'white', width: '50%' }}>Details</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {profileComponents.map((component, index) => (
                                    <TableRow key={index}>
                                        <TableCell>{index + 1}</TableCell>
                                        <TableCell>{component.componentName}</TableCell>
                                        <TableCell>{component.details}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                )}
                {formData.packageProfileAlacarte === 'A-LA-CARTE' && (
                    <TableContainer sx={{ height: 250 }}>
                        <Table>
                            <TableHead>
                                <TableRow sx={{ bgcolor: 'lightskyblue' }}>
                                    <TableCell colSpan={7} align="center" sx={{ color: 'white' }}>
                                        Select Components to Check
                                    </TableCell>
                                </TableRow>
                                <TableRow sx={{ bgcolor: 'lightskyblue' }}>
                                    <TableCell sx={{ color: 'white', width: '10%' }}>#</TableCell>
                                    <TableCell sx={{ color: 'white', width: '20%' }}>Component Name</TableCell>
                                    <TableCell sx={{ color: 'white', width: '10%', textAlign: 'right' }}>TAT</TableCell>
                                    <TableCell sx={{ color: 'white', width: '10%', textAlign: 'right' }}>Rate per check</TableCell>
                                    <TableCell sx={{ color: 'white', width: '30%', textAlign: 'center' }}>Instructions</TableCell>
                                    <TableCell sx={{ color: 'white', width: '10%', textAlign: 'center' }}>Max. Checks</TableCell>
                                    <TableCell sx={{ color: 'white', width: '10%', textAlign: 'center' }}>Select</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {components.map((component, index) => (
                                    <TableRow key={index}>
                                        <TableCell>{index + 1}</TableCell>
                                        <TableCell>{component.componentName}</TableCell>
                                        <TableCell align="right">{component.tat}</TableCell>
                                        <TableCell align="right">{component.price}</TableCell>
                                        <TableCell align="center">
                                            <TextField
                                                value={component.instructions}
                                                onChange={(e) => handleComponentChange(index, 'instructions', e.target.value)}
                                                inputProps={{ maxLength: 200 }}
                                                size="small"
                                            />
                                        </TableCell>
                                        <TableCell align="center">
                                            <TextField
                                                value={component.maxChecks}
                                                onChange={(e) => handleComponentChange(index, 'maxChecks', e.target.value)}
                                                inputProps={{ maxLength: 2 }}
                                                size="small"
                                            />
                                        </TableCell>
                                        <TableCell align="center">
                                            <Checkbox
                                                checked={component.selected}
                                                onChange={(e) => handleComponentChange(index, 'selected', e.target.checked)}
                                            />
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                )}
                <Box sx={{ display: 'flex', justifyContent: 'flex-end', mr: 5, mb: 5 }}>
                    {action === 'DOWNLOAD-TEMPLATE' && (
                        <Button
                            variant="contained"
                            color="primary"
                            onClick={handleDownloadExcelTemplate}
                            startIcon={<GetAppIcon />}
                            sx={{ width: '33%' }}
                        >
                            Download Excel Template
                        </Button>
                    )}
                    {action === 'UPLOAD-DATA' && (
                        <Button
                            variant="contained"
                            color="primary"
                            onClick={handleOpenUploadDialog}
                            startIcon={<PublishIcon />}
                            sx={{ width: '33%' }}
                        >
                            Upload Files
                        </Button>
                    )}
                </Box>
            </Box>
            <Dialog open={openDialog} onClose={handleCloseUploadDialog}>
                <DialogTitle>Upload Files</DialogTitle>
                <DialogContent>
                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                        <TextField
                            type="file"
                            label="Excel File"
                            InputLabelProps={{ shrink: true }}
                            inputProps={{ accept: '.xlsx' }}
                            onChange={(e) => handleFileChange(e, 'excel')}
                            fullWidth
                        />
                        <TextField
                            type="file"
                            label="Zip File (Optional)"
                            InputLabelProps={{ shrink: true }}
                            inputProps={{ accept: '.zip' }}
                            onChange={(e) => handleFileChange(e, 'zip')}
                            fullWidth
                        />
                    </Box>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseUploadDialog}>Cancel</Button>
                    <Button onClick={handleUpload} variant="contained" color="primary">Upload</Button>
                </DialogActions>
            </Dialog>
            <Snackbar
                open={snackbar.open}
                autoHideDuration={4000}
                onClose={handleSnackbarClose}
                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
            >
                <Alert onClose={handleSnackbarClose} severity={snackbar.severity} sx={{ width: '100%' }}>
                    {snackbar.message}
                </Alert>
            </Snackbar>
        </Container>
    );
};

export default DownloadTemplate;