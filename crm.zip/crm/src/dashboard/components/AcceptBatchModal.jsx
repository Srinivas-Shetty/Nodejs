import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Grid,
  FormControl,
  InputLabel,
  Select,
  TextField,
  Button,
  Modal,
  Snackbar,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import MenuItem from "@mui/material/MenuItem";
import IconButton from "@mui/material/IconButton";
import DoneIcon from "@mui/icons-material/Done";
import CancelIcon from "@mui/icons-material/Cancel";
import DownloadIcon from "@mui/icons-material/Download";
import api from "../../auth/api";

const AcceptBatchModal = ({ modalData, onClose }) => {
  const [rows, setRows] = useState([]);
  const [client, setClient] = useState({});
  const [subclient, setSubclient] = useState({});
  const [caseCount, setCaseCount] = useState(0);
  const [packages, setPackages] = useState([]);
  const [profiles, setProfiles] = useState([]);
  const [packageOrProfile, setPackageOrProfile] = useState("-1");
  const [rejectionReason, setRejectionReason] = useState("");
  const [openModal, setOpenModal] = useState(false);
  const [selectedRow, setSelectedRow] = useState({})

  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "info",
  });

  const getBachData = async () => {
    try {
      const response = await api.get(
        `/batches/readbatchfiles/${modalData?._id}`
      );
      let respData = response.data.map((item, index) => {
        return {
          id: index + 1,
          fileName: item,
          candidateName: "",
          packageOrProfile: "-1",
          package: "-1",
          profile: "-1",
        };
      });

      setRows(respData);
    } catch (error) {
      console.log("error == ", error);
    }
  };

  const getRelevantClientContracts = async () => {
    let relevantContract_id = "";
    try {
      const response = await api.get(
        `/clientcontracts/client/${modalData?.client?._id}`
      );
      if (response.data) {
        let currentDate = new Date();
        for (let item of response.data) {
          if (
            currentDate > new Date(item.effectiveDate) &&
            currentDate < new Date(Date.parse(item.expiryDate))
          ) {
            relevantContract_id = item._id;
            break;
          }
        }
        getPackages(relevantContract_id);
        getProfiles(relevantContract_id);
      }
    } catch (error) {
      console.log("error == ", error);
    }
  };

  const getProfiles = async (clientContractId) => {
    try {
      const response = await api.get(
        `/clientcontractprofiles/clientcontract/${clientContractId}`
      );
      if (response.data) {
        setProfiles(response.data);
      }
    } catch (error) {
      console.log("Error Reading Packages == ", error);
    }
  };
  const getPackages = async (clientContractId) => {
    try {
      const response = await api.get(
        `/clientcontractpackages/clientcontract/${clientContractId}`
      );
      if (response.data) {
        setPackages(response.data);
      }
    } catch (error) {
      console.log("Error Reading Packages == ", error);
    }
  };

  const handleCandidateNameChange = (id, newValue) => {
    const updatedRows = rows.map((row) =>
      row.id === id ? { ...row, candidateName: newValue } : row
    );
    setRows(updatedRows);
  };

  const packageOrProfileChanged = (id, newValue) => {
    setPackageOrProfile(newValue);
    const updatedRows = rows.map((row) =>
      row.id === id ? { ...row, packageOrProfile: newValue } : row
    );
    setRows(updatedRows);
  };

  const packageChanged = (id, newValue) => {
    const updated = rows.map((row) =>
      row.id === id ? { ...row, package: newValue } : row
    );
    setRows(updated);
  };

  const profileChanged = (id, newValue) => {
    const updated = rows.map((row) =>
      row.id === id ? { ...row, package: newValue } : row
    );
    setRows(updated);
  };

  useEffect(() => {
    if (modalData?.client) {
      setClient(modalData?.client);
    }
    if (modalData?.subclient) {
      setSubclient(modalData?.subclient);
    }
    if (modalData?._id) {
      setCaseCount(modalData?.numberOfCases);
      getBachData();
    }
    getRelevantClientContracts();
  }, []);

  const acceptButtonClicked = async (row) => {
    let caseData = {
      client: client._id,
      subclient: subclient._id,
      candidateName: row?.candidateName,
      package: row?.packageOrProfile === "PACKAGE" ? row.package : null,
      profile: row.packageOrProfile === "PROFILE" ? row.profile : null,
      status: "INITIATED",
      batch: modalData?._id,
      caseFileName: row?.fileName,
    };

    try {
      const response = await api.post(`/cases/batchcase`, caseData);
      if (response.data) {
        console.log(`${response.data.caseId} Uploaded Successfully`);
        showMessage(`${response.data.caseId} Uploaded Successfully`);
        let data = rows.filter((item) => item !== row);
        setRows(data);
        if (data.length === 0) {
          onClose();
        }
      }
    } catch (error) {
      console.log("error = ", error);
      showError("Error Accepting Batches");
    }
  };

  const rejectButtonClicked = (row) => {
    setOpenModal(true)
    setSelectedRow(row)
  }

  const handleReject = async () => {
    const rejectedCase = {
      batch: modalData?._id,
      candidateName: selectedRow.candidateName,
      rejectionReason,
    };
    try {
      const response = await api.post(`/rejectedcases`,rejectedCase);
      if (response.data) {
        const deleteResponse = await api.post(`/batches/deletecasefile/${modalData?._id}/${selectedRow.fileName}`)
        const updatedRows = rows.filter((item) => item !== selectedRow);
        setRows(updatedRows);
        if (updatedRows.length === 0) {
          setOpenModal(false);
        }
      }
    } catch (error) {
      console.log("error = ", error);
      showError("Error Deleting Batches");
    }
  }

  const handleRejectionModalClose = () => {
    setRejectionReason("");
    setOpenModal(false); 
  };

  const showMessage = (msg) => {
    setSnackbar({ open: true, message: msg, severity: "info" });
  };

  const showError = (msg) => {
    setSnackbar({ open: true, message: msg, severity: "error" });
  };

  const handleSnackbarClose = () => {
    setSnackbar((prev) => ({ ...prev, open: false }));
  };

  const columns = [
    { field: "fileName", headerName: "File Name", flex: 1, minWidth: 100 },
    {
      field: "candidateName",
      headerName: "Candidate Name",
      flex: 1,
      minWidth: 150,
      renderCell: (params) => (
        <div style={{ padding: '5px' }}>
          <TextField
            required
            value={params.row.candidateName}
            onChange={(e) =>
              handleCandidateNameChange(params.row.id, e.target.value)
            }
          />
        </div>
      ),
    },
    {
      field: "packageOrProfile",
      headerName: "Package/Profile",
      flex: 1,
      minWidth: 120,
      renderCell: (params) => (
        <Select
          value={params.row.packageOrProfile}
          size="small"
          fullWidth
          onChange={(e) =>
            packageOrProfileChanged(params.row.id, e.target.value)
          }
        >
          <MenuItem value="-1">Select One</MenuItem>
          <MenuItem value="PACKAGE">Package</MenuItem>
          <MenuItem value="PROFILE">Profile</MenuItem>
        </Select>
      ),
    },
    {
      field: "package",
      headerName: "Package Name",
      flex: 1,
      minWidth: 120,
      renderCell: (params) => (
        <Select
          value={params.row.package}
          onChange={(e) => packageChanged(params.row.id, e.target.value)}
          disabled={
            params.row.packageOrProfile === "-1" ||
            params.row.packageOrProfile === "PROFILE"
          }
        >
          <MenuItem value="-1">Select One</MenuItem>
          {packages.map((item, index) => (
            <MenuItem key={index} value={item._id}>
              {item.name}
            </MenuItem>
          ))}
        </Select>
      ),
    },
    {
      field: "profile",
      headerName: "Profile Name",
      flex: 1,
      minWidth: 120,
      renderCell: (params) => (
        <Select
          value={params.row.profile}
          onChange={(e) => profileChanged(params.row.id, e.target.value)}
          disabled={
            params.row.packageOrProfile === "-1" ||
            params.row.packageOrProfile === "PACKAGE"
          }
        >
          <MenuItem value="-1">Select One</MenuItem>
          {profiles.map((item, index) => (
            <MenuItem key={index} value={item._id}>
              {item.name}
            </MenuItem>
          ))}
        </Select>
      ),
    },
    {
      field: "accept",
      headerName: "Accept",
      renderCell: (params) => (
        <IconButton
          color="success"
          onClick={() => acceptButtonClicked(params.row)}
          sx={{ border: "none", color: "blue" }}
          disabled={
            params.row.candidateName === "" ||
            params.row.packageOrProfile === "-1" ||
            (params.row.package === "-1" && params.row.profile === "-1")
          }
        >
          <DoneIcon />
        </IconButton>
      ),
    },
    {
      field: "reject",
      headerName: "Reject",
      renderCell: (params) => (
        <IconButton
          color="error"
          onClick={() => rejectButtonClicked(params.row)}
          sx={{ border: "none", color: "red" }}
        >
          <CancelIcon />
        </IconButton>
      ),
    },
  ];

  return (
    <>
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          bgcolor: "background.paper",
          boxShadow: 24,
          p: 4,
          borderRadius: 2,
          width: "90%",
          height: "60%",
          textAlign: "center",
        }}
      >
        <Typography component="h2" variant="h6" sx={{ mb: 2 }}>
          Accept Batch
        </Typography>

        <Box sx={{ display: "flex", gap: 3, mb: 4, flexWrap: "wrap" }}>
          <FormControl required sx={{ width: "30%" }}>
            <TextField
              id="outlined-disabled"
              label="Client"
              value={client?.name}
              slotProps={{
                input: {
                  readOnly: true,
                },
              }}
            />
          </FormControl>

          <FormControl required sx={{ width: "30%" }}>
            <TextField
              id="outlined-disabled"
              label="Subclient"
              value={subclient?.name}
              slotProps={{
                input: {
                  readOnly: true,
                },
              }}
            />
          </FormControl>
          <FormControl>
            <TextField
              id="outlined-disabled"
              label="No. of Cases"
              value={caseCount}
              slotProps={{
                input: {
                  readOnly: true,
                },
              }}
            />
          </FormControl>

          <Button
            variant="contained"
            color="secondary"
            sx={{ margin: "0 16px" }}
            onClick={""}
          >
            Download Zip File <DownloadIcon />
          </Button>

          <Box sx={{ width: "700%", height: "100vh", overflow: "hidden" }}>
            <Grid container spacing={2}>
              <Grid item xs={12} sx={{ width: "100%" }}>
                <Box sx={{ height: 200, width: "100%" }}>
                  <DataGrid
                    rows={rows}
                    columns={columns}
                    disableRowSelectionOnClick
                    rowHeight={70}
                    getRowClassName={(params) =>
                      params.indexRelativeToCurrentPage % 2 === 0
                        ? "even"
                        : "odd"
                    }
                    initialState={{
                      pagination: { paginationModel: { pageSize: 5 } },
                    }}
                    pageSizeOptions={[10, 20, 50]}
                    density="compact"
                    sx={{
                      whiteSpace: "normal",
                      "& .MuiDataGrid-cell:focus": {
                        outline: "none",
                        backgroundColor: "transparent",
                      },
                      "& .MuiDataGrid-cell:focus-within": {
                        outline: "none",
                      },
                      "& .MuiDataGrid-cell *:focus": {
                        outline: "none",
                        boxShadow: "none",
                        backgroundColor: "transparent",
                      },
                      "& .MuiDataGrid-columnHeaders": {
                        backgroundColor: "#f5f5f5",
                        fontWeight: "bold",
                      },
                    }}
                  />

                  {/* <Box sx={{ width: "100%" }}>
                  <TableContainer component={Paper}
                  sx={{ maxHeight: 400, overflowY: "auto" }}>
                    <Table stickyHeader size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell>File Name</TableCell>
                          <TableCell>Candidate Name</TableCell>
                          <TableCell>Package/Profile</TableCell>
                          <TableCell>Package Name</TableCell>
                          <TableCell>Profile Name</TableCell>
                          <TableCell>Accept</TableCell>
                          <TableCell>Reject</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {rows.map((row) => (
                          <TableRow key={row.id} >
                            <TableCell>{row.fileName}</TableCell>
                            <TableCell>
                              <TextField
                                required
                                label="Candidate Name"
                                value={row.candidateName}
                                onChange={(e) =>
                                  handleCandidateNameChange(
                                    row.id,
                                    e.target.value
                                  )
                                }
                              />
                            </TableCell>
                            <TableCell>
                              <Select
                                value={row.packageOrProfile}
                                size="small"
                                fullWidth
                                onChange={(e) =>
                                  packageOrProfileChanged(
                                    row.id,
                                    e.target.value
                                  )
                                }
                              >
                                <MenuItem value="-1">Select One</MenuItem>
                                <MenuItem value="PACKAGE">Package</MenuItem>
                                <MenuItem value="PROFILE">Profile</MenuItem>
                              </Select>
                            </TableCell>
                            <TableCell>
                              <Select
                                value={row.package}
                                onChange={(e) =>
                                  packageChanged(row.id, e.target.value)
                                }
                                disabled={
                                  packageOrProfile === "-1" ||
                                  packageOrProfile === "PROFILE"
                                }
                              >
                                <MenuItem value="-1">Select One</MenuItem>
                                {packages.map((item, index) => (
                                  <MenuItem key={index} value={item._id}>
                                    {item.name}
                                  </MenuItem>
                                ))}
                              </Select>
                            </TableCell>
                            <TableCell>
                              <Select
                                value={row.profile}
                                onChange={(e) =>
                                  profileChanged(row.id, e.target.value)
                                }
                                disabled={
                                  packageOrProfile === "-1" ||
                                  packageOrProfile === "PACKAGE"
                                }
                              >
                                <MenuItem value="-1">Select One</MenuItem>
                                {profiles.map((item, index) => (
                                  <MenuItem key={index} value={item._id}>
                                    {item.name}
                                  </MenuItem>
                                ))}
                              </Select>
                            </TableCell>
                            <TableCell>
                              <IconButton
                                color="success"
                                onClick={() => acceptButtonClicked(row)}
                                sx={{border: 'none', color: 'blue'}}
                                disabled={row.candidateName == '' || row.packageOrProfile == '-1' || (row.package=='-1' && row.profile=='-1')}
                              >
                                <DoneIcon />
                              </IconButton>
                            </TableCell>
                            <TableCell>
                              <IconButton
                                color="error"
                                onClick={() => console.log("Rejected:", row)}
                                sx={{border: 'none', color: 'red'}}
                              >
                                <CancelIcon />
                              </IconButton>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>

</Box> */}
                </Box>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Box>
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={handleSnackbarClose}
        message={snackbar.message}
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
      />
      <Modal open={openModal}>
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 4,
            borderRadius: 2,
            width: "50%",
            height: "40%",
            textAlign: "center",
          }}
        >
          <Typography component="h2" variant="h6" sx={{ mb: 2 }}>
            Reject Batch
          </Typography>

          <Box sx={{ mt: 2 }}>
            <TextField
              label="Rejection Comments"
              placeholder="Rejection Comments"
              fullWidth
              required
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              sx={{height: '0px'}}
            />
            {/* <TextField id="outlined-basic" label="Rejection Comments" variant="outlined" /> */}
          </Box>

          <Box
            sx={{ mt: "2rem", display: "flex", justifyContent: "flex-end", gap: 2 }}
          >
            <Button
              required
              variant="contained"
              color="secondary"
              onClick={handleReject}
              disabled={rejectionReason.trim() === ""}
            >
              OK
            </Button>
            <Button variant="contained" onClick={handleRejectionModalClose}>
              Close
            </Button>
          </Box>
        </Box>
      </Modal>
    </>
  );
};

export default AcceptBatchModal;
