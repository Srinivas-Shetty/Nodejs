import React, { useState, useEffect } from 'react';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import PageViewsBarChart from './PageViewsBarChart';
import SessionsChart from './SessionsChart';
import StatCard from './StatCard';
import api from '../../auth/api';
import TatGraph from './TatGraphChart';
import ClientDashboard from './DashboardCount';
import ClientCaseBreak from './ClientCaseBreakDownChart';
import TatStatusChart from './TatGraphChart';
import ClientDashboard2 from './DashboardCount2';
import FinalMonthsTatChart from './FinalMonthsTatChart';

export default function MainGrid() {
  const [dashboardData, setDashboardData] = useState([])

  const getClientDashboard = async () => {
    try {
      const response = await api.get(`/cases/getClientCaseDataForDashboard?clientId=606492f37e2f346e622d5aff`)
      if (response.data) {
        setDashboardData(response.data)
        let obj = Object.keys(response.data).filter(val => (val === 'inflow') || (val === 'outflow') || (val === 'wip'))
        let data = obj.map(val => {
          return {
            title: val ? `${val[0].toLocaleUpperCase()}${val.slice(1).toLocaleUpperCase()}` : '',
            value: response.data[val],
            interval: 'Last 30 days',
            trend: 'neutral',
          }
        })
        setDashboardData(data)
      }
    } catch (error) {
      console.log('error = ', error);
    }
  }

  useEffect(() => {
    getClientDashboard()
  }, [])


  return (
    <Box sx={{ width: '100%', maxWidth: { sm: '100%', md: '1700px' } }}>
      {/* cards */}
      <Typography component="h2" variant="h6" sx={{ mb: 2 }}>
        Overview
      </Typography>
      <Grid
        container
        spacing={2}
        columns={12}
        sx={{ mb: (theme) => theme.spacing(2) }}
      >
        {/* {dashboardData.map((card, index) => ( */}
           {/* <Grid key={index} size={{ xs: 12, sm: 6, lg: 3 }}>
             <StatCard {...card} />
           </Grid> */}
        {/* ))} */}
           <Grid size={{xs:20,md:12}}>
          <ClientDashboard2/>
        </Grid>
          {/* <Grid size={{xs:20,md:12}}>
          <ClientDashboard/>
        </Grid> */}
        <Grid size={{ xs: 12, md: 8 }}>
          <SessionsChart />
        </Grid>
          <Grid size={{xs:12,md:4}}>
          <ClientCaseBreak/>
        </Grid>
        <Grid size={{ xs: 12, md: 6 }}>
          <FinalMonthsTatChart TATname={'Final'} />
        </Grid>
        <Grid size={{ xs: 12, md: 6 }}>
          <FinalMonthsTatChart TATname={'Interim'} />
        </Grid>
        {/* <Grid size={{ xs: 12, md: 6 }}>
          <TatGraph />
        </Grid> */}
        {/* <Grid size={{xs:12,md:6}}>
          <TatStatusChart/>

        </Grid> */}
      </Grid>
    </Box>
  );
}
