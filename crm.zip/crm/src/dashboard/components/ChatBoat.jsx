import React, { useState } from "react";

const ChatBotOptions = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [theme, setTheme] = useState("light");
  const [messages, setMessages] = useState([
    {type:"bot" , text:"Hi, How can I help you..?" }
  ]);
  const [input, setInput] = useState("");
  const [currentOptions, setCurrentOptions] = useState([]);
  const [subOptions, setSubOptions] = useState([]);

  const toggleChat = () => setIsOpen(!isOpen);

  const resetChat = () => {
    setMessages([]);
    setCurrentOptions([]);
    setSubOptions([]);
    setInput("");
  };

  const options = [
    {
      label: "Case Upload",
      instruction:
        "To upload a case, go to the Cases page, click 'Upload', select the file, and submit.",
    },
    {
      label: "View Reports",
      instruction:
        "To view reports, navigate to the Reports tab and select your desired report type.",
    },
    {
      label: "Raise Ticket",
      instruction:
        "To raise a ticket, click on the Support section and fill out the form with issue details.",
    },
    {
      label: "Checks Provided",
     subOptions: [
        {
          label: "Education Verification",
          instruction: "Education can be verified through Colleges, Universities High schools, Study Centers and other Professional Certifications Authorities",

        },
        {
          label: "Employment Verification",
          instruction: "This Verifications are conducted by contacting previous employers to verify an applicant’s job title, tenure and salary claims. Reasons for leaving and eligibility for rehire are also confirmed.",
        },
        {
          label: "Reference Verification",
          instruction: "A email is sent to a person who can provide unbiased feedback based on their insight into Candidates work ethic, skills, strengths, and achievements",
        },
         {
          label: "Address Verification (Physical)",
          instruction: "Adamma field analyst will visit the candidate residential address provided by the candidate",
        },
          {
          label: "Address Verification (Digital)",
          instruction: "The time taken for Digital Address Verification defends on the candidate, completion of adress verification based on provided link shared",
        },
         {
          label: "Court Record Verification",
          instruction: "CRC-Adamma empaneled advocates to cross verify criminal records of candidate through various courts in the district (Magistrate court / Civil Court / Session Court) report provided by advocate with seal and signature",
        },
        {
          label: "Identity Verification (PAN/DL/VOTER)",
          instruction: "Identity proofs (Voter ID / Driving License / PAN / Aadhar) verified through authorized online government portals / concerned government offices",
        },
         {
          label: "Passport Validation",
          instruction: "Passport validation",
        },
        {
          label: "Global Database Verification (IDB)",
          instruction: "Candidate’s information collected and searched through the international portal of Compliance Database Check and detailed report obtained from World Check portal pertaining to candidate compliance database check.",
        },
        {
          label: "Credit History Verification",
          instruction: "Adamma conducts Credit Check in association with cibil, credit scores and reports help give a clear picture of the credit history and financial reputation of individual or business.",
        },

        {
          label: "Resume Check",
          instruction: "Resume check",
        },
        {
          label: "GAP Verification",
          instruction: "Gap analysis refers to a check where our team will thoroughly scrutinize the Resume and documents shared to check the Gaps in between Education and Employments and other info",
        },
        {
          label: "Social Media Verification",
          instruction: "Adamma will verify overall social media behavior in his or her posts on various social media platforms such as Facebook, Instagram and Twitter or posts shared by others tagging the candidate",
        },
         {
          label: "Drug Test",
          instruction: "The time taken for Digital Address Verification depends on the candidate, The address will be captured with geotagging based on provided link shared",
        },
        
      ],
    },
  ];

  const toggleTheme = () =>
    setTheme((prev) => (prev === "light" ? "dark" : "light"));

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage = { type: "user", text: input };
    const botMessage = {
      type: "bot",
      text: "Please select an option below for more details.",
    };

    setMessages((prev) => [...prev, userMessage, botMessage]);
    setInput("");
    setCurrentOptions(options);
    setSubOptions([]);
  };

  const handleOptionClick = (option) => {
    const userMessage = { type: "user", text: option.label };

    if (option.subOptions) {
      const botMessage = {
        type: "bot",
        text: "Please select the type of check provided:",
      };
      setMessages((prev) => [...prev, userMessage, botMessage]);
      setSubOptions(option.subOptions);
      setCurrentOptions([]);
    } else {
      const botMessage = { type: "bot", text: option.instruction };
      setMessages((prev) => [...prev, userMessage, botMessage]);
      setCurrentOptions([]);
      setSubOptions([]);
    }
  };

  const handleSubOptionClick = (sub) => {
    const userMessage = { type: "user", text: sub.label };
    const botMessage = { type: "bot", text: sub.instruction };
    setMessages((prev) => [...prev, userMessage, botMessage]);

    const remainingSubOptions = subOptions.filter((s) => s.label !== sub.label);
    setSubOptions(remainingSubOptions);
  };

  return (
    <div>
      {/* Floating button */}
      <div
        onClick={toggleChat}
        style={{
          position: "fixed",
          bottom: "20px",
          right: "20px",
          width: "60px",
          height: "60px",
          backgroundColor: "#1976d2",
          borderRadius: "50%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          color: "white",
          fontSize: "30px",
          cursor: "pointer",
          boxShadow: "0px 4px 12px rgba(0,0,0,0.3)",
          animation: "pulse 2s infinite",
          zIndex: 9999,
        }}
      >
        🤖
      </div>

      {/* Chat window */}
      {isOpen && (
        <div
          style={{
            position: "fixed",
            bottom: "90px",
            right: "20px",
            width: "300px",
            height: "450px",
            backgroundColor: theme === "light" ? "white" : "#333",
            color: theme === "light" ? "black" : "white",
            borderRadius: "10px",
            boxShadow: "0px 4px 12px rgba(0,0,0,0.3)",
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
            zIndex: 9999,
          }}
        >
          {/* Header */}
          <div
            style={{
              backgroundColor: "#1976d2",
              color: "white",
              padding: "10px",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
              <div
                style={{
                  width: "8px",
                  height: "8px",
                  borderRadius: "50%",
                  backgroundColor: "limegreen",
                }}
              ></div>
              <span>Sharath is online</span>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: "-70px" }}>
              <button
                onClick={resetChat}
                style={{
                  background: "transparent",
                  border: "none",
                  color: "white",
                  cursor: "pointer",
                  fontSize: "14px",
                }}
                title="Refresh Chat"
              >
                🔄
              </button>
              <button
                onClick={toggleTheme}
                style={{
                  background: "transparent",
                  border: "none",
                  color: "white",
                  cursor: "pointer",
                  fontSize: "14px",
                }}
                title="Toggle Theme"
              >
                {theme === "light" ? "🌙" : "☀️"}
              </button>
              <button
                onClick={toggleChat}
                style={{
                  background: "transparent",
                  border: "none",
                  color: "white",
                  cursor: "pointer",
                  fontSize: "14px",
                }}
                title="Close Chat"
              >
                ❌
              </button>
            </div>
          </div>

          {/* Messages */}
          <div
            style={{
              flex: 1,
              padding: "10px",
              overflowY: "auto",
              display: "flex",
              flexDirection: "column",
              gap: "10px",
            }}
          >
            {messages.map((msg, index) => (
              <div
                key={index}
                style={{
                  alignSelf: msg.type === "user" ? "flex-end" : "flex-start",
                  backgroundColor:
                    msg.type === "user"
                      ? "#1976d2"
                      : theme === "light"
                      ? "#f1f1f1"
                      : "#555",
                  color: msg.type === "user" ? "white" : "inherit",
                  borderRadius: "10px",
                  padding: "8px 12px",
                  maxWidth: "80%",
                  wordWrap: "break-word",
                }}
              >
                {msg.text}
              </div>
            ))}

            {/* Options */}
            {currentOptions.length > 0 && (
              <div style={{ marginTop: "10px" }}>
                {currentOptions.map((option, index) => (
                  <div
                    key={index}
                    onClick={() => handleOptionClick(option)}
                    style={{
                      padding: "8px 12px",
                      marginBottom: "5px",
                      backgroundColor: "#1976d2",
                      color: "white",
                      borderRadius: "5px",
                      cursor: "pointer",
                    }}
                  >
                    {option.label}
                  </div>
                ))}
              </div>
            )}

            {/* Sub-options */}
            {subOptions.length > 0 && (
              <div style={{ marginTop: "10px" }}>
                {subOptions.map((sub, index) => (
                  <div
                    key={index}
                    onClick={() => handleSubOptionClick(sub)}
                    style={{
                      padding: "8px 12px",
                      marginBottom: "5px",
                      backgroundColor: "#1976d2",
                      color: "white",
                      borderRadius: "5px",
                      cursor: "pointer",
                    }}
                  >
                    {sub.label}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Input */}
          <div
            style={{
              borderTop: "1px solid #ccc",
              padding: "10px",
              display: "flex",
              gap: "5px",
            }}
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your question..."
              style={{
                flex: 1,
                padding: "8px",
                borderRadius: "5px",
                border: "1px solid #ccc",
              }}
            />
            <button
              onClick={handleSend}
              style={{
                padding: "8px 12px",
                backgroundColor: "#1976d2",
                color: "white",
                border: "none",
                borderRadius: "5px",
                cursor: "pointer",
              }}
            >
              Send
            </button>
          </div>
        </div>
      )}

      {/* CSS animation */}
      <style>
        {`
          @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
          }
        `}
      </style>
    </div>
  );
};

export default ChatBotOptions;
