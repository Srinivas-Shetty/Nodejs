// import * as React from 'react';
// import PropTypes from 'prop-types';
// import { useTheme } from '@mui/material/styles';
// import Card from '@mui/material/Card';
// import CardContent from '@mui/material/CardContent';
// import Chip from '@mui/material/Chip';
// import Typography from '@mui/material/Typography';
// import Stack from '@mui/material/Stack';
// import { LineChart } from '@mui/x-charts/LineChart';

// function AreaGradient({ color, id }) {
//   return (
//     <defs>
//       <linearGradient id={id} x1="50%" y1="0%" x2="50%" y2="100%">
//         <stop offset="0%" stopColor={color} stopOpacity={0.5} />
//         <stop offset="100%" stopColor={color} stopOpacity={0} />
//       </linearGradient>
//     </defs>
//   );
// }

// AreaGradient.propTypes = {
//   color: PropTypes.string.isRequired,
//   id: PropTypes.string.isRequired,
// };

// function getDaysInMonth(month, year) {
//   const date = new Date(year, month, 0);
//   const monthName = date.toLocaleDateString('en-US', {
//     month: 'short',
//   });
//   const daysInMonth = date.getDate();
//   const days = [];
//   let i = 1;
//   while (days.length < daysInMonth) {
//     days.push(`${monthName} ${i}`);
//     i += 1;
//   }
//   return days;
// }

// export default function SessionsChart() {
//   const theme = useTheme();
//   const data = getDaysInMonth(4, 2024);

//   const colorPalette = [
//     theme.palette.primary.light,
//     theme.palette.primary.main,
//     theme.palette.primary.dark,
//   ];

//   return (
//     <Card variant="outlined" sx={{ width: '100%' }}>
//       <CardContent>
//         <Typography component="h2" variant="subtitle2" gutterBottom>
//           Sessions
//         </Typography>
//         <Stack sx={{ justifyContent: 'space-between' }}>
//           <Stack
//             direction="row"
//             sx={{
//               alignContent: { xs: 'center', sm: 'flex-start' },
//               alignItems: 'center',
//               gap: 1,
//             }}
//           >
//             <Typography variant="h4" component="p">
//               13,277
//             </Typography>
//             <Chip size="small" color="success" label="+35%" />
//           </Stack>
//           <Typography variant="caption" sx={{ color: 'text.secondary' }}>
//             Sessions per day for the last 30 days
//           </Typography>
//         </Stack>
//         <LineChart
//           colors={colorPalette}
//           xAxis={[
//             {
//               scaleType: 'point',
//               data,
//               tickInterval: (index, i) => (i + 1) % 5 === 0,
//             },
//           ]}
//           series={[
//             {
//               id: 'direct',
//               label: 'Direct',
//               showMark: false,
//               curve: 'linear',
//               stack: 'total',
//               area: true,
//               stackOrder: 'ascending',
//               data: [
//                 300, 900, 600, 1200, 1500, 1800, 2400, 2100, 2700, 3000, 1800, 3300,
//                 3600, 3900, 4200, 4500, 3900, 4800, 5100, 5400, 4800, 5700, 6000,
//                 6300, 6600, 6900, 7200, 7500, 7800, 8100,
//               ],
//             },
//             {
//               id: 'referral',
//               label: 'Referral',
//               showMark: false,
//               curve: 'linear',
//               stack: 'total',
//               area: true,
//               stackOrder: 'ascending',
//               data: [
//                 500, 900, 700, 1400, 1100, 1700, 2300, 2000, 2600, 2900, 2300, 3200,
//                 3500, 3800, 4100, 4400, 2900, 4700, 5000, 5300, 5600, 5900, 6200,
//                 6500, 5600, 6800, 7100, 7400, 7700, 8000,
//               ],
//             },
//             {
//               id: 'organic',
//               label: 'Organic',
//               showMark: false,
//               curve: 'linear',
//               stack: 'total',
//               stackOrder: 'ascending',
//               data: [
//                 1000, 1500, 1200, 1700, 1300, 2000, 2400, 2200, 2600, 2800, 2500,
//                 3000, 3400, 3700, 3200, 3900, 4100, 3500, 4300, 4500, 4000, 4700,
//                 5000, 5200, 4800, 5400, 5600, 5900, 6100, 6300,
//               ],
//               area: true,
//             },
//           ]}
//           height={250}
//           margin={{ left: 50, right: 20, top: 20, bottom: 20 }}
//           grid={{ horizontal: true }}
//           sx={{
//             '& .MuiAreaElement-series-organic': {
//               fill: "url('#organic')",
//             },
//             '& .MuiAreaElement-series-referral': {
//               fill: "url('#referral')",
//             },
//             '& .MuiAreaElement-series-direct': {
//               fill: "url('#direct')",
//             },
//           }}
//           slotProps={{
//             legend: {
//               hidden: true,
//             },
//           }}
//         >
//           <AreaGradient color={theme.palette.primary.dark} id="organic" />
//           <AreaGradient color={theme.palette.primary.main} id="referral" />
//           <AreaGradient color={theme.palette.primary.light} id="direct" />
//         </LineChart>
//       </CardContent>
//     </Card>
//   );
// }

//orginal code

// import * as React from 'react';
// import PropTypes from 'prop-types';
// import { useTheme } from '@mui/material/styles';
// import Card from '@mui/material/Card';
// import CardContent from '@mui/material/CardContent';
// import Typography from '@mui/material/Typography';
// import CircularProgress from '@mui/material/CircularProgress';
// import { LineChart } from '@mui/x-charts/LineChart';
// import api from '../../auth/api';

// function AreaGradient({ color, id }) {
//   return (
//     <defs>
//       <linearGradient id={id} x1="50%" y1="0%" x2="50%" y2="100%">
//         <stop offset="0%" stopColor={color} stopOpacity={0.5} />
//         <stop offset="100%" stopColor={color} stopOpacity={0} />
//       </linearGradient>
//     </defs>
//   );
// }

// AreaGradient.propTypes = {
//   color: PropTypes.string.isRequired,
//   id: PropTypes.string.isRequired,
// };

// export default function SessionsChart() {
//   const theme = useTheme();

//   // Simulate data loading
//   const [loading, setLoading] = React.useState(true);
//   const [data, setData] = React.useState(null);
//   const [monthlyData, setMonthlyData] = React.useState({ xAxis: [],series: []})

//   React.useEffect(() => {
//     // Simulating async data fetch
//     setTimeout(() => {
//       const days = Array.from({ length: 30 }, (_, i) => `Apr ${i + 1}`);
//       setData({
//         xAxis: [
//           {
//             scaleType: 'point',
//             data: days,
//             tickInterval: (index, i) => (i + 1) % 5 === 0,
//           },
//         ],
//         series: [
//           {
//             id: 'inflow',
//             label: 'Inflow',
//             data: Array.from({ length: 30 }, () => Math.floor(Math.random() * 5000 + 1000)),
//             showMark: false,
//             area: true,
//             curve: 'linear',
//             stack: 'total',
//             stackOrder: 'ascending',
//           },
//           {
//             id: 'outflow',
//             label: 'Outflow',
//             data: Array.from({ length: 30 }, () => Math.floor(Math.random() * 5000 + 1000)),
//             showMark: false,
//             area: true,
//             curve: 'linear',
//             stack: 'total',
//             stackOrder: 'ascending',
//           },
//         ],
//       });
//     }, 1500);
//   }, []);

// const getLastSixMonthsCaseInitiationCount = async () => {
//     try {
//       const params = new URLSearchParams();
  
//       // if (clientId) {
//       //   params.append('clientId', clientId);
//       // }
  
//       // if (clientIds?.length) {
//       //   params.append('clientId', clientIds.join(','));
//       // }
  
//       const inflowResponse = await api.get(`/caseInitiation/lastSixMonthsCaseInitiationData`, {
//         params,
//       });

//       const outflowResponse = await api.get(`/caseInitiation/lastSixMonthsOutputQcCompletionCount`, {
//         params,
//       });

//       let xAxis = [
//         {
//           scaleType: 'point',
//           data: inflowResponse.data?.map(item => item[0]),
//         },
//       ]

//       let inflowYAxis = inflowResponse.data?.map(item => item[1])
//       let outflowYAxis = outflowResponse.data?.map(item => item[1])

//       const inflowSeries = {
//         id: 'inflow',
//         label: 'Inflow',
//         data: inflowYAxis,
//         showMark: false,
//         area: true,
//         curve: 'linear',
//         stack: 'total',
//         stackOrder: 'ascending',
//       }

//       const outflowSeries = {
//         id: 'outflow',
//         label: 'outflow',
//         data: outflowYAxis,
//         showMark: false,
//         area: true,
//         curve: 'linear',
//         stack: 'total',
//         stackOrder: 'ascending',
//       }
//       setMonthlyData({xAxis, series: [inflowSeries, outflowSeries]})
//     } catch (error) {
//       console.error('Error fetching case initiation data:', error);
//     } finally {
//       setLoading(false)
//     }
//   };

//   React.useEffect(() => {
//     getLastSixMonthsCaseInitiationCount()
//   }, [])

//   const colorPalette = [
//     theme.palette.primary.light,
//     theme.palette.primary.dark,
//   ];

//   return (
//     <Card variant="outlined" sx={{ width: '100%' }}>
//       <CardContent>
//         <Typography component="h2" variant="subtitle1" gutterBottom>
//           Case Inflow and Outflow for the Month
//         </Typography>

//         {loading ? (
//           <div style={{ display: 'flex', justifyContent: 'center', padding: '40px 0' }}>
//             <CircularProgress />
//           </div>
//         ) : (
//           <LineChart
//             height={360}
//             colors={colorPalette}
//             xAxis={monthlyData.xAxis}
//             series={monthlyData.series}
//             margin={{ left: 50, right: 20, top: 20, bottom: 20 }}
//             grid={{ horizontal: true }}
//             sx={{
//               '& .MuiAreaElement-series-inflow': {
//                 fill: "url('#inflow')",
//               },
//               '& .MuiAreaElement-series-outflow': {
//                 fill: "url('#outflow')",
//               },
//             }}
//             slotProps={{
//               legend: {
//                 hidden: false,
//               },
//             }}
//           >
//             <AreaGradient color={theme.palette.primary.light} id="inflow" />
//             <AreaGradient color={theme.palette.primary.dark} id="outflow" />
//           </LineChart>
//         )}
//       </CardContent>
//     </Card>
//   );
// }
  

// full flow of graph..............

// import * as React from 'react';
// import PropTypes from 'prop-types';
// import { useTheme } from '@mui/material/styles';
// import {
//   Card,
//   CardContent,
//   Typography,
//   CircularProgress,
//   Grid,
//   Box,
//   MenuItem,
//   Select,
//   FormControl,
//   InputLabel,
//   Stack,
// } from '@mui/material';
// import { LineChart } from '@mui/x-charts/LineChart';
// import { BarChart } from '@mui/x-charts/BarChart';
// import { PieChart } from '@mui/x-charts/PieChart';
// import api from '../../auth/api';

// function AreaGradient({ color, id }) {
//   return (
//     <defs>
//       <linearGradient id={id} x1="50%" y1="0%" x2="50%" y2="100%">
//         <stop offset="0%" stopColor={color} stopOpacity={0.5} />
//         <stop offset="100%" stopColor={color} stopOpacity={0} />
//       </linearGradient>
//     </defs>
//   );
// }

// AreaGradient.propTypes = {
//   color: PropTypes.string.isRequired,
//   id: PropTypes.string.isRequired,
// };

// export default function SessionsChart() {
//   const theme = useTheme();

//   const [loading, setLoading] = React.useState(true);
//   const [monthlyData, setMonthlyData] = React.useState({ xAxis: [], series: [] });
//   const [selectedDays, setSelectedDays] = React.useState('7');

//   const [tatType, setTatType] = React.useState('in');
//   const [packageType, setPackageType] = React.useState('all');
//   const [tatDuration, setTatDuration] = React.useState('6_months');
//   const [severityDuration, setSeverityDuration] = React.useState('30');


//   const handleTatTypeChange = (e) => setTatType(e.target.value);
//   const handlePackageChange = (e) => setPackageType(e.target.value);
//   const handleTatDurationChange = (e) => setTatDuration(e.target.value);
//   const handleSeverityDurationChange = (e) => setSeverityDuration(e.target.value);


//   const handleDaysChange = (event) => {
//     setSelectedDays(event.target.value);
//   };

//   const [highlightSeries, setHighlightSeries] = React.useState('inflow');


// //   const getLastSixMonthsCaseInitiationCount = async () => {
// //     try {
// //       const inflowResponse = await api.get(`/caseInitiation/lastSixMonthsCaseInitiationData`);
// //       const outflowResponse = await api.get(`/caseInitiation/lastSixMonthsOutputQcCompletionCount`);

// //       console.log(lastSixMonthsOutputQcCompletionCount,"data...")

// //       // const xAxis = [
// //       //   {
// //       //     scaleType: 'point',
// //       //     data: inflowResponse.data?.map(item => item[0]),
// //       //   },
// //       // ];

// //       const monthLabels = inflowResponse.data?.map(item => {
// //   const [monthName] = item[0].split('-'); // assuming "Jun-2024"
// //   return monthName;
// // });

// // const xAxis = [
// //   {
// //     scaleType: 'point',
// //     data: monthLabels,
// //   },
// // ];

// //       const inflowYAxis = inflowResponse.data?.map(item => item[1]);
// //       const outflowYAxis = outflowResponse.data?.map(item => item[1]);

// //       const inflowSeries = {
// //         id: 'inflow',
// //         label: 'Inflow',
// //         data: inflowYAxis,
// //         showMark: false,
// //         area: true,
// //         curve: 'linear',
// //       };

// //       const outflowSeries = {
// //         id: 'outflow',
// //         label: 'Outflow',
// //         data: outflowYAxis,
// //         showMark: false,
// //         area: true,
// //         curve: 'linear',
// //       };

// //       setMonthlyData({ xAxis, series: [inflowSeries, outflowSeries] });
// //     } catch (error) {
// //       console.error('Error fetching case initiation data:', error);
// //     } finally {
// //       setLoading(false);
// //     }
// //   };

// const getLastSixMonthsCaseInitiationCount = async () => {
//   try {
//     const inflowResponse = await api.get(`/caseInitiation/lastSixMonthsCaseInitiationData`);
//     const outflowResponse = await api.get(`/caseInitiation/lastSixMonthsOutputQcCompletionCount`);

//     const monthLabels = inflowResponse.data?.map(item => {
//       const [monthName] = item[0].split('-');
//       return monthName;
//     });

//     const inflowData = inflowResponse.data?.map(item => item[1]);
//     const outflowData = outflowResponse.data?.map(item => item[1]);

//     setMonthlyData({
//       xAxis: [{ id: 'months', data: monthLabels, scaleType: 'band' }],
//       series: [
//         { id: 'inflow', data: inflowData, label: 'Inflow', color: theme.palette.primary.main },
//         { id: 'outflow', data: outflowData, label: 'Outflow', color: theme.palette.secondary.main },
//       ],
//     });
//   } catch (error) {
//     console.error('Error fetching case initiation data:', error);
//   } finally {
//     setLoading(false);
//   }
// };

//   React.useEffect(() => {
//     getLastSixMonthsCaseInitiationCount();
//   }, []);

//   const colorPalette = [theme.palette.primary.light, theme.palette.primary.dark];

//   const getLast7DaysLabels = () => {
//     const labels = [];
//     const today = new Date();

//     for (let i = 6; i >= 0; i--) {
//       const date = new Date();
//       date.setDate(today.getDate() - i);

//       const day = date.getDate();
//       const month = date.toLocaleString('default', { month: 'short' });

//       labels.push(`${day} ${month}`);
//     }

//     return labels;
//   };

//   const barChartDataMap = {
//     '7': {
//       xAxis: [
//         {
//           id: 'days',
//           data: getLast7DaysLabels(), // <-- dynamic dates here
//           scaleType: 'band',
//         },
//       ],
//       series: [
//         { id: 'no', data: [100, 80, 90, 76, 34, 18, 13], label: 'No', color: "#3b8d99" },
//         { id: 'yes', data: [40, 38, 23, 19, 14, 13, 6], label: 'Yes', color: "#FFE000" },
//       ],
//     },
//     '30': {
//       xAxis: [{ id: 'days', data: ['Week 1', 'Week 2', 'Week 3', 'Week 4'], scaleType: 'band' }],
//       series: [
//         { id: 'no', data: [320, 290, 210, 180], label: 'No', color: "#c31432" },
//         { id: 'yes', data: [140, 120, 110, 80], label: 'Yes', color: "#240b36" },
//       ],
//     },
//   };

//   const summaryItems = [
//     { label: 'Candidate Login Expired', value: 76 },
//     { label: 'Insufficient Cases', value: 23 },
//     { label: 'Go Ahead Pending', value: 54 },
//     { label: 'Cost Approval Required', value: 31 },
//     { label: 'Sign off Pending', value: 12 },
//   ];

//   const tatData = [
//     { label: 'Identity Check', value: 1, color: '#4caf50' },
//     { label: 'Employment Verification', value: 3, color: '#2196f3' },
//     { label: 'Education Verification', value: 5, color: '#ff9800' },
//     { label: 'Criminal Record Check', value: 7, color: '#f44336' },
//   ];

//   const allTatData = {
//     in: {
//       employment: [
//         { label: 'Identity Check', value: 2, color: '#4caf50' },
//         { label: 'Employment Verification', value: 4, color: '#2196f3' },
//       ],
//       drug: [
//         { label: 'Drug Test', value: 1, color: '#9c27b0' },
//       ],
//       education: [
//         { label: 'Education Verification', value: 3, color: '#ff9800' },
//       ],
//     },
//     out: {
//       employment: [
//         { label: 'Identity Check', value: 1, color: '#4caf50' },
//         { label: 'Employment Verification', value: 3, color: '#2196f3' },
//       ],
//       drug: [
//         { label: 'Drug Test', value: 2, color: '#9c27b0' },
//       ],
//       education: [
//         { label: 'Education Verification', value: 5, color: '#ff9800' },
//       ],
//     },
//   };


//   const severityData = [
//     { id: 0, label: 'Red', value: 10, color: '#f44336' },
//     { id: 1, label: 'Amber', value: 15, color: '#ff9800' },
//     { id: 2, label: 'Green', value: 75, color: '#4caf50' },
//   ];

//   return (
//     <Stack sx={{ display: "-ms-flexbox" }}>
//       {/* <Card variant="outlined" sx={{ height: "130px", width: "200%", borderRadius: "20px" }}>
//         <CardContent>

//           <Grid container spacing={7} sx={{ width: "1900px" }}>
//             {summaryItems.map((item, index) => (
//               <Grid item xs={12} sm={6} md={3} key={index}>
//                 <Box
//                   sx={{
//                     border: '1px solid #e0e0e0',
//                     borderRadius: 2,
//                     p: 2,
//                     textAlign: 'center',
//                     backgroundColor: '#fff',
//                     boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
//                     transition: 'all 0.3s ease-in-out',
//                     cursor: 'pointer',
//                     position: "relative",
//                     left: "40px"
//                   }}
//                 >
//                   <Typography variant="body2" color="textSecondary">
//                     {item.label}
//                   </Typography>
//                   <Typography variant="h6" sx={{ color: 'primary.main', fontWeight: 600 }}>
//                     {item.value}
//                   </Typography>
//                 </Box>
//               </Grid>
//             ))}
//           </Grid>





//         </CardContent>
//       </Card> */}


//       <Card variant="outlined" sx={{ width: '400px', height: "320px", margin: "10px 0px" }}>
//         <CardContent>

//           <Typography component="h2" variant="subtitle1" gutterBottom>
//             Case Inflow and Outflow for the Month
//           </Typography>
// <FormControl size="small" sx={{ minWidth: 120, mb: 2 }}>
//   <InputLabel id="highlight-select-label">Highlight</InputLabel>
//   <Select
//     labelId="highlight-select-label"
//     value={highlightSeries}
//     onChange={(e) => setHighlightSeries(e.target.value)}
//     label="Highlight"
//   >
//     <MenuItem value="inflow">Inflow</MenuItem>
//     <MenuItem value="outflow">Outflow</MenuItem>
//   </Select>
// </FormControl>

//           {loading ? (
//             <Box sx={{ display: 'flex', justifyContent: 'center', py: 5 }}>
//               <CircularProgress />
//             </Box>
//           ) : (
//             // <>
//             //   <LineChart
//             //     height={200}
//             //     colors={colorPalette}
//             //     xAxis={monthlyData.xAxis}
//             //     series={monthlyData.series}
//             //     margin={{ left: 50, right: 20, top: 20, bottom: 20 }}
//             //     grid={{ horizontal: true }}

//             //     sx={{
//             //       '& .MuiAreaElement-series-inflow': {
//             //         fill: "url('#inflow')",
//             //       },
//             //       '& .MuiAreaElement-series-outflow': {
//             //         fill: "url('#outflow')",
//             //       },
//             //     }}
//             //     slotProps={{ legend: { hidden: false } }}
//             //   >
//             //     <AreaGradient color={theme.palette.primary.light} id="inflow" />
//             //     <AreaGradient color={theme.palette.primary.dark} id="outflow" />
//             //   </LineChart>
//             // </>


// <BarChart
//   height={250}
//   xAxis={monthlyData.xAxis}
//   series={[
//     {
//       ...monthlyData.series[0],
//       label: 'Inflow',
//       color: highlightSeries === 'inflow' ? '#FFA500' : '#12c2e9',
//       barWidth: 14,
//     },
//     {
//       ...monthlyData.series[1],
//       label: 'Outflow',
//       color: highlightSeries === 'outflow' ? 'blue':"#808080",
//       barWidth: 14,
//     },
//   ]}
//   margin={{ top: 20, bottom: 30, left: 50, right: 20 }}
//   grid={{ horizontal: true }}
//   slotProps={{ legend: { hidden: false } }}
// />






//           )}
//         </CardContent>
//       </Card>

//       {/* <Card variant="outlined" sx={{ width: '390px', height: '320px', position: "relative", bottom: "330px", left: "760px" }}>
//         <CardContent>
//           <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
//             <Typography component="h2" variant="subtitle1">
//               Complete cases by severity
//             </Typography>
//             <FormControl size="small" sx={{ minWidth: 120 }}>
//               <Select value={severityDuration} onChange={handleSeverityDurationChange}>
//                 <MenuItem value="7">Last 7 days</MenuItem>
//                 <MenuItem value="30">Last 30 days</MenuItem>
//               </Select>
//             </FormControl>
//           </Box>

        
//           <Box sx={{ display: 'flex', mt: 2 }}>
           
//             <Box sx={{ display: 'flex', flexDirection: 'column', mr: 3, justifyContent: 'center', marginLeft: "10px" }}>
//               {[
//                 { label: 'Red', color: '#f44336' },
//                 { label: 'Amber', color: '#ff9800' },
//                 { label: 'Clear', color: '#4caf50' },
//               ].map((item) => (
//                 <Box key={item.label} sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
//                   <Box
//                     sx={{
//                       width: 12,
//                       height: 12,
//                       borderRadius: '50%',
//                       backgroundColor: item.color,
//                       mr: 1,
//                     }}
//                   />
//                   <Typography variant="body2">{item.label}</Typography>
//                 </Box>
//               ))}
//             </Box>



//             <PieChart
//               sx={{ position: "relative", bottom: "30px" }}
//               series={[
//                 {
//                   data: [
//                     { id: 0, value: 14, color: '#F41000' },
//                     { id: 1, value: 42, color: '#FF5A00' },
//                     { id: 2, value: 170, color: '#21AF27' },
//                   ],
//                   innerRadius: 45,
//                   outerRadius: 82,
//                   paddingAngle: 2,
//                   cornerRadius: 2,
//                 },
//               ]}
//               height={250}
//               width={250}
//             />

//           </Box>

//           <Typography sx={{ textAlign: 'center', mt: -2, fontSize: '28px', fontWeight: 600, position: "relative", bottom: "165px" }}>
//             226
//           </Typography>
//           <Typography sx={{ textAlign: 'center', fontSize: '14px', color: 'text.secondary', position: "relative", bottom: "165px" }}>
//             Total BGV
//           </Typography>
//         </CardContent>
//       </Card> */}
//    {/* <Box sx={{ display: 'flex', gap: 2, mt: -40 }}>

//         <Card variant="outlined" sx={{ flex: 1, height: "350px" }}>
//           <CardContent>
//             <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
//               <Typography component="h2" variant="subtitle1">
//                 Form Pending at Candidate’s End
//               </Typography>
//               <FormControl size="small" sx={{ minWidth: 120 }}>
//                 <InputLabel id="days-select-label">Days</InputLabel>
//                 <Select
//                   labelId="days-select-label"
//                   id="days-select"
//                   value={selectedDays}
//                   label="Days"
//                   onChange={handleDaysChange}
//                 >
//                   <MenuItem value="7">7 Days</MenuItem>
//                   <MenuItem value="30">30 Days</MenuItem>
//                 </Select>
//               </FormControl>
//             </Box>

//             <BarChart
//               xAxis={barChartDataMap[selectedDays].xAxis}
//               series={barChartDataMap[selectedDays].series}
//               height={250}
//               margin={{ top: 20, bottom: 30, left: 50, right: 20 }}
//               grid={{ horizontal: true }}
//               slotProps={{ legend: { hidden: false } }}
//             />
//           </CardContent>
//         </Card>
//       </Box> */}

//     </Stack>
//   );
// }


import * as React from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '@mui/material/styles';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import CircularProgress from '@mui/material/CircularProgress';
import { LineChart } from '@mui/x-charts/LineChart';
import api from '../../auth/api';

export default function SessionsChart() {
  const theme = useTheme();
  const [loading, setLoading] = React.useState(true);
  const [monthlyData, setMonthlyData] = React.useState({ xAxis: [], series: [] });

  const getLastSixMonthsCaseInitiationCount = async () => {
    try {
      const inflowResponse = await api.get(`/caseInitiation/lastSixMonthsCaseInitiationData`);
      const outflowResponse = await api.get(`/caseInitiation/lastSixMonthsOutputQcCompletionCount`);

      const xAxis = [
        {
          scaleType: 'point',
          data: inflowResponse.data?.map(item => item[0]),
        },
      ];

      const inflowYAxis = inflowResponse.data?.map(item => item[1]);
      const outflowYAxis = outflowResponse.data?.map(item => item[1]);

      const inflowSeries = {
        id: 'inflow',
        label: 'Inflow',
        data: inflowYAxis,
        showMark: false,
        curve: 'monotone', // smooth curve
      };

      const outflowSeries = {
        id: 'outflow',
        label: 'Outflow',
        data: outflowYAxis,
        showMark: false,
        curve: 'monotone', // smooth curve
      };

      setMonthlyData({ xAxis, series: [inflowSeries, outflowSeries] });
    } catch (error) {
      console.error('Error fetching case initiation data:', error);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    getLastSixMonthsCaseInitiationCount();
  }, []);

  const colorPalette = [
    '#ffad33ff', // neon pink for inflow
    '#d44e10ff', // lighter neon pink for outflow
  ];

  return (
    <Card variant="outlined" sx={{ width: '100%', backgroundColor: '#fdfafdff' }}>
      <CardContent>
        <Typography component="h2" variant="subtitle1" gutterBottom sx={{ color: '#black' }}>
          Case Inflow and Outflow for the Month
        </Typography>

        {loading ? (
          <div style={{ display: 'flex', justifyContent: 'center', padding: '40px 0' }}>
            <CircularProgress />
          </div>
        ) : (
          <LineChart
            height={280}
            colors={colorPalette}
            xAxis={monthlyData.xAxis}
            series={monthlyData.series}
            margin={{ left: 50, right: 20, top: 20, bottom: 20 }}
            grid={{ horizontal: false, vertical: false }}
            sx={{
              // backgroundColor: '#0c050cff',
              '& .MuiLineElement-root': {
                strokeWidth: 3,
                filter: 'drop-shadow(0px 0px 6px #ffad33ff)',
              },
              '& .MuiLineElement-series-outflow': {
                stroke: '#d44e10ff',
                filter: 'drop-shadow(0px 0px 6px #d44e10ff)',
              },
            }}
            slotProps={{
              legend: {
                hidden: false,
                labelStyle: { color: '#fff' },
              },
            }}
            animation={{
              duration: 6000, // animate lines over 2 seconds
              easing: 'easeOut',
            }}
          />
        )}
      </CardContent>
    </Card>
  );
}

















































