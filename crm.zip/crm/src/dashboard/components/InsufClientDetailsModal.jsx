import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Menu,
  MenuItem,
  IconButton,
  Tooltip,
  FormControl,
  InputLabel,
  Select,
  FormHelperText,
  Grid,
  Paper,
  Typography,
  Snackbar,
  CircularProgress,
  Box,
  FormGroup,
  FormLabel
} from '@mui/material';
import { Download, Delete, Close } from '@mui/icons-material';
import api from '../../auth/api';

const ClientInsufDetailsDialog = ({ open, onClose, data }) => {
  const [componentFields, setComponentFields] = useState([]);
  const [candidateDocuments, setCandidateDocuments] = useState([]);
  const [displayedDoc, setDisplayedDoc] = useState({ name: '', blob: null });
  const [showPdfViewer, setShowPdfViewer] = useState(false);
  const [loading, setLoading] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [formData, setFormData] = useState({
    caseId: data.caseId,
    candidateName: data.candidateName,
    componentDisplayName: data.componentDisplayName,
    insufficiencyDetails: data.insufficiencyDetails,
    insufficiencyClearanceComments: '',
    insufficiencyClearanceRejectionComments: data.insufficiencyClearanceRejectionComments || '',
    ...Object.fromEntries(
      ['TEXT', 'TEXTAREA', 'SELECT', 'DATE', 'AC-UNI', 'AC-COM'].map(type => [type, ''])
    )
  });
  const [fileUpload, setFileUpload] = useState({
    file: null,
    title: ''
  });

  useEffect(() => {
    if (open) {
      loadComponentFields();
      readFiles();
    }
  }, [open]);

  const loadComponentFields = async () => {
    try {
      const response = await api.get(`/componentfields/component/${data.component_id}`);
      
      const fields = response.data.filter((field) => 
        field.lhsRhs === 'BOTH' || field.lhsRhs === 'LHS'
    );
      setComponentFields(fields);
      loadFieldValues(fields);
    } catch (error) {
      showSnackbar('Error loading component fields', 'error');
    }
  };

  const loadFieldValues = async (fields) => {
    try {
      const response = await api.get(
        `${data.componentName}/findone/${data.case_id}/${data._id}`
      );
      const newFormData = { ...formData };
      fields.forEach(field => {
        if (field.type !== 'DATE') {
          newFormData[field.name] = response.data[field.name] || '';
        } else {
          const dateValue = new Date(response.data[field.name]);
          newFormData[field.name] = formatDate(dateValue);
        }
      });
      setFormData(newFormData);
    } catch (error) {
      console.log('error == ', error);
      
      showSnackbar('Error loading field values', 'error');
    }
  };

  const readFiles = async () => {
    try {
      const response = await api.get(
        `/${data.componentName}/readfilenames/${data.caseId}/${data.componentName}/${data._id}`
      );
      console.log('res == ', response);
      
      setCandidateDocuments(response.data);
    } catch (error) {
      console.log('error = ', error);
      
      showSnackbar('Error reading files', 'error');
    }
  };

  const downloadDocument = async (fileName) => {
    try {
      const response = await api.get(
        `/${data.componentName}/downloadfile/${data.caseId}/${data.componentName}/${data._id}?fileName=${fileName}`,
        {
          responseType: "blob",
        }
      );
      console.log('resp == ', response);
      
    } catch (error) {
      console.log('err =', error);
      
      showSnackbar("Error downloading document", "error");
    }
  };

  const uploadFile = async () => {
    if (!fileUpload.file || !fileUpload.title) return;

    const formData = new FormData();
    formData.append('componentFile', fileUpload.file);
    formData.append('fileName', fileUpload.title);
    formData.append('_id', data._id);
    formData.append('case_id', data.case_id);
    formData.append('caseId', data.caseId);
    formData.append('componentId',data.component_id);
    formData.append('componentName',data.componentName);


    try {
      await api.post(
        `/${data.componentName}/uploadfile`, formData,
        { headers: { 'Content-Type': 'multipart/form-data' } }
      );
      showSnackbar('File uploaded successfully', 'success');
      setCandidateDocuments([...candidateDocuments, fileUpload.title]);
      setFileUpload({ file: null, title: '' });
    } catch (error) {
      console.log('err == ', error);
      
      showSnackbar('Error uploading file', 'error');
    }
  };

  const handleClearInsuff = () => {
    onClose(formData);
  };

  const handleCancel = () => {
    onClose();
  };

  const handleFileChange = (event) => {
    if (event.target.files && event.target.files[0]) {
      setFileUpload({ ...fileUpload, file: event.target.files[0] });
    }
  };

  const formatDate = (date) => {
    const dd = String(date.getDate()).padStart(2, '0');
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const yyyy = date.getFullYear();
    return `${yyyy}-${mm}-${dd}`;
  };

  const showSnackbar = (message, severity) => {
    setSnackbar({ open: true, message, severity });
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const getSelectValues = (fieldName) => {
    const field = componentFields.find(f => f.name === fieldName);
    return field?.values?.split(',') || [];
  };

  return (
    <>
      <Dialog open={open} onClose={handleCancel} maxWidth="lg" fullWidth>
        <DialogTitle sx={{ backgroundColor: 'primary.main', color: 'white' }}>
          Clear Insufficiency
          <Button 
            variant="contained"
            onClick={handleMenuOpen}
            sx={{ position: 'absolute', right: 16 }}
          >
            Docs Uploaded
          </Button>
        </DialogTitle>

        <Menu
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={handleMenuClose}
        >
          {candidateDocuments.map((file) => (
            <MenuItem key={file} dense>
              <Grid container alignItems="center" spacing={1}>
                <Grid item xs={8}>
                  <Typography>{file}</Typography>
                </Grid>
                <Grid item xs={2}>
                  <Tooltip title="Download">
                    <IconButton onClick={() => downloadDocument(file)} size="small">
                      <Download fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </Grid>
                <Grid item xs={2}>
                  <Tooltip title="Delete">
                    <IconButton size="small">
                      <Delete fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </Grid>
              </Grid>
            </MenuItem>
          ))}
        </Menu>

        <DialogContent sx={{ mt: 2 }}>
          <FormGroup>
            <Grid container spacing={2}>
              <Grid item xs={4}>
                <TextField
                  label="Case ID"
                  value={formData.caseId}
                  fullWidth
                  margin="normal"
                  InputProps={{ readOnly: true }}
                />
              </Grid>
              <Grid item xs={4}>
                <TextField
                  label="Candidate Name"
                  value={formData.candidateName}
                  fullWidth
                  margin="normal"
                  InputProps={{ readOnly: true }}
                />
              </Grid>
              <Grid item xs={4}>
                <TextField
                  label="Component"
                  value={formData.componentDisplayName}
                  fullWidth
                  margin="normal"
                  InputProps={{ readOnly: true }}
                />
              </Grid>
            </Grid>

            <Paper elevation={3} sx={{ p: 2, mt: 2 }}>
              <FormLabel component="legend" sx={{ bgcolor: 'hsl(210, 98%, 48%)', color: 'white', p: 1 }}>
                Details Provided
              </FormLabel>
              <Grid container spacing={2} sx={{ mt: 1 }}>
                {componentFields.map((field) => (
                  <Grid item xs={3} key={field.name}>
                    {field.type === 'TEXT' || field.type === 'AC-UNI' || field.type === 'AC-COM' ? (
                      <TextField
                        label={field.label}
                        value={formData[field.name] || ''}
                        fullWidth
                        margin="normal"
                        InputProps={{ readOnly: true }}
                      />
                    ) : field.type === 'TEXTAREA' ? (
                      <TextField
                        label={field.label}
                        value={formData[field.name] || ''}
                        fullWidth
                        margin="normal"
                        multiline
                        rows={3}
                        InputProps={{ readOnly: true }}
                      />
                    ) : field.type === 'SELECT' ? (
                      <FormControl fullWidth margin="normal">
                        <InputLabel>{field.label}</InputLabel>
                        <Select
                          value={formData[field.name] || ''}
                          label={field.label}
                          disabled
                        >
                          {getSelectValues(field.name).map((value) => (
                            <MenuItem key={value} value={value}>
                              {value}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    ) : field.type === 'DATE' ? (
                      <DatePicker
                        label={field.label}
                        value={formData[field.name] || null}
                        onChange={() => {}}
                        renderInput={(params) => (
                          <TextField {...params} fullWidth margin="normal" InputProps={{ readOnly: true }} />
                        )}
                        disabled
                      />
                    ) : null}
                  </Grid>
                ))}
              </Grid>
            </Paper>

            <TextField
              label="Insufficiency Details"
              value={formData.insufficiencyDetails}
              fullWidth
              margin="normal"
              multiline
              rows={3}
              InputProps={{ readOnly: true }}
              InputLabelProps={{
                shrink: !!formData.insufficiencyDetails,
              }}
              sx={{
                '& .MuiInputBase-root': {
                  alignItems: 'flex-start',
                },
                '& .MuiInputBase-input': {
                  paddingTop: '8px',
                  paddingBottom: '8px',
                }
              }}
            />

            <TextField
              label="Clearance Comments"
              value={formData.insufficiencyClearanceComments}
              onChange={(e) => setFormData({
                ...formData,
                insufficiencyClearanceComments: e.target.value
              })}
              fullWidth
              margin="normal"
              multiline
              rows={3}
              required
              InputLabelProps={{
                shrink: !!formData.insufficiencyClearanceComments,
              }}
              sx={{
                '& .MuiInputBase-root': {
                  alignItems: 'flex-start',
                },
                '& .MuiInputBase-input': {
                  paddingTop: '8px',
                  paddingBottom: '8px',
                }
              }}
            />

            {(data.status === 'INSUF-1-CLEARANCE-REJECTED' || 
              data.status === 'INSUF-2-CLEARANCE-REJECTED') && (
              <TextField
                label="Rejection Reason"
                value={formData.insufficiencyClearanceRejectionComments}
                fullWidth
                margin="normal"
                multiline
                rows={3}
                InputProps={{ readOnly: true }}
              />
            )}

            <Box sx={{ width: "50%", mt: 2, display: 'flex', alignItems: 'center' }}>
              <input
                accept=".pdf"
                style={{ display: 'none' }}
                id="upload-file"
                type="file"
                onChange={handleFileChange}
              />
              <label htmlFor="upload-file" style={{ flex: 1 }}>
                <Button variant="contained" color='secondary' component="span" fullWidth>
                  {fileUpload.file ? fileUpload.file.name : 'Select File'}
                </Button>
              </label>
              <TextField
                label="File Title"
                value={fileUpload.title}
                onChange={(e) => setFileUpload({
                  ...fileUpload,
                  title: e.target.value
                })}
                sx={{ ml: 2, flex: 1 }}
                margin="normal"
              />
   
              {(fileUpload.file || fileUpload.title) && <Button
                variant="contained"
                color='secondary'
                onClick={uploadFile}
                disabled={!fileUpload.file || !fileUpload.title}
                sx={{ ml: 2, height: '2.5rem', mt: 1 }}
              >
                Upload
              </Button>}
            </Box>
          </FormGroup>
        </DialogContent>

        <DialogActions>
          <Button onClick={handleCancel}>Cancel</Button>
          {formData.insufficiencyClearanceComments && <Button 
            onClick={handleClearInsuff} 
            variant="contained"
            color='secondary'
            disabled={!formData.insufficiencyClearanceComments}
          >
            Clear Insuff
          </Button>}
        </DialogActions>
      </Dialog>

      {/* <Dialog 
        open={showPdfViewer} 
        onClose={() => setShowPdfViewer(false)}
        maxWidth="lg"
        fullWidth
      >
        <DialogTitle>
          {displayedDoc.name}
          <IconButton
            edge="end"
            onClick={() => setShowPdfViewer(false)}
            sx={{ position: 'absolute', right: 8, top: 8 }}
          >
            <Close />
          </IconButton>
        </DialogTitle>
        <DialogContent sx={{ height: '70vh' }}>
          {displayedDoc.blob && (
            <PDFViewer width="100%" height="100%">
              <embed 
                src={URL.createObjectURL(displayedDoc.blob)} 
                type="application/pdf" 
                width="100%" 
                height="100%"
              />
            </PDFViewer>
          )}
        </DialogContent>
      </Dialog> */}

      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        message={snackbar.message}
      />
    </>
  );
};

export default ClientInsufDetailsDialog;