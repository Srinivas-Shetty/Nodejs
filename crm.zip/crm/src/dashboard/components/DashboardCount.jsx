import React, { useEffect, useState } from 'react';
import {
  Card,
  CardContent,
  Typography,
  CircularProgress,
  Grid,
  Box,
} from '@mui/material';
import CountUp from 'react-countup';
import { LineChart, Line, ResponsiveContainer } from 'recharts';
import api from '../../auth/api'; 

export default function ClientDashboard() {
  const [counts, setCounts] = useState({});
  const [loading, setLoading] = useState(true);

  const getClientDashboardCounts = async () => {
    setLoading(true);
    try {
      const response = await api.get('/dashboardData/clientDashboardCount');
      console.log('Client Dashboard Counts:', response.data);
      setCounts(response.data);
    } catch (error) {
      console.error('Error fetching client dashboard counts:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getClientDashboardCounts();
  }, []);

  const dashboardItems = [
    { key: 'initiatedCasesCount', label: 'Initiated Cases' },
    { key: 'wipCasesCount', label: 'WIP Cases' },
    { key: 'completedCasesCount', label: 'Completed Cases' },
    { key: 'insuffCasesCount', label: 'Insufficiency Cases' },
    { key: 'casesWithInTATCount', label: 'Within TAT' },
    { key: 'casesBeyondTATCount', label: 'Beyond TAT' },
    { key: 'casesUnderHoldCount', label: 'On Hold' },
  ];

  // Sample data for sparklines (replace with real historical data if available)
  const sampleSparklineData = [
    { value: 5 },
    { value: 10 },
    { value: 7 },
    { value: 12 },
    { value: 15 },
  ];

  return (
    <Card variant="outlined">
      <CardContent>
        <Typography variant="h6" gutterBottom>
          Client Dashboard Summary
        </Typography>

        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
            <CircularProgress />
          </Box>
        ) : (
    //       <Grid container spacing={2} >
    //         {dashboardItems.map((item) => (
    //           // <Grid item xs={12} sm={6} md={3} key={item.key}>

    //           <Grid
    //   item
    //   key={item.key}
    //   sx={{
    //     flex: '1 0 5px', // grow/shrink with a minimum of 200px width
    //     MaxWidth: '100%',
    //   }}
    // >
    //             <Box
    //               sx={{
    //                 background: 'linear-gradient(135deg, #e45821ff, #ff7300ff)',
    //                 padding: 2,
    //                 borderRadius: 2,
    //                 textAlign: 'center',
    //                 color: 'white',
    //               }}
    //             >
    //               <Typography variant="body1">{item.label}</Typography>

    //               <Typography variant="h5">
    //                 <CountUp
    //                   end={counts[item.key] ?? 0}
    //                   duration={2}
    //                   separator=","
    //                 />
    //               </Typography>

    //               <Box sx={{ height: 50, mt: 1 }}>
    //                 <ResponsiveContainer width="100%" height="100%">
    //                   <LineChart data={sampleSparklineData}>
    //                     <Line
    //                       type="monotone"
    //                       dataKey="value"
    //                       stroke="#ffffff"
    //                       strokeWidth={2}
    //                       dot={false}
    //                     />
    //                   </LineChart>
    //                 </ResponsiveContainer>
    //               </Box>
    //             </Box>
    //           </Grid>
    //         ))}
    //       </Grid>
<Box
  sx={{
    display: 'flex',
    flexWrap: 'nowrap', 
    overflowX: 'auto',  
    gap: 2,
    pb: 1,
  }}
>
  {dashboardItems.map((item) => (
    <Box
      key={item.key}
      sx={{
        minWidth: 140, 
        maxWidth: 140,
        background: 'linear-gradient(135deg, #e45821ff, #ff7300ff)',
        padding: 2,
        borderRadius: 1,
        textAlign: 'center',
        color: 'white',
        height: 130,
        flexShrink: 0, 
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
      }}
    >
      <Typography variant="body1">{item.label}</Typography>
      <Typography variant="h5">
        <CountUp end={counts[item.key] ?? 0} duration={2} separator="," />
      </Typography>
      <Box sx={{ height: 50 }}>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={sampleSparklineData}>
            <Line
              type="monotone"
              dataKey="value"
              stroke="#ffffff"
              strokeWidth={2}
              dot={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </Box>
    </Box>
  ))}
</Box>


        )}
      </CardContent>
    </Card>
  );
}
