import React, { useEffect, useState } from 'react';
import {
    Card,
    CardContent,
    Typography,
    CircularProgress,
    Grid,
    Box,
} from '@mui/material';
import CountUp from 'react-countup';
import { LineChart, Line, ResponsiveContainer } from 'recharts';
import api from '../../auth/api';

export default function ClientDashboard2() {
    const [counts, setCounts] = useState({});
    const [loading, setLoading] = useState(true);
    const [userId,setUserId]=useState('');
  useEffect(() => {
    const storedUserId = localStorage.getItem('userId'); // key used in localStorage
    if (storedUserId) {
      setUserId(storedUserId);
    }
  }, []); 
    const getClientDashboardCounts = async () => {
        setLoading(true);
        try {
            const response = await api.get('/dashboardData/clientDashboardCount');
            console.log('Client Dashboard Counts:', response.data);
            setCounts(response.data);
        } catch (error) {
            console.error('Error fetching client dashboard counts:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        getClientDashboardCounts();
    }, []);

    const dashboardItems = [
        { key: 'insuffCasesCount', label: 'My Action Needed' },  //done
        { key: 'candidateinviteshare', label: 'Candidate Invite Share' },
        { key: 'candidatepending', label: 'Candidate Pending Submission' },
        { key: 'invoicepending', label: 'Invoice Pending Aprovals' },
        { key: 'nextcontractrenewal', label: 'Next Contract Renewal Dates' },
        { key: 'pendingCaseCount', label: 'Overall Open BGVs' },
        { key: 'initiatedCasesCount', label: 'BGV Initiated For this month' }, //done
        { key: 'casesWithInTATCount', label: 'BGV closed within TAT' }, //done
        { key: 'casesBeyondTATCount', label: 'BGV closed Beyond TAT' }, //done
        { key: 'casesUnderHoldCount', label: 'BGVs on Hold' } //done
    ];

    // Sample data for sparklines (replace with real historical data if available)
    const sampleSparklineData = [
        { value: 5 },
        { value: 10 },
        { value: 7 },
        { value: 12 },
        { value: 15 },
    ];

    return (
        <Card variant="outlined">
            <CardContent>
               <Box sx={{ mb: 4 }}>
  <Typography
    variant="h4"
    gutterBottom
    sx={{
      fontWeight: 'bold',
      color: 'primary.main',
    }}
  >
    Welcome back, {userId ? userId : ''} 
  </Typography>

  <Typography
    variant="subtitle1"
    sx={{
      color: 'text.secondary',
    }}
  >
    Here’s your current BGV summary and activity.
  </Typography>
</Box>

                {loading ? (
                    <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                        <CircularProgress />
                    </Box>
                ) : (
                    
                  <Box
  sx={{
    display: 'flex',
    flexWrap: 'wrap',   // allow wrapping to next row
    gap: 2,
    width: '100%',
  }}
>
  {dashboardItems.map((item) => (
    <Box
      key={item.key}
      sx={{
        flex: '1 1 calc(20% - 16px)', // 5 per row (minus gap)
        background: 'linear-gradient(135deg, #e45821ff, #ff7300ff)',
        padding: 2,
        borderRadius: 1,
        textAlign: 'center',
        color: 'white',
        height: 130,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
      }}
    >
      <Typography variant="body1" sx={{fontWeight:'500',fontSize:'16px'}}>{item.label}</Typography>
      <Typography variant="h5">
        <CountUp end={counts[item.key] ?? 0} duration={2} separator="," />
      </Typography>
      <Box sx={{ height: 50 }}>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={sampleSparklineData}>
            <Line
              type="monotone"
              dataKey="value"
              stroke="#ffffff"
              strokeWidth={2}
              dot={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </Box>
    </Box>
  ))}
</Box>



                )}
               
            </CardContent>
        </Card>
    );
}
