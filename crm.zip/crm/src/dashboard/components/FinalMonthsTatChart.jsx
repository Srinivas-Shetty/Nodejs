import React, { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  Typography,
  CircularProgress,
  Box,
} from "@mui/material";
import { BarChart } from "@mui/x-charts/BarChart";
import api from "../../auth/api";

export default function FinalMonthsTatChart({TATname}) {
  const [monthlyData, setMonthlyData] = useState(null);
  const [loading, setLoading] = useState(true);

  const getFinalTatDetails = async () => {
    setLoading(true);
    try {
      const res = await api.get("/dashboardData/final-data"); // 🔥 your API route
      if (res.data && res.data.months) {
        const months = res.data.months.map((m) => m.month);
        const withinTat = res.data.months.map((m) => m.withinTat);
        const beyondTat = res.data.months.map((m) => m.beyondTat);

        setMonthlyData({
          xAxis: [{ id: "months", data: months, scaleType: "band" }],
          series: [
            {
              id: "withinTat",
              data: withinTat,
              label: "Within TAT",
              color: "#ffad33", // green
            },
            {
              id: "beyondTat",
              data: beyondTat,
              label: "Beyond TAT",
              color: "#d44e10", // red
            },
          ],
        });
      }
    } catch (err) {
      console.error("Error fetching final months TAT:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getFinalTatDetails();
  }, []);

  return (
    <Card variant="outlined" sx={{ height: "400px", flex: 1 }}>
      <CardContent>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            mb: 2,
          }}
        >
          <Typography component="h2" variant="subtitle1">
            {TATname ? TATname : ''} TAT Closure (Apr 2025 - Mar 2026)
          </Typography>
        </Box>

        {loading ? (
          <Box sx={{ display: "flex", justifyContent: "center", mt: 4 }}>
            <CircularProgress />
          </Box>
        ) : monthlyData ? (
          <BarChart
            height={300}
            xAxis={monthlyData.xAxis}
            series={monthlyData.series}
            margin={{ top: 20, bottom: 40, left: 50, right: 20 }}
            grid={{ horizontal: true }}
          />
        ) : (
          <Typography>No data available.</Typography>
        )}
      </CardContent>
    </Card>
  );
}
