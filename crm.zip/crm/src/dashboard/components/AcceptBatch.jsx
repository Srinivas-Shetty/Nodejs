// import React from 'react'
// import {
//     Box,
//     Typography,
//     TextField,
//     Button,
//     Grid,
//     FormControl,
//     InputLabel,
//     MenuItem,
//     Select,
// } from '@mui/material';
// import { DataGrid } from '@mui/x-data-grid';

// const AcceptBatch = () => {

//     const columns = [
//         { field: 'slNo', headerName: '#', minWidth: 60 },
//         { field: 'batchId', headerName: 'Batch ID', minWidth: 100 },
//         { field: 'client', headerName: 'Client', flex: 2, minWidth: 200 },
//         { field: 'subClient', headerName: 'SubClient', minWidth: 120 },
//         { field: 'rejected cases', headerName: 'rejected cases', minWidth: 120 },
//         { field: 'accepted cases', headerName: 'accepted cases', minWidth: 120 },
//         { field: 'rejected cases', headerName: 'rejected cases', minWidth: 120 },
//         { field: 'uploadedDate', headerName: 'Uploaded Date', minWidth: 120 },
       
//     ];

//     const rows = [

//     ];

//     return (
//         <>
//         <Typography component="h2" variant="h6" sx={{ mb: 2 }}>
//             Accept Batch
//         </Typography>

       
//                 <Box sx={{ width: '100%', height: '100vh', overflow: 'hidden' }}>
//                             <Grid container spacing={2} >
//                                 <Grid item xs={12} sx={{ width: "900px" }}>
//                                     <Box sx={{ height: 500, width: '100%' }}>
//                                         <DataGrid
//                                             rows={rows}
//                                             columns={columns}
//                                             disableRowSelectionOnClick
//                                             getRowClassName={(params) =>
//                                                 params.indexRelativeToCurrentPage % 2 === 0 ? 'even' : 'odd'
//                                             }
//                                             initialState={{
//                                                 pagination: { paginationModel: { pageSize: 10 } },
//                                             }}
//                                             pageSizeOptions={[10, 20, 50]}
//                                             density="compact"
//                                             sx={{
//                                                 whiteSpace: 'normal',
//                                                 '& .MuiDataGrid-cell:focus': {
//                                                     outline: 'none',
//                                                     backgroundColor: 'transparent',
//                                                 },
//                                                 '& .MuiDataGrid-columnHeaders': {
//                                                     backgroundColor: '#f5f5f5',
//                                                     fontWeight: 'bold',
//                                                 },
//                                             }}
//                                         />
//                                     </Box>
//                                 </Grid>
//                             </Grid>
//                         </Box>
//                         </>
//     )
// }

// export default AcceptBatch


import React, { useState, useEffect } from 'react';
import {
    Box,
    Typography,
    Grid,
    FormControl,
    InputLabel,
    Select,
    TextField,
    Button,
    Modal
} from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import IconButton from '@mui/material/IconButton';
import { DataGrid } from '@mui/x-data-grid';
import api from '../../auth/api';
import moment from 'moment';
import AcceptBatchModal from './AcceptBatchModal';


const AcceptBatch = () => {
    const [rows, setRows] = useState([]);
    const [batchData, setBatchData] = useState([]);
    const [modalData, setModalData] = useState({});
    const [clients, setClients] = useState([]);
    const [subclients, setSubclients] = useState([]);
    const [batches, setBatches] = useState([]);
    const [client, setClient] = useState('');
    const [subclient, setSubclient] = useState('');
    const [caseCount, setCaseCount] = useState(0);
    const [open, setOpen] = useState(false);
    const userId = localStorage.getItem('userId');

    const handleOpen = (row) => {
        console.log('Download clicked for row:', row);
        const data = batchData.find(data => data.batchId === row.batchId)
        setModalData(data)
        setOpen(true);
    };

    const handleClose = () => setOpen(false);

    // const columnsModal = [
    //     { field: 'Sl.No', headerName: '#', flex: 1, minWidth: 60 },
    //     { field: 'File Name', headerName: 'File Name', flex: 1, minWidth: 100 },
    //     { field: 'Candidate Name', headerName: 'Candidate Name', flex: 2, minWidth: 200 },
    //     { field: 'Package/Profile', headerName: 'Package/Profile', flex: 1, minWidth: 120 },
    //     { field: 'Package Name', headerName: 'Package Name', flex: 1, minWidth: 120 },
    //     { field: 'Profile Name', headerName: 'Profile Name', flex: 1, minWidth: 120 },
    //     { field: 'Accept', headerName: 'Accept', flex: 1, minWidth: 120 },
    //     { field: 'Reject', headerName: 'Reject', flex: 1, minWidth: 120 }        
    // ];

    const columns = [
        { field: 'batchId', headerName: 'Batch ID', minWidth: 100 },
        { field: 'client', headerName: 'Client', flex: 1, minWidth: 160 },
        { field: 'subClient', headerName: 'SubClient', minWidth: 120 },
        { field: 'numberOfCases', headerName: 'Upload Cases', minWidth: 120 },
        { field: 'rejectedCases', headerName: 'Rejected Cases', minWidth: 120 },
        { field: 'acceptedCases', headerName: 'Accepted Cases', minWidth: 120 },
        { field: 'uploadedDate', headerName: 'Uploaded Date', minWidth: 120 },
        { field: 'uploaded',headerName: 'Uploaded', minWidth: 120, renderCell: (params) => (
            <IconButton
              onClick={() => {
                console.log('Download clicked for row:', params.row);
                handleOpen(params.row)
              }}
              sx={{border: 'none',
                color: 'blue'}}
            >
              <DownloadIcon />
            </IconButton>
          ), },
    ];



    const getAllBatches = async () => {
        try {
            const response = await api.get(`/usersubclientaccess/useremail/${userId}`)
            if (response.data) {
                let clientSubclientIds = [];
                for(let subclientOfResponse of response.data){
                    let clientSubclient = {
                      client: subclientOfResponse.client._id,
                      subclient:subclientOfResponse.subclient._id
                    }
                    clientSubclientIds.push(clientSubclient);  
                  }
                const batchResponse = await api.get(`/batches/clientssubclients`)
                // console.log('res == ', batchResponse.data);
                if (batchResponse.data) {
                    setBatchData(batchResponse.data)
                    let data = batchResponse.data.map((item,index) => {
                        return {
                            id: index + 1,
                            batchId: item?.batchId,
                            client: item?.client?.name,
                            subClient: item?.subclient?.name,
                            numberOfCases: item?.numberOfCases,
                            rejectedCases: item?.rejectedCases,
                            acceptedCases: item?.acceptedCases,
                            uploadedDate: item?.uploadDate ? moment(item?.uploadDate).format('YYYY-MM-DD') : item?.uploadDate
                        }
                    })
                    setRows(data)
                }
                
            }
        } catch (error) {
            console.log('err == ', error);
            
        }
      }
    
    useEffect(() => {
        getAllBatches()
    }, []);

    return (
        <>
            <Typography component="h2" variant="h6" sx={{ mb: 2 }}>
                Accept Batch
            </Typography>
            <Box sx={{ width: '100%', height: '100vh', overflow: 'hidden' }}>
                <Grid container spacing={2}>
                <Box sx={{ height: 500, width: '100%' }}>
                            <DataGrid
                                rows={rows}
                                columns={columns}
                                disableRowSelectionOnClick
                                getRo   wClassName={(params) =>
                                    params.indexRelativeToCurrentPage % 2 === 0 ? 'even' : 'odd'
                                }
                                initialState={{
                                    pagination: { paginationModel: { pageSize: 10 } },
                                }}
                                pageSizeOptions={[10, 20, 50]}
                                density="compact"
                                sx={{
                                    whiteSpace: 'normal',
                                    // '& .MuiDataGrid-cell:focus': {
                                    //     outline: 'none',
                                    //     backgroundColor: 'transparent',
                                    // },
                                    '& .MuiDataGrid-columnHeaders': {
                                        backgroundColor: '#f5f5f5',
                                        fontWeight: 'bold',
                                    },
                                    "& .MuiDataGrid-cell:focus": {
                                        outline: "none",
                                        backgroundColor: "transparent",
                                      },
                                      "& .MuiDataGrid-cell:focus-within": {
                                        outline: "none",
                                      },
                                      "& .MuiDataGrid-cell *:focus": {
                                        outline: "none",
                                        boxShadow: "none",
                                        backgroundColor: "transparent",
                                      },
                                    //   "& .MuiDataGrid-columnHeaders": {
                                    //     backgroundColor: "#f5f5f5",
                                    //     fontWeight: "bold",
                                    //   },
                                }}
                            />
                        </Box>
                </Grid>
            </Box>
            <Modal open={open} onClose={handleClose}>
                {/* <Box
                    sx={{
                        position: 'absolute',
                        top: '50%',
                        left: '50%',
                        transform: 'translate(-50%, -50%)',
                        bgcolor: 'background.paper',
                        boxShadow: 24,
                        p: 4,
                        borderRadius: 2,
                        width: "90%",
                        height: "60%",
                        textAlign: 'center'
                    }}
                >

                    <Typography component="h2" variant="h6" sx={{ mb: 2 }}>
                        Accept Batch
                    </Typography>

                    <Box sx={{ display: 'flex', gap: 3, mb: 4, flexWrap: 'wrap' }}>
                        <FormControl required sx={{ width: '30%' }}>
                            <InputLabel id="client-label">Client</InputLabel>
                            <Select
                                labelId="client-label"
                                value={client}
                                onChange={(e) => setClient(e.target.value)}
                                IconComponent={KeyboardArrowDownIcon}
                                label="Client"
                            >
                            </Select>
                        </FormControl>

                        <FormControl required sx={{ width: '30%' }}>
                            <InputLabel id="subclient-label">Subclient</InputLabel>
                            <Select
                                labelId="subclient-label"
                                value={subclient}
                                onChange={(e) => setSubclient(e.target.value)}
                                IconComponent={KeyboardArrowDownIcon}
                                label="Subclient"
                            >
                            </Select>
                        </FormControl>


                        <TextField
                            label="No. of Cases"
                            type="number"
                            value={caseCount}
                            onChange={(e) => {
                                const val = e.target.value;
                                if (!isNaN(val) && Number(val) >= 0) {
                                    setCaseCount(val);
                                }
                            }}
                            onKeyDown={(e) => {
                                if (e.key === 'ArrowUp') {
                                    setCaseCount((prev) => String(Number(prev || 0) + 0));
                                } else if (e.key === 'ArrowDown') {
                                    setCaseCount((prev) => {
                                        const newVal = Number(prev || 0) - 1;
                                        return newVal >= 0 ? String(newVal) : '0';
                                    });
                                }
                            }}
                            required
                            sx={{ width: '10%' }}
                            slotProps={{
                                input: {
                                    min: 0,
                                },
                            }}
                        />

                        <Button
                            variant="contained"
                            color="secondary"
                            sx={{ margin: "0 16px" }}
                            onClick={''}
                        >
                            Download Zip File <DownloadIcon />
                        </Button>

                        <Box sx={{ width: '700%', height: '100vh', overflow: 'hidden' }}>
                            <Grid container spacing={2} >
                                <Grid item xs={12} sx={{ width: "100%" }}>
                                    <Box sx={{ height: 400, width: '100%' }}>
                                        <DataGrid
                                            rows={rows}
                                            columns={columnsModal}
                                            disableRowSelectionOnClick
                                            getRowClassName={(params) =>
                                                params.indexRelativeToCurrentPage % 2 === 0 ? 'even' : 'odd'
                                            }
                                            initialState={{
                                                pagination: { paginationModel: { pageSize: 5 } },
                                            }}
                                            pageSizeOptions={[10, 20, 50]}
                                            density="compact"
                                            sx={{
                                                whiteSpace: 'normal',
                                                '& .MuiDataGrid-cell:focus': {
                                                    outline: 'none',
                                                    backgroundColor: 'transparent',
                                                },
                                                '& .MuiDataGrid-columnHeaders': {
                                                    backgroundColor: '#f5f5f5',
                                                    fontWeight: 'bold',
                                                },
                                            }}
                                        />
                                    </Box>
                                </Grid>
                            </Grid>
                        </Box>
                    </Box>
                </Box> */}
                <AcceptBatchModal modalData={modalData} onClose={handleClose}/>
            </Modal>
        </>
    );
};

export default AcceptBatch;
