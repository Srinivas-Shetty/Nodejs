import React, { useEffect, useState } from 'react';
import {
  Card,
  CardContent,
  Typography,
  Button,
  CircularProgress,
  Box,
  Stack,
} from '@mui/material';
import { BarChart } from '@mui/x-charts/BarChart';
import { PieChart } from '@mui/x-charts/PieChart';
import api from '../../auth/api';
import axios from 'axios';

export default function PageViewsBarChart() {
  const [caseInitiationOverlay, setCaseInitiationOverlay] = useState(false);
  const [caseInitiationLoading, setCaseInitiationLoading] = useState(true);
  const [caseInitiationData, setCaseInitiationData] = useState(null);
  const [pendingFrequencyBucketData, setPendingFrequencyBucketData] = useState([]);
  const [pendingFrequencyLoading, setPendingFrequencyLoading] = useState(true);

  const [gradingColorLoading, setGradingColorLoading] = useState(true);
  const [gradingColorData, setGradingColorData] = useState(null);

  // Simulate loading case initiation data
  useEffect(() => {
    setTimeout(() => {
      setGradingColorData([
        { id: 0, value: 45, label: 'High' },
        { id: 1, value: 25, label: 'Medium' },
        { id: 2, value: 30, label: 'Low' },
      ]);
      setGradingColorLoading(false);
    }, 2000);
  }, []);

  const getLastSixMonthsCaseInitiationCount = () => {
    console.log('Fetching last six months data...');
    // Simulated action
    setCaseInitiationOverlay(true);
  };

  const onMonthSelectForCaseInitiation = (event) => {
    console.log('Bar clicked:', event);
    setCaseInitiationOverlay(false);
  };


  const getDateWiseCaseInitiationData = async () => {
    const params = new URLSearchParams();
  
    // if (clientId) {
    //   params.append('clientId', clientId);
    // }

    // if (clientIds?.length) {
    //   params.append('clientId', clientIds.join(','));
    // }
    let monthYear = 'Dec-2024'
    const response = await api.get(`/caseInitiation/dateWiseCaseInitiationData/${monthYear}`, {
      params,
    });
    let xAxis = response.data.map(item => item[0])
    let yAxis = response.data.map(item => item[1])
    setCaseInitiationData({
      xAxis: [
        { scaleType: 'band', data: xAxis },
      ],
      series: [
        {
          data: yAxis,
          label: 'Cases Initiated',
        },
      ],
    });
    setCaseInitiationLoading(false);
    
  }


  const getPendingFrequencyBucketDetails = async (type = null, clientId, clientIds) => {
    const params = {};
    if (clientId) {
      params.clientId = clientId;
    }
    if (clientIds?.length) {
      params.clientId = clientIds.join(',');
    }

    setPendingFrequencyLoading(true);

    try {
      const response = await api.get(`/cases/pendingFrequencyBucket?type=${type}`, { params });
      // const response = await axios.get(`http://vibe.verifacts.co.in/api/cases/pendingFrequencyBucket?type=${type}`, { params });
      // console.log('res == ', response);
      
      const responseData = response.data;
      const keys = Object.keys(responseData).filter(key => key !== 'Total');
      const chartData = keys.map((key, index) => ({
        id: index,
        value: responseData[key].length,
        label: key, 
      }));
      setPendingFrequencyBucketData(chartData);
    } catch (error) {
      console.error('Error fetching bucket details:', error);
    } finally {
      setPendingFrequencyLoading(false);
    }
  };

  useEffect(() => { 
    getDateWiseCaseInitiationData(), 
    getPendingFrequencyBucketDetails(null, null, [])
  },[])

  return (
    <Stack spacing={4}>
      {/* <Card variant="outlined" sx={{height:"430px"}}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Case Initiation
          </Typography>

          <Box
            sx={{
              position: 'relative',
              backgroundColor: '#f5f5f5',
              padding: 2,
              borderRadius: 1,
              marginBottom: 2,
            }}
          >
          </Box>

          {caseInitiationLoading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
              <CircularProgress />
            </Box>
          ) : (
            <BarChart
              xAxis={caseInitiationData.xAxis}
              series={caseInitiationData.series}
              width={400}
              height={360}
              // onClick={onMonthSelectForCaseInitiation}
            />
          )}
        </CardContent>
      </Card> */}

      <Card variant="outlined" >
      <CardContent>
        <Typography variant="h6" gutterBottom>
          Pending Frequency Bucket
        </Typography>

        {pendingFrequencyLoading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
            <CircularProgress />
          </Box>
        ) : (
          <PieChart
              series={[
                {
                  data: pendingFrequencyBucketData,
                },
              ]}
            width={340}
            height={280}
            />

//           <PieChart
//   series={[
//     {
//       data: pendingFrequencyBucketData.map((item, index) => ({
//         ...item,
//         color: ['#e76413ff', '#cea140ff', '#f56e00ff', '#a3978cff', '#e09f11ff'][index % 5],
//       })),
//     },
//   ]}
//   width={340}
//   height={280}
// />
        )}
      </CardContent>
    </Card>
    </Stack>
  );
}

