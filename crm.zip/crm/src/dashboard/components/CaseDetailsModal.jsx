import * as React from 'react';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import Typography from '@mui/material/Typography';
import { styled } from '@mui/material/styles';
import { useEffect } from 'react';
import { useState } from 'react';
import { DataGrid, GridCloseIcon } from '@mui/x-data-grid';
import LinearProgress from '@mui/material/LinearProgress';
import Alert from '@mui/material/Alert';
import CircularProgress from '@mui/material/CircularProgress';
import api from '../../auth/api';
import { Button, IconButton } from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';

const columns = [
  {
    field: 'componentDisplayName',
    headerName: 'Component',
    flex: 1,
    minWidth: 180
  },
  {
    field: 'field1',
    headerName: 'Field 1',
    flex: 1,
    minWidth: 150
  },
  {
    field: 'field2',
    headerName: 'Field 2',
    flex: 1,
    minWidth: 150
  },
  {
    field: 'field3',
    headerName: 'Field 3',
    flex: 1,
    minWidth: 150
  },
  {
    field: 'displayStatus',
    headerName: 'Display Status',
    flex: 1,
    minWidth: 180
  },
  // { 
  //   field: 'gradingColor', 
  //   headerName: 'Grading Color', 
  //   flex: 1, 
  //   minWidth: 150 
  // }
  {
    field: "gradingColor",
    headerName: "Grade",
    width: 80,
    sortable: false,
    renderCell: (params) => (
      <div
        style={{
          marginTop: '7px',
          width: "30px",
          height: "10px",
          borderRadius: "3px",
          backgroundColor: params.value || "transparent",
        }}
      />
    ),
  }
];

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: '80%',
  //   maxWidth: 800,
  bgcolor: 'background.paper',
  boxShadow: 24,
  p: 4,
  borderRadius: 1,
  //   maxHeight: '80vh',
  //   overflowY: 'auto'
};

const DetailRow = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexWrap: 'wrap',
  gap: theme.spacing(2),
  marginBottom: theme.spacing(3),
  [theme.breakpoints.down('sm')]: {
    flexDirection: 'column',
    gap: theme.spacing(1),
  },
}));

const DetailItem = styled(Box)({
  flex: '1 1 200px',
  minWidth: 0,
});

function fillFieldDetails(componentName, field, item) {
  if (componentName == 'address') {
    if (field == "field1") {
      return item.typeofaddress
    } else if (field == "field2") {
      return item.address
    } else {
      return item.city
    }
  } else if (componentName == 'addresscomprehensive') {
    if (field == "field1") {
      return item.typeofaddress
    } else if (field == "field2") {
      return item.fulladdress
    } else {
      return item.city
    }
  } else if (componentName == 'addressonline') {
    if (field == "field1") {
      return item.typeofaddress
    } else if (field == "field2") {
      return item.fulladdwithpin
    } else {
      return item.city
    }
  } else if (componentName == 'addresstelephone') {
    if (field == "field1") {
      return item.typeofaddress
    } else if (field == "field2") {
      return item.address
    } else {
      return item.city
    }
  } else if (componentName == 'bankstmt') {
    if (field == "field1") {
      return item.nameofbank
    } else if (field == "field2") {
      return "-"
    } else {
      return "-"
    }
  } else if (componentName == 'courtrecord') {
    if (field == "field1") {
      return item.typeofaddress
    } else if (field == "field2") {
      return item.addresswithpin
    } else {
      return item.city
    }
  } else if (componentName == 'creditcheck') {
    if (field == "field1") {
      return item.candidate
    } else if (field == "field2") {
      return item.taxid
    } else {
      return "-"
    }

  } else if (componentName == 'creditequifax') {
    if (field == "field1") {
      return item.candidate
    } else if (field == "field2") {
      return item.derogatoryrecord
    } else {
      return "-"
    }
  } else if (componentName == 'credittrans') {
    if (field == "field1") {
      return item.nameasperpan
    } else if (field == "field2") {
      return item.derogatoryrecord
    } else {
      return "-"
    }
  } else if (componentName == 'criminalrecord') {
    if (field == "field1") {
      return item.typeofaddress
    } else if (field == "field2") {
      return item.fulladdress
    } else {
      return item.city
    }
  } else if (componentName == 'directorshipcheck') {
    if (field == "field1") {
      return item.directorname
    } else if (field == "field2") {
      return item.dinnumber
    } else {
      return "-"
    }
  } else if (componentName == 'dlcheck') {
    if (field == "field1") {
      return item.nameasperdl
    } else if (field == "field2") {
      return item.dlnumber
    } else {
      return item.issuedate
    }
  } else if (componentName == 'drugtestfive') {
    if (field == "field1") {
      return item.nameofemployee
    } else if (field == "field2") {
      return item.fulladdress
    } else {
      return item.city
    }
  } else if (componentName == 'drugtestsix') {
    if (field == "field1") {
      return "-"
    } else if (field == "field2") {
      return "-"
    } else {
      return "-"
    }
  } else if (componentName == 'drugtestseven') {
    if (field == "field1") {
      return item.nameofemploybee
    } else if (field == "field2") {
      return item.fulladdress
    } else {
      return item.city
    }
  } else if (componentName == 'drugtesteight') {
    if (field == "field1") {
      return item.nameofemployee
    } else if (field == "field2") {
      return item.address
    } else {
      return item.city
    }
  } else if (componentName == 'drugtestnine') {
    if (field == "field1") {
      return "-"
    } else if (field == "field2") {
      return item.fulladdress
    } else {
      return item.city
    }
  } else if (componentName == 'drugtestten') {
    if (field == "field1") {
      return item.nameofemployee
    } else if (field == "field2") {
      return item.address
    } else {
      return item.city
    }
  } else if (componentName == 'education') {
    if (field == "field1") {
      return item.address
    } else if (field == "field2") {
      return item.course
    } else {
      return item.nameofuniversity ?? item.nameofschool ?? item.university ?? ""
    }
  } else if (componentName == 'educationadvanced') {
    if (field == "field1") {
      return item.address
    } else if (field == "field2") {
      return item.course
    } else {
      return (item.nameofuniverskty != null ? item.nameofuniverskty : item.nameofschool !== null ? item.nameofschool : "")
    }
  } else if (componentName == 'educationcomprehensive') {
    if (field == "field1") {
      return item.address
    } else if (field == "field2") {
      return item.course
    } else {
      return (item.nameofuniversity != null ? item.nameofuniversity : item.nameofschool !== null ? item.nameofschool : "")
    }
  } else if (componentName == 'empbasic') {
    if (field == "field1") {
      return item.address
    } else if (field == "field2") {
      return item.company
    } else {
      return item.position
    }
  } else if (componentName == 'empadvance') {
    if (field == "field1") {
      return item.address
    } else if (field == "field2") {
      return item.company
    } else {
      return item.position
    }
  } else if (componentName == 'employment') {
    if (field == "field1") {
      return item.address
    } else if (field == "field2") {
      return item.company
    } else {
      return item.position
    }
  } else if (componentName == 'facisl3') {
    if (field == "field1") {
      return item.applicantname
    } else if (field == "field2") {
      return item.stcode
    } else {
      return "-"
    }
  } else if (componentName == 'gapvnf') {
    if (field == "field1") {
      return item.tenureofgap
    } else if (field == "field2") {
      return item.address
    } else {
      return item.city
    }
  } else if (componentName == 'globaldatabase') {
    if (field == "field1") {
      return "-"
    } else if (field == "field2") {
      return "-"
    } else {
      return "-"
    }
  } else if (componentName == 'identity') {
    if (field == "field1") {
      return item.typeofid
    } else if (field == "field2") {
      return item.nameasperid
    } else {
      return item.idnumber
    }
  } else if (componentName == 'ofac') {
    if (field == "field1") {
      return item.candname
    } else if (field == "field2") {
      return item.ofac
    } else {
      return "-"
    }
  } else if (componentName == 'passport') {
    if (field == "field1") {
      return item.passportnumber
    } else if (field == "field2") {
      return item.nationality
    } else {
      return item.expirydate
    }
  } else if (componentName == 'physostan') {
    if (field == "field1") {
      return "-"
    } else if (field == "field2") {
      return "-"
    } else {
      return "-"
    }
  } else if (componentName == 'refbasic') {
    if (field == "field1") {
      return item.name
    } else if (field == "field2") {
      return item.designation
    } else {
      return item.contact
    }
  } else if (componentName == 'reference') {
    if (field == "field1") {
      return item.nameofreference
    } else if (field == "field2") {
      return item.designation
    } else {
      return item.contactdetails
    }
  } else if (componentName == 'sitecheck') {
    if (field == "field1") {
      return item.name
    } else if (field == "field2") {
      return item.fulladdress
    } else {
      return item.city
    }
  } else if (componentName == 'socialmedia') {
    if (field == "field1") {
      return item.searchname
    } else if (field == "field2") {
      return "-"
    } else {
      return "-"
    }
  } else if (componentName == 'vddadvance') {
    if (field == "field1") {
      return item.companyname
    } else if (field == "field2") {
      return item.regdadd
    } else {
      return item.cin
    }
  } else {
    if (field == "field1") {
      return item.epicname
    } else if (field == "field2") {
      return item.epicnumber
    } else {
      return item.state
    }
  }
}

export default function CaseDetailsModal({ open, onClose, caseData }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [rows, setRows] = useState([]);
  const [showFiles, setShowFiles] = useState(false);

  const [caseFileData, setCaseFileData] = useState([
    
    
  ]);

  const getDetails = async () => {
    if (!caseData?.id) return;

    setLoading(true);
    setError(null);
    try {
      const componentsResp = await api.get(`/components`)
      if (componentsResp.data) {
        const componentPromises = componentsResp.data.map(async (component) => {


          try {
            const response = await api.get(`/${component.name}/${caseData.id}`)

            return response.data?.map((item, index) => ({
              id: `${component._id}-${item._id}`,
              _id: item._id,
              caseId: caseData.caseId,
              case_id: caseData.id,
              candidateName: caseData.candidateName,
              clientName: caseData.clientName,
              subclientName: caseData.subclientName,
              componentDisplayName: component.displayName,
              componentName: component.name,
              component_id: component._id,
              status: item.status,
              field1: fillFieldDetails(component.name, "field1", item),
              field2: fillFieldDetails(component.name, "field2", item),
              field3: fillFieldDetails(component.name, "field3", item),
              serialNumber: index + 1,
              displayStatus: getDisplayStatus(item.status),
              gradingColor: item.grade ? item.grade : ""
            }));
          } catch (error) {
            console.error(`Error fetching ${component.name} details:`, error);
            return [];
          }
        });

        const componentsData = await Promise.all(componentPromises);
        const flattenedData = componentsData.flat();
        // console.log(flattenedData, "flattenedData");

        setRows(flattenedData);
      }
    } catch (error) {
      console.error('Error fetching components:', error);
      setError('Failed to load component details. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getFileDetails = async () => {
  if (!caseData?.id) return;

  setLoading(true);
  setError(null);

  try {
    const response = await api.get(`/cases/readreportfilenames/${caseData.caseId}`);
    if (response.data) {
      // Assuming response.data is an array like:
      // [{ type: "FINAL", fileName: "file1.pdf", date: "2025-09-02T05:18:45.284Z" }, ...]
      setCaseFileData(response.data);
    } else {
      setCaseFileData([]);
    }
  } catch (error) {
    console.error(`Error fetching case files for ${caseData.caseId}:`, error);
    setError('Failed to load case files. Please try again.');
    setCaseFileData([]);
  } finally {
    setLoading(false);
  }
};


  const getDisplayStatus = (status) => {
    if (status === 'OUTPUTQC-ACCEPTED' || status === 'MENTOR-REVIEW-ACCEPTED') {
      return "Completed";
    } else if (
      status === 'INSUF-2-REQ-ACCEPTED' ||
      status === 'INSUF-2-REQ' ||
      status === 'INSUF-1-REQ-ACCEPTED' ||
      status === 'INSUF-1-REQ'
    ) {
      return "Insuff";
    } else if (
      status === 'CLARIFICATION-REQ-ACCEPTED' ||
      status === 'COST-APPROVAL-REQ-ACCEPTED'
    ) {
      return "Clarification";
    } else if (status === 'COST-APPROVAL-REQ') {
      return "Cost Approval";
    } else if (status === "DELETED-CHECK") {
      return "DELETED-CHECK";
    }
    return "Pending";
  };

  const getGradingColor = (grade) => {
    switch (grade) {
      case "Green": return "#059142";
      case "Red": return "#D93025";
      case "Amber": return "#F4B400";
      default: return "transparent";
    }
  };

  useEffect(() => {
    if (open && caseData) {
      getDetails();
      getFileDetails();
    }
  }, [open, caseData]);

  return (
    <Modal
      open={open}
      onClose={onClose}
      aria-labelledby="case-details-modal"
      aria-describedby="case-details-content"
    >
      <Box sx={style}>
        {/* <Typography variant="h6" component="h2" sx={{ mb: 3 }}>
          Case Details
        </Typography>
         <Typography variant="h6" component="h2" sx={{ mb: 3 }} onClick={onClose}>
         Close
        </Typography> */}

        <Box
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            mb: 3
          }}
        >
          <Typography variant="h6" component="h2">
            Case Details
          </Typography>

<div>
  
 <Button sx={{marginRight:'10px'}} variant="contained" onClick={() => setShowFiles(true)}>
        View Case Files
      </Button>
      <IconButton onClick={onClose} color="primary">
            <GridCloseIcon />
          </IconButton>
</div>

          



        </Box>


    
        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}

        <DetailRow>
          <DetailItem>
            <Typography variant="subtitle2" color="textSecondary">
              Case ID
            </Typography>
            <Typography variant="body1">{caseData?.caseId || "N/A"}</Typography>
          </DetailItem>

          <DetailItem>
            <Typography variant="subtitle2" color="textSecondary">
              Candidate
            </Typography>
            <Typography variant="body1">
              {caseData?.candidateName || "N/A"}
            </Typography>
          </DetailItem>

          <DetailItem>
            <Typography variant="subtitle2" color="textSecondary">
              Client
            </Typography>
            <Typography variant="body1">
              {caseData?.clientName || "N/A"}
            </Typography>
          </DetailItem>

          <DetailItem>
            <Typography variant="subtitle2" color="textSecondary">
              Subclient
            </Typography>
            <Typography variant="body1">
              {caseData?.subclientName || "N/A"}
            </Typography>
          </DetailItem>
        </DetailRow>

        <Typography variant="h6" component="h2" sx={{ mb: 3 }}>
          Component Details
        </Typography>

        <Box sx={{ height: 400, width: "100%", position: "relative" }}>
          {loading && rows.length === 0 ? (
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "15%",
              }}
            >
              <CircularProgress />
            </Box>
          ) : (
            <DataGrid
              rows={rows}
              columns={columns}
              loading={loading}
              components={{
                LoadingOverlay: LinearProgress,
              }}
              pageSize={10}
              rowsPerPageOptions={[10]}
              disableSelectionOnClick
              getRowId={(row) => row.id}
              sx={{
                "& .MuiDataGrid-root": {
                  overflow: "scroll",
                },
                "& .MuiDataGrid-cell": {
                  display: "flex",
                  alignItems: "center",
                },
              }}
            />
          )}
        </Box>



   <Modal open={showFiles} onClose={() => setShowFiles(false)}>
        <Box sx={style}>
          <Typography variant="h6" component="h2" sx={{ mb: 2 }}>
            Case Files
          </Typography>

          {caseFileData.length > 0 ? (
            <Box sx={{ display: "flex", flexDirection: "column", gap: 1 }}>
              {caseFileData.map((file, index) => (
                <Button
                  key={index}
                  variant="outlined"
                  startIcon={<DownloadIcon />}
                  onClick={() => handleDownload(file.fileName)}
                  sx={{ justifyContent: "flex-start" }}
                >
                  {file.fileName} ({file.type})
                </Button>
              ))}
            </Box>
          ) : (
            <Typography variant="body2" color="textSecondary">
              No case files available
            </Typography>
          )}

          <Box sx={{ mt: 2, textAlign: "right" }}>
            <Button variant="contained" onClick={() => setShowFiles(false)}>
              Close
            </Button>
          </Box>
        </Box>
      </Modal>


      </Box>


    </Modal>
  );
}