import axios from 'axios';
const apiUrl = import.meta.env.VITE_BASE_URL;

const api = axios.create({
  baseURL: apiUrl,
});

api.interceptors.request.use(
  (config) => {
    const authToken = localStorage.getItem('accessToken'); 
    if (authToken) {
      config.headers['Authorization'] = `Bearer ${authToken}`; 
    }
    return config;
  },
  (error) => {
    return Promise.reject(error); 
  }
);

export default api;
