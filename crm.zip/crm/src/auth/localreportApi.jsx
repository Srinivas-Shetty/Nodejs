import axios from 'axios';
const apiUrl = import.meta.env.VITE_LOCALREPORTS_URL;

const localreportsApi = axios.create({
  baseURL: apiUrl,
});

localreportsApi.interceptors.request.use(
  (config) => {
    const authToken = localStorage.getItem('accessToken'); 
    if (authToken) {
      config.headers['Authorization'] = `Bearer ${authToken}`; 
    }
    return config;
  },
  (error) => {
    return Promise.reject(error); 
  }
);

export default localreportsApi;