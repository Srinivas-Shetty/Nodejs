import { Navigate, useLocation } from 'react-router-dom';
import { isTokenValid } from '../utils/helper'; 

const AuthGuard = ({ children }) => {
  const location = useLocation();

  if (!isTokenValid()) {
    localStorage.removeItem('accessToken'); 
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
};

export default AuthGuard;
