import {jwtDecode} from 'jwt-decode';

export const isTokenValid = () => {
  const token = localStorage.getItem('accessToken');
  if (!token) return false;

  try {
    const decoded = jwtDecode(token);
    const now = Math.floor(Date.now() / 1000); 

    return decoded.exp > now;
  } catch (err) {
    return false;
  }
};
